import React, { useState, useEffect } from 'react';
import Prediction from './Components/Prediction';
import Page from './Components/Page';
import History from './Components/History'; 
import { ImageProvider, useImage } from './Components/ImageContext';
import Navbar from './Components/Navbar';
import Home from './Components/Home';
import Login from './Components/Login';
import Resource from './Components/Resource';
import CropCalculator from './Components/CropCalculator';
import Store from './Components/Store';
import { FaRobot } from 'react-icons/fa';
import Chatbot from './Components/Chatbot';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import CityInfo from './Components/CityInfo';
import CropMoniter from './Components/CropMoniter';
import Analytic from './Components/Analytic';
import Maps from './Components/Maps';

const AppContent = () => {
  const [view, setView] = useState('home'); 
  const [isLoggedIn, setIsLoggedIn] = useState(false); 
  const { userId, clearData } = useImage(); 
  const [response, setResponse] = useState(null); // State to store the response

  const [seeanalysis, setseeanalysis] = useState(false);
  useEffect(() => {
    setIsLoggedIn(Boolean(userId));
  }, [userId]);

  useEffect(() => {
    if (!isLoggedIn && view !== 'home' && view !== 'login') {
      setView('login');
    }
  }, [isLoggedIn, view]);



  const handleViewChange = (section) => {
    if (section !== 'home' && !isLoggedIn) {
      setView('login');
      return;
    }
    setView(section); 
  };

  // const newchange=(section)=>{
  //   if (section !== 'home' && !isLoggedIn) {
  //     setView('login');
  //     setResponse(true);
  //     return;
  //   }
  //   setView(section); 
  // };


  const handleLogout = () => {
    clearData(); 
    toast.success("Logout successful");
    setView('login'); 
  };


  return (
    <>
      <Navbar 
        onViewChange={handleViewChange}
        isLoggedIn={isLoggedIn}
        onLogout={handleLogout}
      />
      {view === 'login' && <Login onViewMore={() => handleViewChange('home')} />}
      {view === 'home' && <Home />}
      {view === 'history' && <History />}
      {view === 'prediction' && <Prediction onViewMore={() => handleViewChange('pages')} setResponse={setResponse} />}
      {view === 'resource' && <Resource onViewMore={() => handleViewChange('cropcalculator')}/>}
      {view === 'support' && <Store />}
      {view === 'pages' && <Page response={response} onViewMore={() => handleViewChange('prediction')} />}
      {view === 'cropcalculator' && <CropCalculator onViewMore={() => handleViewChange('resource')} />}
      {view === 'chatbot' && <Chatbot />}
      {view === 'get crop' && <CityInfo />}
      {view === 'analytic' && <Analytic />}
      {view === 'plant monitoring' && <CropMoniter onViewMore={() => handleViewChange('analytic')}/>}
      {view === 'maps' && <Maps />}
      {/* //  handleViewChange('analytic')
      //  setseeanalysis(true)}
      // />} */}
      
      {view !== 'login' && view !== 'chatbot' && (
        <div className="fixed bottom-20 right-5 z-50" onClick={() => handleViewChange('chatbot')}>
          <FaRobot className="text-6xl text-green-600 hover:text-green-400 transition-colors border rounded-full border-green-800 p-1 bg-black cursor-pointer" />
        </div>
      )}

      <ToastContainer />
    </>
  );
};



const App = () => (
  <ImageProvider>
    <AppContent />
  </ImageProvider>
);

export default App;
