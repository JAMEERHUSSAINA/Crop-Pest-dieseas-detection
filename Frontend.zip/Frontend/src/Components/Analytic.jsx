import {
    AreaChart,
    BarChart,
    LineChart,
    ScatterChart,
    DonutChart,
    BarList,
    Card,
  } from "@tremor/react";
import { useEffect ,useState} from "react";
import axios from 'axios';
  
  export default function Analytic({setseeanalysis}) {
   const [data, setData] = useState(null);
    const [error, setError] = useState(null);
    // const[response,setresponse] = useState("");
    const cityName ="Coimbatore";
    // useEffect(() => {
    //     // Define an async function inside useEffect
    //     const fetchCityData = async () => {
    //       try {
    //           // if(setseeanalysis){
    //           // Pass cityName as a key in the JSON payload
    //           const response = await axios.post('http://127.0.0.1:5000/find_weather_data', {
    //                 city: cityName
    //               });
    //               // setresponse(res);
    //               // Handle the response data
    //               if (response.status === 200) {
    //                 console.log('Success:', response.data.weather_data);
    //                 setData(response.data);
    //               } else {
    //                 console.error('Unexpected status code:', response.status);
    //                 setError('Unexpected status code: ' + response.status);
    //               }
    //             // }
    //         } catch (error) {
    //             // Handle error
    //             const message = error.response?.data?.message || 'Error occurred during the request';
    //             console.error('Error:', message);
    //             setError(message);
    //           }
    //         };
    //     if (cityName) { // Ensure cityName is not empty or null
    //       fetchCityData(); // Call the async function
    //     }
    //   }, ); 
      
          
    return (
      <div>
        <div className="flex justify-center">
          <h2 className="font-bold pt-5 text-xl font-montserrat">Growth Analytics</h2>
        </div>
        <div className="pt-5 px-3">
          <p className="font-poppins text-sm text-gray-800 font-bold ">
            Growth Moniter
          </p>
          <div className="px-4 border border-gray-700 rounded-md">
            <GrowthMoniter /> {/* GROWTH MONITER  - x-axis month y - height*/} 
          </div>
        </div>
  
        <div className="pt-5 px-3">
          <p className="font-montserrat text-sm text-gray-800 font-bold ">
            Weather Report
          </p>
          <div className="px-4 border border-gray-700 rounded-md">
            <WeatherReport/>{/* WEATER (TEMP,HUMIDITY,pressure) x-axis month y-axis values include those 3    */}
          </div>
        </div>
  
        <div className="pt-5 px-3">
          <p className="font-montserrat text-sm text-gray-800 font-bold ">
            Soil Moniter
          </p>
          <div className="px-4 border border-gray-700 rounded-md">
            <BarChartSoil /> {/* SOIL Temperature , humidity  (moisture , fertilizer , )*/}
          </div>
        </div>
  
        <div className="pt-5 px-3">
          <p className="font-montserrat text-sm text-gray-800 font-bold ">
            Fertilizer Used
          </p>
          <div className="px-4 border border-gray-700 rounded-md">
            <Fertilizers />
            {/* Fertilizer Used */}
          </div>
        </div>
  
        {/* <div className="pt-5 px-3">
          <p className="font-montserrat text-sm text-gray-800 font-bold ">
            Water Usage 
          </p>
          <div className="px-4 border border-gray-700 rounded-md">
            <WaterMonitering />
          </div>
        </div> */}
  
        <div className="pt-5 px-3">
          <p className="font-montserrat text-sm text-gray-800 font-bold ">
            Market Value
          </p>
          <div className="px-4 border border-gray-700 rounded-md">
            <MarketValue /> {/* Market Value */}
          </div>
        </div>
  
        <div className="pt-5 px-3 pb-5">
          <p className="font-montserrat text-sm text-gray-800 font-bold ">
            Problems faced over time on wheat
          </p>
          <div className="px-4 rounded-md">
            <Imapacts />
            {/* Impact */}
          </div>
        </div>
  
        {/* <div className="pt-5 px-3">
          <p className="font-montserrat text-sm text-gray-800 font-bold ">
            Yield
          </p>
          <div className="px-4  rounded-md">
            <Yield/>
            {/* Yield */}
          {/* </div>
        </div> */} 
      </div>
    );
  }
  
  const chartdata1 = [
    {
      date: "Feb 23",
      "Crop Growth": 1,
    },
    {
      date: "Mar 23",
      "Crop Growth": 1,
    },
    {
      date: "Apr 23",
      "Crop Growth": 1,
    },
    {
      date: "May 23",
      "Crop Growth": 1,
    },
    {
      date: "Jun 23",
      "Crop Growth":1,
    },
    {
      date: "Jul 23",
      "Crop Growth":1,
    },
    {
      date: "Aug 23",
      "Crop Growth":1,
    },
  ];
  
  export function GrowthMoniter() {
    const customTooltip = (props) => {
      const { payload, active } = props;
      if (!active || !payload) return null;
      return (
        <div className="w-56 rounded-tremor-default border border-tremor-border bg-tremor-background p-2 text-tremor-default shadow-tremor-dropdown">
          {payload.map((category, idx) => (
            <div key={idx} className="flex flex-1 space-x-2.5">
              <divx
                className={`flex w-1 flex-col bg-${category.color}-500 rounded`}
              />
              <div className="space-y-1">
                <p className="text-tremor-content">{category.dataKey}</p>
                <p className="font-medium text-tremor-content-emphasis">
                  {category.value} 
                </p>
              </div>
            </div>
          ))}
        </div>
      );
    };
    return (
      <>
        <h3 className="text-lg font-medium text-tremor-content-strong dark:text-dark-tremor-content-strong">
        </h3>
        <AreaChart
          className="mt-4 h-72"
          data={chartdata1}
          index="date"
          categories={["Crop Growth"]}
          colors={["blue"]}
          yAxisWidth={30}
          customTooltip={customTooltip}
          />
          <div className="flex justify-center">
            <p className="font-montserrat text-gray-700">plant growth</p>
            </div>
      </>
    );
  }
  const chartdata2 = [
    {
      date: "Jan 23",
      "Temperature": 167,
      "Humidity": 80,
      "Preassure": 135,
      "Hatha Yoga": 115,
      "Street Basketball": 150,
    },
    {
      date: "Feb 23",
      "Temperature": 125,
      "Humidity": 70,
      "Preassure": 115,
      "Hatha Yoga": 85,
      "Street Basketball": 180,
    },
    {
      date: "Mar 23",
      "Temperature": 156,
      "Humidity": 110,
      "Preassure": 125,
      "Hatha Yoga": 90,
      "Street Basketball": 130,
    },
    {
      date: "Apr 23",
      "Temperature": 165,
      "Humidity": 140,
      "Preassure": 145,
      "Hatha Yoga": 105,
      "Street Basketball": 170,
    },
    {
      date: "May 23",
      "Temperature": 153,
      "Humidity": 120,
      "Preassure": 140,
      "Hatha Yoga": 100,
      "Street Basketball": 110,
    },
    {
      date: "Jun 23",
      "Temperature": 124,
      "Humidity": 100,
      "Preassure": 120,
      "Hatha Yoga": 75,
      "Street Basketball": 140,
    },
  ];
  const weatherdata=[ 
      {
          "date": "Aug 07",
          "Temperature": 17.293498992919922,
          "Humidity": 78.0,
          "Pressure": 1007.635986328125 / 100
      },
      {
          "date": "Aug 07",
          "Temperature": 16.943500518798828,
          "Humidity": 79.0,
          "Pressure": 1007.4305419921875
      },
      {
          "date": "Aug 07",
          "Temperature": 16.64349937438965,
          "Humidity": 80.0,
          "Pressure": 1006.828369140625
      },
      {
          "date": "Aug 07",
          "Temperature": 16.0935001373291,
          "Humidity": 81.0,
          "Pressure": 1006.6189575195312
      },
      {
          "date": "Aug 07",
          "Temperature": 15.693499565124512,
          "Humidity": 83.0,
          "Pressure": 1006.213623046875
      },
      {
          "date": "Aug 07",
          "Temperature": 16.293498992919922,
          "Humidity": 81.0,
          "Pressure": 1006.4238891601562
      },
      {
          "date": "Aug 07",
          "Temperature": 18.14349937438965,
          "Humidity": 71.0,
          "Pressure": 1006.7569580078125
      },
      {
          "date": "Aug 07",
          "Temperature": 20.0935001373291,
          "Humidity": 64.0,
          "Pressure": 1006.0967407226562
      },
      {
          "date": "Aug 07",
          "Temperature": 22.14349937438965,
          "Humidity": 58.0,
          "Pressure": 1006.2333984375
      },
      {
          "date": "Aug 07",
          "Temperature": 24.3435001373291,
          "Humidity": 48.0,
          "Pressure": 1005.8753051757812
      },
      {
          "date": "Aug 07",
          "Temperature": 26.043498992919922,
          "Humidity": 44.0,
          "Pressure": 1005.6068115234375
      },
      {
          "date": "Aug 07",
          "Temperature": 27.39349937438965,
          "Humidity": 40.0,
          "Pressure": 1005.6307983398438
      },
      {
          "date": "Aug 07",
          "Temperature": 28.043498992919922,
          "Humidity": 41.0,
          "Pressure": 1005.6419067382812
      },
      {
          "date": "Aug 07",
          "Temperature": 28.64349937438965,
          "Humidity": 40.0,
          "Pressure": 1004.9561157226562
      },
      {
          "date": "Aug 07",
          "Temperature": 28.943500518798828,
          "Humidity": 38.0,
          "Pressure": 1005.0607299804688
      },
      {
          "date": "Aug 07",
          "Temperature": 28.8435001373291,
          "Humidity": 39.0,
          "Pressure": 1004.561767578125
      },
      {
          "date": "Aug 07",
          "Temperature": 28.443500518798828,
          "Humidity": 40.0,
          "Pressure": 1004.0573120117188
      },
      {
          "date": "Aug 07",
          "Temperature": 28.243499755859375,
          "Humidity": 40.0,
          "Pressure": 1004.1533813476562
      },
      {
          "date": "Aug 07",
          "Temperature": 26.993499755859375,
          "Humidity": 52.0,
          "Pressure": 1004.2307739257812
      },
      {
          "date": "Aug 07",
          "Temperature": 25.043498992919922,
          "Humidity": 63.0,
          "Pressure": 1004.6939086914062
      },
      {
          "date": "Aug 07",
          "Temperature": 24.0935001373291,
          "Humidity": 67.0,
          "Pressure": 1005.0751342773438
      },
      {
          "date": "Aug 07",
          "Temperature": 20.64349937438965,
          "Humidity": 89.0,
          "Pressure": 1005.510009765625
      },
      {
          "date": "Aug 07",
          "Temperature": 20.043498992919922,
          "Humidity": 88.0,
          "Pressure": 1006.2947387695312
      },
      {
          "date": "Aug 07",
          "Temperature": 19.8435001373291,
          "Humidity": 90.0,
          "Pressure": 1006.4898681640625
      },
      {
          "date": "Aug 08",
          "Temperature": 19.193500518798828,
          "Humidity": 90.0,
          "Pressure": 1006.2788696289062
      },
      {
          "date": "Aug 08",
          "Temperature": 18.64349937438965,
          "Humidity": 92.0,
          "Pressure": 1006.965087890625
      },
      {
          "date": "Aug 08",
          "Temperature": 18.0935001373291,
          "Humidity": 94.0,
          "Pressure": 1007.0543823242188
      },
      {
          "date": "Aug 08",
          "Temperature": 18.39349937438965,
          "Humidity": 93.0,
          "Pressure": 1007.2587280273438
      },
      {
          "date": "Aug 08",
          "Temperature": 18.3435001373291,
          "Humidity": 91.0,
          "Pressure": 1007.9539794921875
      },
      {
          "date": "Aug 08",
          "Temperature": 18.193500518798828,
          "Humidity": 86.0,
          "Pressure": 1008.0509643554688
      },
      {
          "date": "Aug 08",
          "Temperature": 18.743499755859375,
          "Humidity": 84.0,
          "Pressure": 1008.6578369140625
      },
      {
          "date": "Aug 08",
          "Temperature": 19.493499755859375,
          "Humidity": 79.0,
          "Pressure": 1009.1690673828125
      },
      {
          "date": "Aug 08",
          "Temperature": 20.443500518798828,
          "Humidity": 71.0,
          "Pressure": 1009.982177734375
      },
      {
          "date": "Aug 08",
          "Temperature": 21.443500518798828,
          "Humidity": 62.0,
          "Pressure": 1010.0006103515625
      },
      {
          "date": "Aug 08",
          "Temperature": 22.043498992919922,
          "Humidity": 54.0,
          "Pressure": 1009.8126831054688
      },
      {
          "date": "Aug 08",
          "Temperature": 22.39349937438965,
          "Humidity": 49.0,
          "Pressure": 1009.8190307617188
      },
      {
          "date": "Aug 08",
          "Temperature": 22.64349937438965,
          "Humidity": 50.0,
          "Pressure": 1010.32080078125
      },
      {
          "date": "Aug 08",
          "Temperature": 23.14349937438965,
          "Humidity": 43.0,
          "Pressure": 1010.131103515625
      },
      {
          "date": "Aug 08",
          "Temperature": 21.943500518798828,
          "Humidity": 47.0,
          "Pressure": 1010.3082275390625
      },
      {
          "date": "Aug 08",
          "Temperature": 22.543498992919922,
          "Humidity": 46.0,
          "Pressure": 1010.3189086914062
      },
      {
          "date": "Aug 08",
          "Temperature": 22.943500518798828,
          "Humidity": 45.0,
          "Pressure": 1009.7293701171875
      },
      {
          "date": "Aug 08",
          "Temperature": 22.443500518798828,
          "Humidity": 45.0,
          "Pressure": 1010.5162963867188
      },
      {
          "date": "Aug 08",
          "Temperature": 21.64349937438965,
          "Humidity": 51.0,
          "Pressure": 1010.4022827148438
      },
      {
          "date": "Aug 08",
          "Temperature": 20.14349937438965,
          "Humidity": 60.0,
          "Pressure": 1010.8719482421875
      },
      {
          "date": "Aug 08",
          "Temperature": 19.39349937438965,
          "Humidity": 64.0,
          "Pressure": 1011.1564331054688
      },
      {
          "date": "Aug 08",
          "Temperature": 17.5935001373291,
          "Humidity": 80.0,
          "Pressure": 1011.1228637695312
      },
      {
          "date": "Aug 08",
          "Temperature": 16.8435001373291,
          "Humidity": 79.0,
          "Pressure": 1011.0093994140625
      },
      {
          "date": "Aug 08",
          "Temperature": 16.243499755859375,
          "Humidity": 79.0,
          "Pressure": 1011.3958740234375
      },
      {
          "date": "Aug 09",
          "Temperature": 15.693499565124512,
          "Humidity": 83.0,
          "Pressure": 1011.3854370117188
      },
      {
          "date": "Aug 09",
          "Temperature": 15.293499946594238,
          "Humidity": 84.0,
          "Pressure": 1010.781005859375
      },
      {
          "date": "Aug 09",
          "Temperature": 14.943499565124512,
          "Humidity": 87.0,
          "Pressure": 1010.7744140625
      },
      {
          "date": "Aug 09",
          "Temperature": 14.893499374389648,
          "Humidity": 88.0,
          "Pressure": 1010.8729248046875
      },
      {
          "date": "Aug 09",
          "Temperature": 14.593500137329102,
          "Humidity": 89.0,
          "Pressure": 1010.2703857421875
      },
      {
          "date": "Aug 09",
          "Temperature": 15.243499755859375,
          "Humidity": 85.0,
          "Pressure": 1010.28271484375
      },
      {
          "date": "Aug 09",
          "Temperature": 17.14349937438965,
          "Humidity": 78.0,
          "Pressure": 1010.5174560546875
      },
      {
          "date": "Aug 09",
          "Temperature": 18.8435001373291,
          "Humidity": 73.0,
          "Pressure": 1010.151611328125
      },
      {
          "date": "Aug 09",
          "Temperature": 20.8435001373291,
          "Humidity": 66.0,
          "Pressure": 1010.2879028320312
      },
      {
          "date": "Aug 09",
          "Temperature": 23.14349937438965,
          "Humidity": 54.0,
          "Pressure": 1009.3353271484375
      },
      {
          "date": "Aug 09",
          "Temperature": 24.543498992919922,
          "Humidity": 46.0,
          "Pressure": 1008.8629760742188
      },
      {
          "date": "Aug 09",
          "Temperature": 24.3435001373291,
          "Humidity": 48.0,
          "Pressure": 1008.6605224609375
      },
      {
          "date": "Aug 09",
          "Temperature": 23.89349937438965,
          "Humidity": 54.0,
          "Pressure": 1008.8512573242188
      },
      {
          "date": "Aug 09",
          "Temperature": 23.493499755859375,
          "Humidity": 57.0,
          "Pressure": 1008.2474365234375
      },
      {
          "date": "Aug 09",
          "Temperature": 23.64349937438965,
          "Humidity": 58.0,
          "Pressure": 1007.6531372070312
      },
      {
          "date": "Aug 09",
          "Temperature": 22.0935001373291,
          "Humidity": 69.0,
          "Pressure": 1007.9237060546875
      },
      {
          "date": "Aug 09",
          "Temperature": 20.993499755859375,
          "Humidity": 80.0,
          "Pressure": 1008.5997924804688
      },
      {
          "date": "Aug 09",
          "Temperature": 21.043498992919922,
          "Humidity": 82.0,
          "Pressure": 1008.5012817382812
      },
      {
          "date": "Aug 09",
          "Temperature": 21.043498992919922,
          "Humidity": 87.0,
          "Pressure": 1008.7996826171875
      },
      {
          "date": "Aug 09",
          "Temperature": 20.14349937438965,
          "Humidity": 90.0,
          "Pressure": 1008.783203125
      },
      {
          "date": "Aug 09",
          "Temperature": 19.3435001373291,
          "Humidity": 91.0,
          "Pressure": 1009.3651123046875
      },
      {
          "date": "Aug 09",
          "Temperature": 18.5935001373291,
          "Humidity": 95.0,
          "Pressure": 1009.2517700195312
      },
      {
          "date": "Aug 09",
          "Temperature": 18.493499755859375,
          "Humidity": 95.0,
          "Pressure": 1010.2445068359375
      },
      {
          "date": "Aug 09",
          "Temperature": 18.293498992919922,
          "Humidity": 96.0,
          "Pressure": 1010.7379760742188
      },
      {
          "date": "Aug 10",
          "Temperature": 18.043498992919922,
          "Humidity": 99.0,
          "Pressure": 1011.4298095703125
      },
      {
          "date": "Aug 10",
          "Temperature": 17.693500518798828,
          "Humidity": 98.0,
          "Pressure": 1012.119384765625
      },
      {
          "date": "Aug 10",
          "Temperature": 16.89349937438965,
          "Humidity": 94.0,
          "Pressure": 1012.3033447265625
      },
      {
          "date": "Aug 10",
          "Temperature": 16.3435001373291,
          "Humidity": 93.0,
          "Pressure": 1012.6907348632812
      },
      {
          "date": "Aug 10",
          "Temperature": 15.593500137329102,
          "Humidity": 94.0,
          "Pressure": 1012.77587890625
      },
      {
          "date": "Aug 10",
          "Temperature": 15.743499755859375,
          "Humidity": 90.0,
          "Pressure": 1013.1766357421875
      },
      {
          "date": "Aug 10",
          "Temperature": 16.5935001373291,
          "Humidity": 81.0,
          "Pressure": 1014.3863525390625
      },
      {
          "date": "Aug 10",
          "Temperature": 18.39349937438965,
          "Humidity": 73.0,
          "Pressure": 1013.8232421875
      },
      {
          "date": "Aug 10",
          "Temperature": 20.14349937438965,
          "Humidity": 60.0,
          "Pressure": 1013.7564697265625
      },
      {
          "date": "Aug 10",
          "Temperature": 21.993499755859375,
          "Humidity": 53.0,
          "Pressure": 1013.4921264648438
      },
      {
          "date": "Aug 10",
          "Temperature": 23.243499755859375,
          "Humidity": 49.0,
          "Pressure": 1013.1167602539062
      },
      {
          "date": "Aug 10",
          "Temperature": 24.193500518798828,
          "Humidity": 50.0,
          "Pressure": 1013.3329467773438
      },
      {
          "date": "Aug 10",
          "Temperature": 24.943500518798828,
          "Humidity": 50.0,
          "Pressure": 1012.8492431640625
      },
      {
          "date": "Aug 10",
          "Temperature": 25.743499755859375,
          "Humidity": 44.0,
          "Pressure": 1012.2666625976562
      },
      {
          "date": "Aug 10",
          "Temperature": 26.0935001373291,
          "Humidity": 42.0,
          "Pressure": 1012.4716186523438
      },
      {
          "date": "Aug 10",
          "Temperature": 26.0935001373291,
          "Humidity": 44.0,
          "Pressure": 1012.1732177734375
      },
      {
          "date": "Aug 10",
          "Temperature": 25.5935001373291,
          "Humidity": 45.0,
          "Pressure": 1012.36328125
      },
      {
          "date": "Aug 10",
          "Temperature": 24.64349937438965,
          "Humidity": 46.0,
          "Pressure": 1013.0427856445312
      },
      {
          "date": "Aug 10",
          "Temperature": 23.493499755859375,
          "Humidity": 53.0,
          "Pressure": 1013.12158203125
      },
      {
          "date": "Aug 10",
          "Temperature": 21.5935001373291,
          "Humidity": 63.0,
          "Pressure": 1013.5843505859375
      },
      {
          "date": "Aug 10",
          "Temperature": 20.3435001373291,
          "Humidity": 71.0,
          "Pressure": 1013.6605834960938
      },
      {
          "date": "Aug 10",
          "Temperature": 19.543498992919922,
          "Humidity": 72.0,
          "Pressure": 1013.9443359375
      },
      {
          "date": "Aug 10",
          "Temperature": 18.993499755859375,
          "Humidity": 75.0,
          "Pressure": 1013.8346557617188
      },
      {
          "date": "Aug 10",
          "Temperature": 18.493499755859375,
          "Humidity": 78.0,
          "Pressure": 1014.3224487304688
      },
      {
          "date": "Aug 11",
          "Temperature": 18.8435001373291,
          "Humidity": 77.0,
          "Pressure": 1014.5280151367188
      },
      {
          "date": "Aug 11",
          "Temperature": 18.493499755859375,
          "Humidity": 79.0,
          "Pressure": 1014.2230224609375
      },
      {
          "date": "Aug 11",
          "Temperature": 18.543498992919922,
          "Humidity": 78.0,
          "Pressure": 1014.12451171875
      },
      {
          "date": "Aug 11",
          "Temperature": 18.943500518798828,
          "Humidity": 73.0,
          "Pressure": 1014.5299682617188
      },
      {
          "date": "Aug 11",
          "Temperature": 18.493499755859375,
          "Humidity": 76.0,
          "Pressure": 1015.3170776367188
      },
      {
          "date": "Aug 11",
          "Temperature": 18.193500518798828,
          "Humidity": 78.0,
          "Pressure": 1015.7095336914062
      },
      {
          "date": "Aug 11",
          "Temperature": 18.693500518798828,
          "Humidity": 76.0,
          "Pressure": 1016.1166381835938
      },
      {
          "date": "Aug 11",
          "Temperature": 19.493499755859375,
          "Humidity": 68.0,
          "Pressure": 1016.2310791015625
      },
      {
          "date": "Aug 11",
          "Temperature": 20.5935001373291,
          "Humidity": 63.0,
          "Pressure": 1016.8482055664062
      },
      {
          "date": "Aug 11",
          "Temperature": 21.943500518798828,
          "Humidity": 56.0,
          "Pressure": 1016.2763671875
      },
      {
          "date": "Aug 11",
          "Temperature": 22.943500518798828,
          "Humidity": 50.0,
          "Pressure": 1016.29443359375
      },
      {
          "date": "Aug 11",
          "Temperature": 23.943500518798828,
          "Humidity": 45.0,
          "Pressure": 1016.1137084960938
      },
      {
          "date": "Aug 11",
          "Temperature": 24.243499755859375,
          "Humidity": 43.0,
          "Pressure": 1015.4227905273438
      },
      {
          "date": "Aug 11",
          "Temperature": 24.293498992919922,
          "Humidity": 43.0,
          "Pressure": 1015.921142578125
      },
      {
          "date": "Aug 11",
          "Temperature": 24.993499755859375,
          "Humidity": 38.0,
          "Pressure": 1015.8341064453125
      },
      {
          "date": "Aug 11",
          "Temperature": 24.64349937438965,
          "Humidity": 40.0,
          "Pressure": 1015.231201171875
      },
      {
          "date": "Aug 11",
          "Temperature": 24.943500518798828,
          "Humidity": 38.0,
          "Pressure": 1014.8387451171875
      },
      {
          "date": "Aug 11",
          "Temperature": 24.0935001373291,
          "Humidity": 41.0,
          "Pressure": 1014.7239379882812
      },
      {
          "date": "Aug 11",
          "Temperature": 23.5935001373291,
          "Humidity": 45.0,
          "Pressure": 1014.416259765625
      },
      {
          "date": "Aug 11",
          "Temperature": 21.89349937438965,
          "Humidity": 53.0,
          "Pressure": 1014.5844116210938
      },
      {
          "date": "Aug 11",
          "Temperature": 20.5935001373291,
          "Humidity": 60.0,
          "Pressure": 1014.659912109375
      },
      {
          "date": "Aug 11",
          "Temperature": 18.743499755859375,
          "Humidity": 75.0,
          "Pressure": 1014.7251586914062
      },
      {
          "date": "Aug 11",
          "Temperature": 17.39349937438965,
          "Humidity": 76.0,
          "Pressure": 1014.6001586914062
      },
      {
          "date": "Aug 11",
          "Temperature": 16.64349937438965,
          "Humidity": 76.0,
          "Pressure": 1014.6856689453125
      },
      {
          "date": "Aug 12",
          "Temperature": 15.743499755859375,
          "Humidity": 81.0,
          "Pressure": 1014.66845703125
      },
      {
          "date": "Aug 12",
          "Temperature": 15.243499755859375,
          "Humidity": 81.0,
          "Pressure": 1014.260986328125
      },
      {
          "date": "Aug 12",
          "Temperature": 14.843500137329102,
          "Humidity": 82.0,
          "Pressure": 1013.955078125
      },
      {
          "date": "Aug 12",
          "Temperature": 14.693499565124512,
          "Humidity": 86.0,
          "Pressure": 1013.9522094726562
      },
      {
          "date": "Aug 12",
          "Temperature": 14.493499755859375,
          "Humidity": 86.0,
          "Pressure": 1013.3516235351562
      },
      {
          "date": "Aug 12",
          "Temperature": 14.543499946594238,
          "Humidity": 87.0,
          "Pressure": 1013.2531127929688
      },
      {
          "date": "Aug 12",
          "Temperature": 16.743499755859375,
          "Humidity": 75.0,
          "Pressure": 1013.0962524414062
      },
      {
          "date": "Aug 12",
          "Temperature": 18.8435001373291,
          "Humidity": 67.0,
          "Pressure": 1012.4393310546875
      },
      {
          "date": "Aug 12",
          "Temperature": 20.89349937438965,
          "Humidity": 60.0,
          "Pressure": 1012.2781982421875
      },
      {
          "date": "Aug 12",
          "Temperature": 23.243499755859375,
          "Humidity": 48.0,
          "Pressure": 1011.6246948242188
      },
      {
          "date": "Aug 12",
          "Temperature": 24.793498992919922,
          "Humidity": 43.0,
          "Pressure": 1011.0558471679688
      },
      {
          "date": "Aug 12",
          "Temperature": 25.743499755859375,
          "Humidity": 40.0,
          "Pressure": 1010.7745361328125
      },
      {
          "date": "Aug 12",
          "Temperature": 26.193500518798828,
          "Humidity": 38.0,
          "Pressure": 1010.7824096679688
      },
      {
          "date": "Aug 12",
          "Temperature": 26.8435001373291,
          "Humidity": 35.0,
          "Pressure": 1009.7990112304688
      },
      {
          "date": "Aug 12",
          "Temperature": 27.39349937438965,
          "Humidity": 33.0,
          "Pressure": 1009.5104370117188
      },
      {
          "date": "Aug 12",
          "Temperature": 27.5935001373291,
          "Humidity": 31.0,
          "Pressure": 1009.0164794921875
      },
      {
          "date": "Aug 12",
          "Temperature": 27.243499755859375,
          "Humidity": 37.0,
          "Pressure": 1008.21435546875
      },
      {
          "date": "Aug 12",
          "Temperature": 26.3435001373291,
          "Humidity": 37.0,
          "Pressure": 1008.1985473632812
      },
      {
          "date": "Aug 12",
          "Temperature": 25.5935001373291,
          "Humidity": 42.0,
          "Pressure": 1008.38427734375
      },
      {
          "date": "Aug 12",
          "Temperature": 23.39349937438965,
          "Humidity": 45.0,
          "Pressure": 1008.4444580078125
      },
      {
          "date": "Aug 12",
          "Temperature": 21.89349937438965,
          "Humidity": 36.0,
          "Pressure": 1008.6162719726562
      },
      {
          "date": "Aug 12",
          "Temperature": 20.193500518798828,
          "Humidity": 50.0,
          "Pressure": 1008.4857788085938
      },
      {
          "date": "Aug 12",
          "Temperature": 19.0935001373291,
          "Humidity": 68.0,
          "Pressure": 1009.0620727539062
      },
      {
          "date": "Aug 12",
          "Temperature": 18.193500518798828,
          "Humidity": 70.0,
          "Pressure": 1009.14501953125
      },
      {
          "date": "Aug 13",
          "Temperature": 17.5935001373291,
          "Humidity": 72.0,
          "Pressure": 1009.3325805664062
      },
      {
          "date": "Aug 13",
          "Temperature": 16.89349937438965,
          "Humidity": 75.0,
          "Pressure": 1009.4190063476562
      },
      {
          "date": "Aug 13",
          "Temperature": 16.39349937438965,
          "Humidity": 75.0,
          "Pressure": 1008.812744140625
      },
      {
          "date": "Aug 13",
          "Temperature": 16.0935001373291,
          "Humidity": 76.0,
          "Pressure": 1008.7075805664062
      },
      {
          "date": "Aug 13",
          "Temperature": 15.543499946594238,
          "Humidity": 78.0,
          "Pressure": 1008.9955444335938
      },
      {
          "date": "Aug 13",
          "Temperature": 15.593500137329102,
          "Humidity": 78.0,
          "Pressure": 1009.1954345703125
      },
      {
          "date": "Aug 13",
          "Temperature": 17.293498992919922,
          "Humidity": 72.0,
          "Pressure": 1009.0284423828125
      },
      {
          "date": "Aug 13",
          "Temperature": 19.243499755859375,
          "Humidity": 65.0,
          "Pressure": 1009.1642456054688
      },
      {
          "date": "Aug 13",
          "Temperature": 21.5935001373291,
          "Humidity": 57.0,
          "Pressure": 1009.2077026367188
      },
      {
          "date": "Aug 13",
          "Temperature": 24.243499755859375,
          "Humidity": 48.0,
          "Pressure": 1008.95703125
      },
      {
          "date": "Aug 13",
          "Temperature": 26.14349937438965,
          "Humidity": 43.0,
          "Pressure": 1008.1951293945312
      },
  
      {
          "date": "Aug 13",
          "Temperature": 21.493499755859375,
          "Humidity": 51.0,
          "Pressure": 1008.2111206054688
      },
      {
          "date": "Aug 13",
          "Temperature": 20.493499755859375,
          "Humidity": 52.0,
          "Pressure": 1007.9938354492188
      },
      {
          "date": "Aug 14",
          "Temperature": 19.793498992919922,
          "Humidity": 52.0,
          "Pressure": 1007.4835815429688
      },
      {
          "date": "Aug 14",
          "Temperature": 19.043498992919922,
          "Humidity": 56.0,
          "Pressure": 1006.8731079101562
      },
      {
          "date": "Aug 14",
          "Temperature": 18.5935001373291,
          "Humidity": 58.0,
          "Pressure": 1006.4668579101562
      },
      {
          "date": "Aug 14",
          "Temperature": 18.3435001373291,
          "Humidity": 60.0,
          "Pressure": 1006.5615234375
      },
      {
          "date": "Aug 14",
          "Temperature": 17.8435001373291,
          "Humidity": 61.0,
          "Pressure": 1006.3533935546875
      },
      {
          "date": "Aug 14",
          "Temperature": 17.743499755859375,
          "Humidity": 62.0,
          "Pressure": 1006.4511108398438
      },
      {
          "date": "Aug 14",
          "Temperature": 18.993499755859375,
          "Humidity": 60.0,
          "Pressure": 1006.8721923828125
      },
      {
          "date": "Aug 14",
          "Temperature": 20.8435001373291,
          "Humidity": 56.0,
          "Pressure": 1006.70703125
      },
      {
          "date": "Aug 14",
          "Temperature": 23.0935001373291,
          "Humidity": 52.0,
          "Pressure": 1007.14599609375
      },
      {
          "date": "Aug 14",
          "Temperature": 25.693500518798828,
          "Humidity": 48.0,
          "Pressure": 1006.297119140625
      },
      {
          "date": "Aug 14",
          "Temperature": 27.943500518798828,
          "Humidity": 44.0,
          "Pressure": 1006.1376342773438
      },
      {
          "date": "Aug 14",
          "Temperature": 29.89349937438965,
          "Humidity": 39.0,
          "Pressure": 1005.6739501953125
      },
      {
          "date": "Aug 14",
          "Temperature": 30.793498992919922,
          "Humidity": 40.0,
          "Pressure": 1005.5899658203125
      },
      {
          "date": "Aug 14",
          "Temperature": 32.14350128173828,
          "Humidity": 36.0,
          "Pressure": 1005.7124633789062
      },
      {
          "date": "Aug 14",
          "Temperature": 32.64350128173828,
          "Humidity": 34.0,
          "Pressure": 1005.52197265625
      },
      {
          "date": "Aug 14",
          "Temperature": 32.29349899291992,
          "Humidity": 34.0,
          "Pressure": 1004.7201538085938
      },
      {
          "date": "Aug 14",
          "Temperature": 31.89349937438965,
          "Humidity": 33.0,
          "Pressure": 1004.7131958007812
      },
      {
          "date": "Aug 14",
          "Temperature": 30.493499755859375,
          "Humidity": 37.0,
          "Pressure": 1005.6844482421875
      },
      {
          "date": "Aug 14",
          "Temperature": 24.64349937438965,
          "Humidity": 73.0,
          "Pressure": 1006.77587890625
      },
      {
          "date": "Aug 14",
          "Temperature": 24.693500518798828,
          "Humidity": 74.0,
          "Pressure": 1006.6774291992188
      },
      {
          "date": "Aug 14",
          "Temperature": 23.943500518798828,
          "Humidity": 80.0,
          "Pressure": 1006.9622192382812
      },
      {
          "date": "Aug 14",
          "Temperature": 22.993499755859375,
          "Humidity": 89.0,
          "Pressure": 1007.4425048828125
      },
      {
          "date": "Aug 14",
          "Temperature": 22.5935001373291,
          "Humidity": 93.0,
          "Pressure": 1007.5347290039062
      },
      {
          "date": "Aug 14",
          "Temperature": 22.243499755859375,
          "Humidity": 93.0,
          "Pressure": 1007.1304931640625
      }
  
  ]
  
// const weatherdata=data

  export function WeatherReport() {
    return (
      <AreaChart
        className="h-80"
        data={weatherdata}
        index="date"
  
        categories={["Temperature", "Humidity"]}
        colors={["blue-700", "fuchsia-700", "#f0652f"]}
        yAxisWidth={30}
      />
    );
  }
  
  const chartdata3 = [
    {
      name: "Topic 1",
      "Temperature": 890,
      "Humidity": 338,
      "Moisture": 538,
      "Fertilizer": 396,
      // "Group E": 138,
      // "Group F": 436,
    },
    {
      name: "Topic 2",
      "Temperature": 289,
      "Humidity": 233,
      "Moisture": 253,
      "Fertilizer": 333,
      // "Group E": 133,
      // "Group F": 533,
    },
    {
      name: "Topic 3",
      "Temperature": 380,
      "Humidity": 535,
      "Moisture": 352,
      "Fertilizer": 718,
      // "Group E": 539,
      // "Group F": 234,
    },
    {
      name: "Topic 4",
      "Temperature": 90,
      "Humidity": 98,
      "Moisture": 28,
      "Fertilizer": 33,
      // "Group E": 61,
      // "Group F": 53,
    },
  ];
  const dataFormatter1 = (number) =>
    Intl.NumberFormat("us").format(number).toString();
  
  export function BarChartSoil() {
    return (
      <>
        <h3 className="text-lg font-medium text-tremor-content-strong dark:text-dark-tremor-content-strong pt-3 pl-1">
          Soil Condition Monitering
        </h3>
        <BarChart
          className="mt-6"
          data={chartdata3}
          index="name"
          categories={[
            "Temperature",
            "Humidity",
            "Moisture",
            // "Fertilizer",
            // "Group E",
            // "Group F",
          ]}
          colors={["blue", "teal", "amber", "rose", "indigo", "emerald"]}
          valueFormatter={dataFormatter1}
          yAxisWidth={48}
        />
      </>
    );
  }
  
  const datahero = [
    {
      name: "Urea",
      value: 38,
    },
    {
      name: "D A P",
      value: 24,
    },
    { 
      name: "Potassium Sulphate",
      value: 20,
    },
    {
      name: "Phosphate",
      value: 5,
    },
    {
      name: "Ammonuium nitrate",
      value: 13,
    },
    // {
    //   name: "",
    //   value: 1398,
    // },
  ];
  
  const dataFormatter2 = (number) =>
    ` ${Intl.NumberFormat("us").format(number).toString()} %`;
  
  export const Fertilizers = () => (
    <>
      <div className="mx-auto space-y-12">
        <div className="space-y-3">
          <span className="text-center block font-mono text-tremor-default text-tremor-content dark:text-dark-tremor-content pt-3">
            Percentage of fertilizers used !
          </span>
          <div className="flex justify-center">
            {/* <DonutChart
              data={datahero}
              variant="donut"
              valueFormatter={dataFormatter2}
              onValueChange={(v) => console.log(v)}
            /> */}
          </div>
        </div>
        <div className="space-y-3">
          <span className="text-center block font-mono text-tremor-default text-tremor-content dark:text-dark-tremor-content">
          </span>
          <div className="flex justify-center pb-12">
            <DonutChart
              data={datahero}
              variant="pie"
              valueFormatter={dataFormatter2}
              onValueChange={(v) => console.log(v)}
            />
          </div>
        </div>
      </div>
    </>
  );
  
  const chartdata5 = [
    {
      plant: "Septoria",
      "Life expectancy": 76.3,
      spreadtime: 13467.1236,
      spread: 435,
    },
    {
      plant: "Blight",
      "Life expectancy": 82.8,
      spreadtime: 56554.3876,
      spread: 587,
    },
    {
      Plant: "Ergot",
      "Life expectancy": 81.5,
      spreadtime: 43665.947,
      spread: 445,
    },
    {
      Plant: "Eyespot",
      "Life expectancy": 75,
      spreadtime: 8757.2622,
      spread: 165,
    },
    {
      Plant: "Foliar",
      "Life expectancy": 77.6,
      spreadtime: 1774.9291,
      spread: 89,
    },
    {
      Plant: "Mildew",
      "Life expectancy": 64.8,
      spreadtime: 645.4637627,
      spread: 187,
    },
    {
      Plant: "Karnal bunt",
      "Life expectancy": 81,
      spreadtime: 41176.88158,
      spread: 260,
    },
    {
      Plant: "Snow Mold",
      "Life expectancy": 74.6,
      spreadtime: 2326.15856,
      spread: 150,
    }
  ];
  export function Imapacts() {
    return (
      <Card style={{ background: "white" }}>
        {/* <p
          className="text-lg  text-tremor-content-strong dark:text-dark-tremor-content-strong font-semibold"
          style={{ color: "gray" }}
        >
          Life expectancy vs. GDP per capita
        </p>
        <p className="text-tremor-default text-tremor-content dark:text-dark-tremor-content leading-6">
          As of 2015. Source: Our World in Data{" "}
        </p> */}
        <ScatterChart
          className="-ml-2 mt-6 h-80"
          yAxisWidth={50}
          data={chartdata5}
          category="Plant"
          x="spreadtime"
          y="Life expectancy"
          size="spread"
          showOpacity={true}
          minYValue={40}
          xAxisTitle="GDP per Capita"
          yAxisTitle="Life Expectancy (Years)"
          valueFormatter={{
            x: (amount) => `${(amount / 1000)}%`,
            y: (lifeExp) => `${lifeExp}%`,
            size: (population) => `${(population / 1000000).toFixed(1)}`,
          }}
          enableLegendSlider
        />
        <div className="flex justify-center pt-2">
          <p className="font-montserrat text-gray-600 font-xl">Field Affected / Time to Solve </p>
          </div>
      </Card>
    );
  }
  
  const chartdata4 = [
    {
      name: "AUG 1",
      "Number of threatened species": 2488,
    },
    {
      name: "Birds",
      "Number of threatened species": 1445,
    },
    {
      name: "Crustaceans",
      "Number of threatened species": 743,
    },
    {
      name: "Ferns",
      "Number of threatened species": 281,
    },
    {
      name: "Arachnids",
      "Number of threatened species": 251,
    },
    {
      name: "Corals",
      "Number of threatened species": 232,
    },
    {
      name: "Algae",
      "Number of threatened species": 98,
    },
  ];
  
  const dataFormatter = (number) =>
    Intl.NumberFormat("₹").format(number).toString();
  
  export const WaterMonitering = () => (
    <BarChart
      data={chartdata4}
      index="name"
      categories={["Number of threatened species"]}
      colors={["blue"]}
      valueFormatter={dataFormatter}
      yAxisWidth={48}
      onValueChange={(v) => console.log(v)}
    />
  );
  
  const chartdata = [
    {
      date: "Jan 22",
      "Market Value":140,
      "Predicted value": 135,
    },
    {
      date: "Feb 22",
      "Market Value":160,
      "Predicted value": 150,
    },
    {
      date: "Mar 22",
      "Market Value": 160,
      "Predicted value": 150,
    },
    {
      date: "Apr 22",
      "Market Value": 160,
      "Predicted value": 158,
    },
    {
      date: "May 22",
      "Market Value": 148,
      "Predicted value": 139,
    },
    {
      us:100,
      date: "Jun 22",
      "Market Value": 170,
      "Predicted value": 160,
    },
    {
      date: "Jul 22",
      "Market Value": 120,
      "Predicted value": 130,
    },
    {
      date: "Aug 22",
      "Market Value": 165,
      "Predicted value": 160,
    },
    {
      date: "Sep 22",
      "Market Value": 150,
      "Predicted value": 140,
    },
    {
      date: "Oct 22",
      "Market Value": 100,
      "Predicted value": 90,
    },
    {
      date: "Nov 22",
      "Market Value": 130,
      "Predicted value": 150,
    },
    {
      date: "Dec 22",
      "Market Value": 125,
      "Predicted value": 130,
    },
  ];
  
  const valueFormatter = function (number) {
    return "₹"  + new Intl.NumberFormat("us").format(number).toString();
    // return "₹ 20" 
  };
  
  export function MarketValue() {
    return (
      <>
        <h3 className="text-lg font-medium text-tremor-content-strong dark:text-dark-tremor-content-strong">
          Newsletter revenue over time
        </h3>
        <LineChart
          className="mt-4 h-72"
          data={chartdata}
          index="date"
          yAxisWidth={75}
          categories={["Market Value","Predicted value"]}
          // customTooltip={customTooltip}
          colors={["indigo", "cyan"]}
          valueFormatter={valueFormatter}
        />
      </>
    );
  }
  
  const data = [
    {
      name: "Twitter",
      value: 456,
      href: "https://twitter.com/tremorlabs",
      icon: function TwitterIcon() {
        return (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="mr-2.5 fill-blue-500"
            viewBox="0 0 24 24"
            width="20"
            height="20"
          >
            <path fill="none" d="M0 0h24v24H0z" />
            <path d="M22.162 5.656a8.384 8.384 0 0 1-2.402.658A4.196 4.196 0 0 0 21.6 4c-.82.488-1.719.83-2.656 1.015a4.182 4.182 0 0 0-7.126 3.814 11.874 11.874 0 0 1-8.62-4.37 4.168 4.168 0 0 0-.566 2.103c0 1.45.738 2.731 1.86 3.481a4.168 4.168 0 0 1-1.894-.523v.052a4.185 4.185 0 0 0 3.355 4.101 4.21 4.21 0 0 1-1.89.072A4.185 4.185 0 0 0 7.97 16.65a8.394 8.394 0 0 1-6.191 1.732 11.83 11.83 0 0 0 6.41 1.88c7.693 0 11.9-6.373 11.9-11.9 0-.18-.005-.362-.013-.54a8.496 8.496 0 0 0 2.087-2.165z" />
          </svg>
        );
      },
    },
    {
      name: "Google",
      value: 351,
      href: "https://google.com",
      icon: function GoogleIcon() {
        return (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="mr-2.5 fill-slate-500"
            viewBox="0 0 24 24"
            width="20"
            height="20"
          >
            <path fill="none" d="M0 0h24v24H0z" />
            <path d="M3.064 7.51A9.996 9.996 0 0 1 12 2c2.695 0 4.959.99 6.69 2.605l-2.867 2.868C14.786 6.482 13.468 5.977 12 5.977c-2.605 0-4.81 1.76-5.595 4.123-.2.6-.314 1.24-.314 1.9 0 .66.114 1.3.314 1.9.786 2.364 2.99 4.123 5.595 4.123 1.345 0 2.49-.355 3.386-.955a4.6 4.6 0 0 0 1.996-3.018H12v-3.868h9.418c.118.654.182 1.336.182 2.045 0 3.046-1.09 5.61-2.982 7.35C16.964 21.105 14.7 22 12 22A9.996 9.996 0 0 1 2 12c0-1.614.386-3.14 1.064-4.49z" />
          </svg>
        );
      },
    },
    {
      name: "GitHub",
      value: 271,
      href: "https://github.com/tremorlabs/tremor",
      icon: function GitHubIcon() {
        return (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="mr-2.5 fill-slate-900"
            viewBox="0 0 24 24"
            width="20"
            height="20"
          >
            <path fill="none" d="M0 0h24v24H0z" />
            <path d="M12 2C6.475 2 2 6.475 2 12a9.994 9.994 0 0 0 6.838 9.488c.5.087.687-.213.687-.476 0-.237-.013-1.024-.013-1.862-2.512.463-3.162-.612-3.362-1.175-.113-.288-.6-1.175-1.025-1.413-.35-.187-.85-.65-.013-.662.788-.013 1.35.725 1.538 1.025.9 1.512 2.338 1.087 2.912.825.088-.65.35-1.087.638-1.337-2.225-.25-4.55-1.113-4.55-4.938 0-1.088.387-1.987 1.025-2.688-.1-.25-.45-1.275.1-2.65 0 0 .837-.262 2.75 1.026a9.28 9.28 0 0 1 2.5-.338c.85 0 1.7.112 2.5.337 1.912-1.3 2.75-1.024 2.75-1.024.55 1.375.2 2.4.1 2.65.637.7 1.025 1.587 1.025 2.687 0 3.838-2.337 4.688-4.562 4.938.362.312.675.912.675 1.85 0 1.337-.013 2.412-.013 2.75 0 .262.188.574.688.474A10.016 10.016 0 0 0 22 12c0-5.525-4.475-10-10-10z" />
          </svg>
        );
      },
    },
    {
      name: "Reddit",
      value: 191,
      href: "https://reddit.com",
      icon: function RedditIcon() {
        return (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="mr-2.5 fill-orange-500"
            viewBox="0 0 24 24"
            width="20"
            height="20"
          >
            <path fill="none" d="M0 0h24v24H0z" />
            <path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10zm6.67-10a1.46 1.46 0 0 0-2.47-1 7.12 7.12 0 0 0-3.85-1.23L13 6.65l2.14.45a1 1 0 1 0 .13-.61L12.82 6a.31.31 0 0 0-.37.24l-.74 3.47a7.14 7.14 0 0 0-3.9 1.23 1.46 1.46 0 1 0-1.61 2.39 2.87 2.87 0 0 0 0 .44c0 2.24 2.61 4.06 5.83 4.06s5.83-1.82 5.83-4.06a2.87 2.87 0 0 0 0-.44 1.46 1.46 0 0 0 .81-1.33zm-10 1a1 1 0 1 1 2 0 1 1 0 0 1-2 0zm5.81 2.75a3.84 3.84 0 0 1-2.47.77 3.84 3.84 0 0 1-2.47-.77.27.27 0 0 1 .38-.38A3.27 3.27 0 0 0 12 16a3.28 3.28 0 0 0 2.09-.61.28.28 0 1 1 .39.4v-.04zm-.18-1.71a1 1 0 1 1 1-1 1 1 0 0 1-1.01 1.04l.01-.04z" />
          </svg>
        );
      },
    },
    {
      name: "Youtube",
      value: 91,
      href: "https://www.youtube.com/@tremorlabs3079",
      icon: function YouTubeIcon() {
        return (
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="mr-2.5 fill-red-500"
            viewBox="0 0 24 24"
            width="20"
            height="20"
          >
            <path fill="none" d="M0 0h24v24H0z" />
            <path d="M21.543 6.498C22 8.28 22 12 22 12s0 3.72-.457 5.502c-.254.985-.997 1.76-1.938 2.022C17.896 20 12 20 12 20s-5.893 0-7.605-.476c-.945-.266-1.687-1.04-1.938-2.022C2 15.72 2 12 2 12s0-3.72.457-5.502c.254-.985.997-1.76 1.938-2.022C6.107 4 12 4 12 4s5.896 0 7.605.476c.945.266 1.687 1.04 1.938 2.022zM10 15.5l6-3.5-6-3.5v7z" />
          </svg>
        );
      },
    },
  ];
  
  export function Yield() {
    return (
      <Card className="mx-auto max-w-lg" style={{ background: "white" }}>
        <h3
          className="text-tremor-title text-tremor-content-strong dark:text-dark-tremor-content-strong font-medium"
          style={{ color: "black" }}
        >
          Website Analytics
        </h3>
        <p className="mt-4 text-tremor-default flex items-center justify-between text-tremor-content dark:text-dark-tremor-content">
          <span>Source</span>
          <span>Views</span>
        </p>
        <BarList data={data} className="mt-2" />
      </Card>
    );
  }