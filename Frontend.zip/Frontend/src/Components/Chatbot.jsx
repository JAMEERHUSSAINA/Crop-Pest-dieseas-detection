import { useState, useEffect, useRef } from 'react';
import { FaPaperPlane, FaMicrophone } from "react-icons/fa";
import { GoogleGenerativeAI } from "@google/generative-ai";
import Loading from "./Loading"; // Assuming you have your Loading component here

const SpeechRecognition =
  window.SpeechRecognition || window.webkitSpeechRecognition;
const recognition = SpeechRecognition ? new SpeechRecognition() : null;

const Chatbot = () => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [language, setLanguage] = useState("en"); // Default to English
  const [isRecognizing, setIsRecognizing] = useState(false); // Manage recognition state
  const messagesEndRef = useRef(null);

  // Initialize your Gemini API
  const genAI = new GoogleGenerativeAI("AIzaSyCwpwZFMJsk6UBhgM_nxowK6a3NvvcOxQA");
  const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

  // Check if recognition is supported and set language
  if (recognition) {
    recognition.lang = language === "ta" ? "ta-IN" : "en-US";
  }

  const handleSendMessage = async () => {
    if (input.trim() === "") return;

    setMessages([...messages, { text: input, sender: "user" }]);
    setInput("");
    setIsLoading(true);

    try {
      const result = await model.generateContent(input);
      const response = await result.response;

      let botMessage = response.text();

      // Preprocess the bot message to remove asterisks and other unwanted symbols
      botMessage = botMessage.replace(/[*]/g, ""); // Remove asterisks

      setMessages((prevMessages) => [
        ...prevMessages,
        { text: botMessage, sender: "bot" },
      ]);

      const voiceLang = language === "ta" ? "Tamil Female" : "UK English Female";
      window.responsiveVoice.speak(botMessage, voiceLang);
    } catch (error) {
      console.error("Error sending message", error);
      setMessages((prevMessages) => [
        ...prevMessages,
        { text: "Sorry, there was an error.", sender: "bot" },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleVoiceInput = () => {
    if (!recognition) {
      alert("Speech recognition is not supported in this browser.");
      return;
    }

    if (isRecognizing) {
      alert("Speech recognition is already active.");
      return;
    }

    recognition.start();
    setIsRecognizing(true);

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      setInput(transcript);
      handleSendMessage();
    };

    recognition.onend = () => {
      setIsRecognizing(false);
    };

    recognition.onerror = (event) => {
      console.error('Speech recognition error detected: ', event.error);
      if (event.error === 'not-allowed') {
        alert('Microphone access is not allowed. Please enable it in your browser settings.');
      } else if (event.error === 'network') {
        alert('Network error occurred. Please check your connection.');
      } else {
        alert(`Error occurred: ${event.error}`);
      }
      setIsRecognizing(false);
    };
  };

  // Scroll to the bottom whenever messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  return (
    <div className="flex flex-col h-screen w-screen bg-green-100">
      {/* Header */}
      <div className="bg-green-500 text-white p-4 mt-14">
        <h1 className="text-lg font-semibold">I am your AI assistant</h1>
        <p className="text-sm">
          Ask me anything! I can answer.
        </p>
      </div>

      {/* Language Selection */}
      <div className="p-2 flex justify-end bg-white">
        <select
          value={language}
          onChange={(e) => setLanguage(e.target.value)}
          className="border p-1 rounded-md"
        >
          <option value="en">English</option>
          <option value="ta">Tamil</option>
        </select>
      </div>

      {/* Messages Area */}
      <div className="flex-1 p-4 overflow-y-auto bg-gray-100">
        {messages.map((message, index) => (
          <div
            key={index}
            className={`mb-4 p-2 rounded-lg shadow-md break-words ${
              message.sender === "user"
                ? "bg-green-500 text-white ml-auto text-left"
                : "bg-white text-black"
            }`}
            style={{ display: 'block', width: 'auto', maxWidth: '75%' }}
          >
            {message.text}
          </div>
        ))}
        <div ref={messagesEndRef}></div>
        <Loading isLoading={isLoading} />
      </div>

      {/* Input and Send Button */}
      <div className="p-4 bg-white flex items-center border-t">
        <input
          type="text"
          className="flex-1 p-2 border rounded-lg shadow-sm"
          placeholder="Type your message"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
          disabled={isLoading}
        />
        <button
          onClick={handleSendMessage}
          className="ml-2 p-3 text-white bg-green-500 rounded-full shadow-sm"
          disabled={isLoading}
        >
          <FaPaperPlane className="text-lg" />
        </button>
        <button
          onClick={handleVoiceInput}
          className="ml-2 p-3 text-white bg-green-500 rounded-full shadow-sm"
          disabled={!recognition || isRecognizing}
        >
          <FaMicrophone className="text-lg" />
        </button>
      </div>
    </div>
  );
};

export default Chatbot;
