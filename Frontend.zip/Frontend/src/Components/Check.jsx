// // import React, { useState, useEffect } from 'react';
// // import CameraUpload from './CameraUpload';
// // import { useImage } from './ImageContext';
// // import axios from 'axios';

// // const Prediction = ({ onViewMore, setResponse }) => {
// //   const { image, userId } = useImage();
// //   const [toggle, setToggle] = useState(1);
// //   const [response, setLocalResponse] = useState(null);
// //   const [loading, setLoading] = useState(false);

// //   useEffect(() => {
// //     if (image) {
// //       setLoading(true);
// //       const endpoint = toggle === 1 ? 'http://127.0.0.1:5000/detect_disease' : 'http://127.0.0.1:5000/detect_pests';
      
// //       const formData = new FormData();
// //       formData.append('image', image);

// //       axios.post(endpoint, formData, {
// //         headers: {
// //           'Content-Type': 'multipart/form-data'
// //         }
// //       })
// //       .then(response => {
// //         const data = toggle === 1 ? response.data.diseases_detected : response.data.pests_detected;
// //         setLocalResponse(data);
// //         setResponse(data); // Pass the response to parent component
// //         setLoading(false);
// //       })
// //       .catch(error => {
// //         console.error("Error detecting:", error);
// //         setLoading(false);
// //       });
// //     }
// //   }, [image, toggle]);

// //   useEffect(() => {
// //     if (image && response && userId) {
// //       const reader = new FileReader();
// //       reader.readAsDataURL(image);
      
// //       reader.onloadend = () => {
// //         const base64Image = reader.result;

// //         const newEntry = {
// //           imageId: Date.now(),
// //           image: base64Image,
// //           disease: response,
// //         };

// //         axios.get(`http://localhost:4000/users/${userId}`)
// //           .then(res => {
// //             const userData = res.data;
// //             let updatedHistory = Array.isArray(userData.history) ? userData.history : [];
// //             const imageExists = updatedHistory.some(entry => entry.image === base64Image);

// //             if (!imageExists) {
// //               updatedHistory = [...updatedHistory, newEntry];
// //             } else {
// //               console.log("Image already exists in history");
// //             }

// //             return axios.patch(`http://localhost:4000/users/${userId}`, { history: updatedHistory });
// //           })
// //           .then(() => {
// //             console.log("Image data saved successfully");
// //           })
// //           .catch(err => {
// //             if (err.response && err.response.status === 404) {
// //               console.error("User not found:", err);
// //             } else {
// //               console.error("Error saving image data:", err);
// //             }
// //           });
// //       };
// //     }
// //   }, [image, response, userId]);

// //   return (
// //     <div className="min-h-screen bg-green-50">
// //       <header className="text-black py-6 pt-20">
// //         <h1 className="text-3xl font-bold text-center font-montserrat">
// //           Plant Disease Detection
// //         </h1>
// //         <p className="text-center mt-2 text-green-600">
// //           Identify and manage plant diseases effectively
// //         </p>
// //       </header>
// //       <div className="pt-10 p-6">
// //         <div className="flex justify-center mb-8">
// //           <div className="flex space-x-0">
// //             <button
// //               onClick={() => setToggle(1)}
// //               className={`px-6 py-2 rounded-l border border-green-600 ${
// //                 toggle === 1 ? 'bg-green-600 text-white' : 'bg-white text-green-600'
// //               } transition-all`}
// //             >
// //               Disease prediction
// //             </button>
// //             <button
// //               onClick={() => setToggle(2)}
// //               className={`px-6 py-2 rounded-r border border-green-600 ${
// //                 toggle === 2 ? 'bg-green-600 text-white' : 'bg-white text-green-600'
// //               } transition-all`}
// //             >
// //               Pest prediction
// //             </button>
// //           </div>
// //         </div>
// //         <div className="relative flex justify-center mb-8">
// //           {toggle === 1 && (
// //             <div className="p-4 border border-dashed border-green-300 rounded-lg w-96 h-96 bg-white shadow-lg">
// //               <CameraUpload />
// //             </div>
// //           )}
// //           {toggle === 2 && (
// //             <div className="p-4 border border-dashed border-green-300 rounded-lg w-96 h-96 bg-white shadow-lg">
// //               <CameraUpload />
// //             </div>
// //           )}
// //         </div>
// //         {loading && (
// //           <div className="bg-green-100 p-6 rounded-lg shadow-md border border-green-300 text-center">
// //             <p>Loading response...</p>
// //           </div>
// //         )}
// //         {response && !loading && (
// //           <div className="bg-white p-6 rounded-lg mt-6 shadow-lg border border-green-300">
// //             <h2 className="text-xl font-bold mb-4 text-green-800">
// //               Detected Diseases
// //             </h2>
// //             {response.map((disease, index) => (
// //               <div key={index} className="mb-6">
// //                 <h3 className="text-lg font-semibold text-green-600">{disease.disease}</h3>
// //                 <p className="text-gray-700 mb-2"><strong>Solution:</strong> {disease.solution}</p>
// //               </div>
// //             ))}
// //             <div className="flex justify-end mt-6">
// //               <button onClick={onViewMore} className="text-green-600 hover:underline font-bold text-lg">
// //                 View More
// //               </button>
// //             </div>
// //           </div>
// //         )}
// //       </div>
// //     </div>
// //   );
// // };

// // export default Prediction;
// import React, { useState, useEffect } from 'react';
// import CameraUpload from './CameraUpload';
// import { useImage } from './ImageContext';
// import axios from 'axios';
// import { useSpeechSynthesis } from 'react-speech-kit';

// const Check = ({ onViewMore, setResponse }) => {
//   const { image, userId } = useImage();
//   const [toggle, setToggle] = useState(1);
//   const [response, setLocalResponse] = useState(null);
//   const [loading, setLoading] = useState(false);
//   const [language, setLanguage] = useState('en'); // Default language is English
//   const { speak } = useSpeechSynthesis();

//   useEffect(() => {
//     if (image) {
//       setLoading(true);
//       const endpoint = toggle === 1 ? 'http://127.0.0.1:5000/detect_disease' : 'http://127.0.0.1:5000/detect_pests';

//       const formData = new FormData();
//       formData.append('image', image);

//       axios.post(endpoint, formData, {
//         headers: {
//           'Content-Type': 'multipart/form-data'
//         }
//       })
//       .then(response => {
//         const data = toggle === 1 ? response.data.diseases_detected : response.data.pests_detected;

//         // Translate data if language is Tamil
//         if (language === 'ta') {
//           const translatedData = data.map(async disease => {
//             const translatedDisease = await translateText(disease.disease, 'ta');
//             const translatedSolution = await translateText(disease.solution, 'ta');
//             return { disease: translatedDisease, solution: translatedSolution };
//           });
//           Promise.all(translatedData).then(finalData => {
//             setLocalResponse(finalData);
//             setResponse(finalData);
//             setLoading(false);
//           });
//         } else {
//           setLocalResponse(data);
//           setResponse(data);
//           setLoading(false);
//         }
//       })
//       .catch(error => {
//         console.error("Error detecting:", error);
//         setLoading(false);
//       });
//     }
//   }, [image, toggle, language]);

//   // UseEffect to save image and response to user's history
//   useEffect(() => {
//     if (image && response && userId) {
//       const reader = new FileReader();
//       reader.readAsDataURL(image);
  
//       reader.onloadend = () => {
//         const base64Image = reader.result;
  
//         const newEntry = {
//           imageId: Date.now(),
//           image: base64Image,
//           disease: response,
//         };
  
//         axios.get(`http://localhost:4000/users/${userId}`)
//           .then(res => {
//             const userData = res.data;
//             let updatedHistory = Array.isArray(userData.history) ? userData.history : [];
//             const imageExists = updatedHistory.some(entry => entry.image === base64Image);
  
//             if (!imageExists) {
//               updatedHistory = [...updatedHistory, newEntry];
//             } else {
//               console.log("Image already exists in history");
//             }
  
//             return axios.patch(`http://localhost:4000/users/${userId}`, { history: updatedHistory });
//           })
//           .then(() => {
//             console.log("Image data saved successfully");
//           })
//           .catch(err => {
//             if (err.response && err.response.status === 404) {
//               console.error("User not found:", err);
//               // Optionally handle user creation or display a message
//               // For example, you could create a new user here
//               // axios.post('http://localhost:4000/users', { id: userId, history: [newEntry] });
//             } else {
//               console.error("Error saving image data:", err);
//             }
//           });
//       };
//     }
//   }, [image, response, userId]);
  
//   const translateText = async (text, targetLang) => {
//     try {
//       const response = await axios.post(
//         'https://libretranslate.com/translate',
//         {
//           q: text,
//           source: 'en', // Assuming source language is English
//           target: targetLang
//         },
//         {
//           headers: { 'Content-Type': 'application/json' }
//         }
//       );
//       return response.data.translatedText;
//     } catch (error) {
//       console.error("Translation error:", error);
//       return text; // Fallback to original text if translation fails
//     }
//   }

//   const handleSpeak = (text) => {
//     speak({ text, lang: language === 'ta' ? 'ta-IN' : 'en-US' });
//   };

//   return (
//     <div className="min-h-screen bg-green-50">
//       <header className="text-black py-6 pt-20">
//         <h1 className="text-3xl font-bold text-center font-montserrat">
//           Plant Disease Detection
//         </h1>
//         <p className="text-center mt-2 text-green-600">
//           Identify and manage plant diseases effectively
//         </p>
//         <div className="flex justify-center mt-4">
//           <label className="mr-2 text-lg">Language:</label>
//           <select
//             value={language}
//             onChange={(e) => setLanguage(e.target.value)}
//             className="px-3 py-1 border border-green-600 rounded"
//           >
//             <option value="en">English</option>
//             <option value="ta">Tamil</option>
//           </select>
//         </div>
//       </header>
//       <div className="pt-10 p-6">
//         <div className="flex justify-center mb-8">
//           <div className="flex space-x-0">
//             <button
//               onClick={() => setToggle(1)}
//               className={`px-6 py-2 rounded-l border border-green-600 ${
//                 toggle === 1 ? 'bg-green-600 text-white' : 'bg-white text-green-600'
//               } transition-all`}
//             >
//               Disease prediction
//             </button>
//             <button
//               onClick={() => setToggle(2)}
//               className={`px-6 py-2 rounded-r border border-green-600 ${
//                 toggle === 2 ? 'bg-green-600 text-white' : 'bg-white text-green-600'
//               } transition-all`}
//             >
//               Pest prediction
//             </button>
//           </div>
//         </div>
//         <div className="relative flex justify-center mb-9">
//           <div className="p-4 border border-dashed border-green-300 rounded-lg w-96 h-96 bg-white shadow-lg">
//             <CameraUpload />
//           </div>
//         </div>
//         {loading && (
//           <div className="bg-green-100 p-6 rounded-lg shadow-md border border-green-300 text-center">
//             <p>Loading response...</p>
//           </div>
//         )}
//         {response && !loading && (
//           <div className="bg-white p-6 rounded-lg mt-6 shadow-lg border border-green-300">
//             <h2 className="text-xl font-bold mb-4 text-green-800">
//               Detected Diseases
//             </h2>
//             {response.map((disease, index) => (
//               <div key={index} className="mb-6">
//                 <h3 className="text-lg font-semibold text-green-600">{disease.disease}</h3>
//                 <p className="text-gray-700 mb-2"><strong>Solution:</strong> {disease.solution}</p>
//                 <button onClick={() => handleSpeak(`${disease.disease}. ${disease.solution}`)} className="text-green-600 hover:underline">
//                   Play Audio
//                 </button>
//               </div>
//             ))}
//             <div className="flex justify-end mt-6">
//               <button onClick={onViewMore} className="text-green-600 hover:underline font-bold text-lg">
//                 View More
//               </button>
//             </div>
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default Check;