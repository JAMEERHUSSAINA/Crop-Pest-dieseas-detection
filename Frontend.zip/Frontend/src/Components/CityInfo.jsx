import React, { useState } from 'react';
import axios from 'axios';
import ReactMarkdown from "react-markdown";

const CityInfo = () => {
    const [city, setCity] = useState('');
    const [plant, setPlant] = useState(null);
    const [info, setInfo] = useState(null);
    const [error, setError] = useState(null);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError(null);

        try {
            const response = await axios.post('http://localhost:5000/predict_crop_city', { city });
            setPlant(response.data.crop_prediction);
            console.log(plant)
            console.log("1111")
            // setInfo(response.data.info);
            // console.log(info)
        } catch (err) {
            setError(err.response?.data?.message || 'Failed to fetch city details');
        }
    };

    return (
        <div className="max-w-md mx-auto p-4 bg-green-100 h-screen">
            <h1 className="text-3xl font-bold text-center text-gray-800 mb-6 mt-10">Find the Best Plant for Your City</h1>
            <p className="text-center text-gray-600 mb-8">
                Enter the name of your city to discover the most suitable plant to grow in your area, along with helpful tips and details.
            </p>
            <form onSubmit={handleSubmit} className="mb-4">
                <label className="block text-gray-700 text-sm font-bold mb-2">
                    Enter City Name
                </label>
                <input
                    type="text"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline"
                    placeholder="City Name"
                    required
                />
                <button
                    type="submit"
                    className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline mt-4"
                >
                    Get Details
                </button>
            </form>

            {error && <p className="text-red-500 text-center">{error}</p>}

            {plant && (
                <div className="mt-8">
                    {/* <h2 className="text-2xl font-bold text-gray-800">{plant}</h2> */}
                    <div className="mt-4 bg-gray-100 p-4 rounded shadow">
                    <ReactMarkdown>{plant}</ReactMarkdown>
                    </div>
                </div>
            )}
        </div>
    );
};

export default CityInfo;