// import React, { useState } from 'react';

// const CropCalculator = ({ onViewMore }) => {
//   const [crop, setCrop] = useState('');
//   const [landSize, setLandSize] = useState('');
//   const [landUnit, setLandUnit] = useState('hectares');

//   const hectaresToAcres = 2.47105;

//   const seedsPerHectare = {
//     Wheat: 120,  //kg
//     Rice: 100,
//     maize:25,
//     soyabean:80,
//     Sugarcane: 400,
//     Cotton: 15
//   };

//   const seedsPerAcre = {
//     Wheat: 120,  //kg
//     Rice: 100,
//     maize:25,
//     soyabean:80,
//     Sugarcane: 400,
//     Cotton: 15
//   };

//   const calculateSeeds = () => {
//     if (!crop || isNaN(landSize)) return 'Select the Field';

//     const seedsNeeded = landUnit === 'hectares'
//       ? seedsPerHectare[crop] * landSize
//       : seedsPerAcre[crop] * (landSize * hectaresToAcres);

//     return seedsNeeded.toFixed(2);
//   };

//   const handleSubmit = (event) => {
//     event.preventDefault();
//   };

//   return (
//     <div className="min-h-screen bg-green-50 p-6 flex flex-col justify-center items-center relative">
//       <button
//         className="absolute top-4 mt-14 left-4 bg-blue-600 text-white p-2 rounded-full shadow-lg hover:bg-blue-700 transition duration-300 flex items-center justify-center"
//         onClick={onViewMore}
//       >
//         <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
//           <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
//         </svg>
//       </button>
//       <div className="bg-white p-6 rounded-lg shadow-md w-full max-w-sm">
//         <h1 className="text-2xl font-bold text-gray-700 mb-4 text-center">Crop Calculator</h1>
//         <form onSubmit={handleSubmit} className="space-y-4">
//           <div>
//             <label className="block text-lg font-medium text-gray-600 mb-2" htmlFor="crop">Select Crop:</label>
//             <select
//               id="crop"
//               value={crop}
//               onChange={(e) => setCrop(e.target.value)}
//               className="w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-green-500 focus:border-green-500"
//               required
//             >
//               <option value="">Select a crop</option>
//               {Object.keys(seedsPerHectare).map((cropName) => (
//                 <option key={cropName} value={cropName}>{cropName}</option>
//               ))}
//             </select>
//           </div>
//           <div>
//             <label className="block text-lg font-medium text-gray-600 mb-2" htmlFor="landUnit">Land Unit:</label>
//             <select
//               id="landUnit"
//               value={landUnit}
//               onChange={(e) => setLandUnit(e.target.value)}
//               className="w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-green-500 focus:border-green-500"
//               required
//             >
//               <option value="hectares">Hectares</option>
//               <option value="acres">Acres</option>
//             </select>
//           </div>

//           <div>
//             <label className="block text-lg font-medium text-gray-600 mb-2" htmlFor="landSize">Land Size:</label>
//             <input
//               type="number"
//               id="landSize"
//               value={landSize}
//               onChange={(e) => setLandSize(e.target.value)}
//               className="w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-green-500 focus:border-green-500"
//               placeholder="Enter land size"
//               required
//             />
//           </div>

//           <div className="text-lg font-bold font-montserrat text-center bg-green-50 p-4 rounded-md shadow-inner">
//             <p className="text-gray-700">Seeds/Plants needed:</p>
//             <p className="text-green-700 text-2xl mt-2">{calculateSeeds()}</p>
//           </div>
//         </form>
//       </div>
//     </div>
//   );
// };

// export default CropCalculator;


import React, { useState } from 'react';

const seedingRates = {
  wheat: 120,
  rice: 100,
  maize: 25,
  soybean: 80,
  cotton: 15,
  sugarcane: 5000,
};

const hectareToAcre = 2.471;

const CropCalculator = () => {
  const [crop, setCrop] = useState('');
  const [areaAcres, setAreaAcres] = useState('');
  const [seedsRequired, setSeedsRequired] = useState(null);

  const calculateSeeds = (crop, areaAcres) => {
    if (!seedingRates[crop]) {
      alert(`Seeding rate for ${crop} not found.`);
      return;
    }
    const seedingRatePerHectare = seedingRates[crop];
    const areaHectares = areaAcres / hectareToAcre;
    const seedsRequiredKg = seedingRatePerHectare * areaHectares;
    return seedsRequiredKg;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const seeds = calculateSeeds(crop, parseFloat(areaAcres));
    setSeedsRequired(seeds);
  };

  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Seed Calculator</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Crop</label>
          <select
            value={crop}
            onChange={(e) => setCrop(e.target.value)}
            className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring focus:ring-indigo-200"
            required
          >
            <option value="">Select a crop</option>
            {Object.keys(seedingRates).map((crop) => (
              <option key={crop} value={crop}>
                {crop.charAt(0).toUpperCase() + crop.slice(1)}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Area (Acres)</label>
          <input
            type="number"
            value={areaAcres}
            onChange={(e) => setAreaAcres(e.target.value)}
            className="mt-1 block w-full p-2 border border-gray-300 rounded-md shadow-sm focus:ring focus:ring-indigo-200"
            required
          />
        </div>
        <button
          type="submit"
          className="mt-2 px-4 py-2 bg-blue-500 text-white font-semibold rounded-md hover:bg-blue-600"
        >
          Calculate
        </button>
      </form>
      {seedsRequired !== null && (
        <div className="mt-4">
          <h2 className="text-xl font-bold">Results</h2>
          <p>{`Seeds required to plant ${areaAcres} acres of ${crop}: ${seedsRequired.toFixed(2)} kg`}</p>
        </div>
      )}
    </div>
  );
};

export default CropCalculator;