import React, { useState } from 'react';
import { GrowthMoniter } from './Analytic';
import forcast from "../images/forecast_2.png"
const ImagePopup = ({ imageSrc, onClose }) => (
  <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div className="bg-white p-4 rounded-lg relative">
      <button onClick={onClose} className="absolute top-2 right-2 text-black font-bold">X</button>
      <img src={imageSrc} alt="Forecast" className="w-full h-auto" />
    </div>
  </div>
);

const CropMoniter = ({ onViewMore }) => {
  const [isPopupOpen, setIsPopupOpen] = useState(false);

  const openPopup = () => setIsPopupOpen(true);
  const closePopup = () => setIsPopupOpen(false);

  return (
    <div>
      <div className='px-5 pt-20'>
        <div className='pb-2 border border-gray-800 rounded-md'>
          <GrowthMoniter />
        </div>
      </div>
      <div className='flex flex-row justify-between'>
        <div className='test-base font-montserrat text-blue-600 justify-start flex font-bold pl-5'>
          <p className="pt-3 cursor-pointer" onClick={openPopup}>
            Forecasting
          </p>
        </div>
        <div className="test-base font-montserrat text-blue-600 justify-end flex font-bold pr-4">
          <p className="pr-2 pt-3 cursor-pointer" onClick={onViewMore}>View Analysis</p>
        </div>
      </div>

      {isPopupOpen && (
        <ImagePopup 
          imageSrc={forcast}
          onClose={closePopup}
        />
      )}
    </div>
  );
};

export default CropMoniter;
