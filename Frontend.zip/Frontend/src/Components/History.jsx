import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useImage } from './ImageContext';

const HistoryItem = ({ data, expandedId, toggleExpand }) => {
  const { id, problem, solution, details, image } = data;
  const expanded = id === expandedId;

  return (
    <div className={`flex flex-col px-5 pt-2  ${expanded ? 'h-96' : 'h-48 '}`}>
      <div className={`grid  grid-rows-2 shadow-lg bg-green-50 w-screen rounded-md pl-2 pt-2 ${expanded ? 'h-96 overflow-scroll' : 'h-40 overflow-hidden'} transition-all duration-500 hover:shadow-lg hover:border-green-500`}>
        <div className='grid grid-cols-12 row-span-1  h-32'>
          <div className={`${expanded ? 'col-span-12' : 'col-span-4'} transition-all duration-500`}>
          {expanded && (
              <div className='flex justify-end bottom-0 h-10'>
                <button onClick={() => toggleExpand(null)} className='z-10 font-montserrat text-sm font-bold text-gray-500'>View Less</button>
              </div>
            )}
            <img src={image} alt='crop' className={`rounded-md pr-1 transition-all duration-500 ${expanded ? 'w-full h-auto' : 'h-24 w-32'}`} />
          </div>
          <div className={`${expanded ? 'col-span-12 mt-2' : 'col-span-8'} transition-all duration-500`}>
            <p className='text-gray-800 font-montserrat font-bold'>Problem</p>
            <p className='font-kanit'>{problem}</p>
            <p className='text-gray-800 font-montserrat font-bold'>Solution</p>
            <p className='text-gray-800 font-montserrat overflow-hidden'>{solution}</p>
            {/* {expanded && (
              <div className='flex justify-center border-t border-gray-300 bottom-0 h-10 mt-4'>
                <button onClick={() => toggleExpand(null)} className='z-10 font-montserrat text-sm font-bold text-black'>View Less</button>
              </div>
            )} */}
          </div>
        </div>
      </div>
        {!expanded && (
        <div className="row-span-1 flex justify-center h-10 w-screen bg-green-50">
        <div className="flex justify-center items-center w-full h-full">
          <div className="flex justify-center">
            <button
              onClick={() => toggleExpand(id)}
              className="z-10 px-4 font-montserrat text-sm font-medium text-black"
            >
              View More
            </button>
          </div>
        </div>
      </div>
      
        )}
    </div>
  );
};

const History = () => {
  const [expandedId, setExpandedId] = useState(null);
  const [historyData, setHistoryData] = useState([]);
  const { userId } = useImage();

  useEffect(() => {
    const fetchHistoryData = async () => {
      try {
        const response = await axios.get(`http://localhost:4000/users/${userId}`);
        if (response === null) return <>No History Found</>;

        // Remove duplicates based on image URL
        const uniqueHistoryData = [];
        const imageUrls = new Set();

        response.data.history.forEach(item => {
          if (!imageUrls.has(item.image)) {
            imageUrls.add(item.image);
            uniqueHistoryData.push(item);
          }
        });

        setHistoryData(uniqueHistoryData);
      } catch (error) {
        console.error(error);
      }
    };
    fetchHistoryData();
  }, [userId]);

  const toggleExpand = (id) => {
    setExpandedId(expandedId === id ? null : id);
  };

  return (
    <div>
      <div>
        <p className='font-montserrat font-bold text-lg flex pl-6 pt-16 pb-2'>History</p>
      </div>
      {historyData.map((data) => (
        <HistoryItem
          key={data.imageId}
          data={{
            id: data.imageId,
            problem: data.disease.map(d => d.disease).join(', '),
            solution: data.disease.map(d => d.solution).join(', '),
            details: data.disease.map(d => d.details).join(', '),
            image: data.image,
          }}
          expandedId={expandedId}
          toggleExpand={toggleExpand}
        />
      ))}
    </div>
  );
};

export default History;
