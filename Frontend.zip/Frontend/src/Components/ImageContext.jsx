import React, { createContext, useState, useContext } from 'react';

const ImageContext = createContext();

export const useImage = () => useContext(ImageContext);

export const ImageProvider = ({ children }) => {
  const [image, setImage] = useState(null);
  const [userId, setUserId] = useState(() => {
    const savedUserId = localStorage.getItem('userId');
    return savedUserId ? JSON.parse(savedUserId) : null;
  });

  const storeUserId = (id) => {
    setUserId(id);
    localStorage.setItem('userId', JSON.stringify(id));
  };

  const clearData = () => {
    setUserId(null);
    setImage(null);
    localStorage.removeItem('userId');
  };

  return (
    <ImageContext.Provider value={{ image, setImage, userId, setUserId: storeUserId, clearData }}>
      {children}
    </ImageContext.Provider>
  );
};
