import React, { useState } from 'react';
import axios from 'axios';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { useImage } from './ImageContext';
import logo from '../images/logo.png'; // Replace with your logo path

const Login = ({ onViewMore }) => {
    const [isLogin, setIsLogin] = useState(true);
    const [username, setUsername] = useState('');
    const [mobileNumber, setMobileNumber] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const { setUserId } = useImage();
    const [location, setLocation] = useState(''); // New state for location

    const toggleAuthMode = () => {
        setIsLogin(!isLogin);
        setUsername('');
        setMobileNumber('');
        setEmail('');
        setPassword('');
        setConfirmPassword('');
        setLocation('');
    };

    const handleSignup = async () => {
        if (password !== confirmPassword) {
            toast.error("Passwords do not match");
            return;
        }
        try {
            const response = await axios.post('http://localhost:4000/users', {
                username,
                mobileNumber,
                email,
                password,
                location,
            });
            if (response.status === 201) {
                const userId = response.data.id;
                toast.success("Signup successful. Please login.");
                setUserId(userId);
                setIsLogin(true);
                onViewMore();
            } else {
                toast.error("Signup failed");
            }
        } catch (error) {
            const message = error.response?.data?.message || "Error during signup";
            toast.error("Error during signup: " + message);
        }
    };

    const handleLogin = async () => {
        try {
            const response = await axios.get('http://localhost:4000/users', {
                params: { mobileNumber },
            });
            const user = response.data.find((user) => user.password === password);
            if (user) {
                toast.success("Login successful");
                setUserId(user.id);
                onViewMore();
            } else {
                toast.error("Invalid mobile number or password");
            }
        } catch (error) {
            const message = error.response?.data?.message || "Error during login";
            toast.error("Error during login: " + message);
        }
    };

    return (
        <div className="min-h-screen flex items-center justify-center bg-cover bg-center">
            <div className="bg-white p-5 m-5 rounded-lg shadow-lg max-w-md w-full relative">
                <img src={logo} alt="Logo" className="w-20 mx-auto mb-6" />
                <h2 className="text-3xl font-bold text-center text-green-700 mb-6">
                    {isLogin ? 'Login' : 'Sign Up'}
                </h2>

                {!isLogin && (
                    <>
                        <div className="mb-4">
                            <label className="block text-gray-700 text-sm font-bold mb-2">Username</label>
                            <input
                                type="text"
                                placeholder="Enter your username"
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                className="w-full p-3 border rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-700"
                            />
                        </div>

                        <div className="mb-4">
                            <label className="block text-gray-700 text-sm font-bold mb-2">Email (Optional)</label>
                            <input
                                type="email"
                                placeholder="Enter your email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className="w-full p-3 border rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-700"
                            />
                        </div>

                        <div className="mb-4">
                            <label className="block text-gray-700 text-sm font-bold mb-2">Location</label>
                            <input
                                type="text"
                                placeholder="Enter your location"
                                value={location}
                                onChange={(e) => setLocation(e.target.value)}
                                className="w-full p-3 border rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-700"
                            />
                        </div>

                        <div className="mb-4">
                            <label className="block text-gray-700 text-sm font-bold mb-2">Password</label>
                            <input
                                type="password"
                                placeholder="Enter your password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className="w-full p-3 border rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-700"
                            />
                        </div>

                        <div className="mb-4">
                            <label className="block text-gray-700 text-sm font-bold mb-2">Confirm Password</label>
                            <input
                                type="password"
                                placeholder="Confirm your password"
                                value={confirmPassword}
                                onChange={(e) => setConfirmPassword(e.target.value)}
                                className="w-full p-3 border rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-700"
                            />
                        </div>
                    </>
                )}

                <div className="mb-4">
                    <label className="block text-gray-700 text-sm font-bold mb-2">Mobile Number</label>
                    <input
                        type="text"
                        placeholder="Enter mobile number"
                        value={mobileNumber}
                        onChange={(e) => setMobileNumber(e.target.value)}
                        className="w-full p-3 border rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-700"
                    />
                </div>

                <div className="mb-4">
                    <label className="block text-gray-700 text-sm font-bold mb-2">Password</label>
                    <input
                        type="password"
                        placeholder="Enter your password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full p-3 border rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-green-700"
                    />
                </div>

                <button
                    onClick={isLogin ? handleLogin : handleSignup}
                    className="w-full bg-green-700 text-white py-3 rounded-lg font-semibold hover:bg-green-800 transition duration-300"
                >
                    {isLogin ? 'Login' : 'Sign Up'}
                </button>

                <div className="text-center mt-4">
                    <button onClick={toggleAuthMode} className="text-green-700 hover:underline">
                        {isLogin ? "Don't have an account? Sign up" : "Already have an account? Login"}
                    </button>
                </div>

                {/* Decorative Elements */}
                <div className="absolute -top-8 -right-8 w-20 h-20 bg-green-500 rounded-full opacity-10"></div>
                <div className="absolute -bottom-18 -left-8 w-32 h-32 bg-green-500 rounded-full opacity-20"></div>
            </div>
            <ToastContainer />
        </div>
    );
};

export default Login;
