import mapboxgl from 'mapbox-gl';
import axios from 'axios';
import { useState, useEffect, useRef } from 'react';
import { FaExpand, FaCompress } from 'react-icons/fa';
import streetsImage from '../images/streets.jpg';
import satelliteStreetsImage from '../images/green.jpg';
import outdoorsImage from '../images/outdoors.jpg';
import satelliteImage from '../images/sat.jpg';

const cropData = {
  Ariyalur: {
    CommonAreas: "heavy clay soils",
    Existing: [
      "Rice (June-Sep.) - rice (Oct.-Jan.) - pulses / gingelly (Feb.-May)",
      "Rice (Aug.-Jan.) - groundnut (Jan.-April) – gingelly (April-June)",
      "Rice (Aug.-Jan.) - pulses/sesame/cotton (Jan.-April)",
      "Sugarcane - ratoon sugarcane (Dec.-Nov.) - (2 years rotation)",
      "Rice (Aug.-Jan.) – cotton + onion / gingelly (Feb-May)"
    ],
    NormalYear: [
      "Rice (June-Sep.) - rice (Oct.-Jan.) - pulses / gingelly (Feb.-May)",
      "Maize (Pulses) / vegetables (June-Sep.) - rice (Oct.-Jan.) - pulses/cotton + onion / gingelly / sunflower (Feb.-May)",
      "Sugarcane - ratoon sugarcane (Dec.-Nov.) - (2 years rotation)",
      "Rice (Aug.-Jan.) - cotton + onion / gingelly (Feb-May)"
    ],
    ModerateDroughtYear: [
      "Maize/vegetables/pulses/sesame/green manure (June-Sep.) - rice (Aug.-Jan.) - pulses / senna* (Feb.-May)",
      "Coleus* / Periwinkle* / senna* (June-Nov.)",
      "Sweet sorghum* (Jun-Sept) – rice (Oct-Jan) – Pulses/gingelly (Feb- May)"
    ],
    SevereDroughtYear: [
      "Pulses (June-Sep.) - sunflower/coriander/cotton (Oct.-Feb.) - fallow",
      "Millets / green manure / gingelly (June-Sep.) - maize / fodder (Oct.-Feb.) - pulses (Feb.-May)"
    ]
  },
  Chengalpattu: {
    CommonAreas: "heavy clay soils",
    Existing: [
      "Rice (June-Sep.) - rice (Oct.-Jan.) - pulses / gingelly (Feb.-May)",
      "Rice (Aug.-Jan.) - pulses/sesame/cotton (Jan.-Apr)",
      "Sugarcane - ratoon sugarcane (Dec.-Nov.) - rice (Dec.-May) – groundnut (June-Sep./Oct.) - (three years rotation)"
    ],
    NormalYear: [
      "Rice (June - Sep.) - rice (Oct.-Jan.) - pulses / gingelly (Feb.-May)",
      "Sonavari (April - July)",
      "Samba (Aug - Nov)",
      "Sugarcane - ratoon sugarcane (Dec.-Nov.) - Red Gram (Dec.-May) – groundnut (June-Sep./Oct.) - (three years rotation)"
    ],
    ModerateDroughtYear: [
      "Maize / clusterbean / lab lab / bhendi / gingelly / green manure (June-Sep.) - rice (Aug.-Feb.) – gingelly (Feb.-May)",
      "Sweet sorghum* (Jun-Sept) – Rice (Oct-Jan) – Pulses/gingelly (Feb-May)",
      "Navarai (Dec - Mar)"
    ],
    SevereDroughtYear: [
      "Millets / green manure / season (June-Sep.) - maize / fodder (Oct.-Feb.) – gingelly (Feb.-May)",
      "Perennial trees: 20% of cultivable area sapota, amla, cashew, bamboo, mango, casuarina, Brinjal, Yam, Tube rose",
      "Inland fisheries and dairy",
      "Biofuel crops are recommended only with industrial tie-up",
      "Medicinal plants are recommended only with buy back arrangement"
    ]
  },
  "சென்னை மாவட்டம்": {
    CommonAreas: "heavy clay soils",
    Existing: [
      "Rice (June-Sep.) - rice (Oct.-Jan.) - pulses / gingelly (Feb.-May)",
      "Rice (Aug.-Jan.) - groundnut (Jan.-April) – gingelly (April-June)",
      "Rice (Aug.-Jan.) - pulses/sesame/cotton (Jan.-April)",
      "Jowar (Dec.-Nov.) - (2 years rotation)",
      "Rice (Aug.-Jan.) – cotton + onion / gingelly (Feb-May)"
    ],
    NormalYear: [
      "Rice (June-Sep.) - rice (Oct.-Jan.) - pulses / gingelly (Feb.-May)",
      "Maize (Pulses) / vegetables (June-Sep.) - rice (Oct-­Jan.) - pulses/cotton + onion / gingelly/ sunflower (Feb.-May)",
      "Sugarcane - ratoon sugarcane (Dec.-Nov.) - (2 years rotation)",
      "Rice (Aug.-Jan.) - cotton + onion / gingelly (Feb-May)"
    ],
    ModerateDroughtYear: [
      "Maize/vegetables/pulses/sesame/green manure (June-Sep.) - rice (Aug.-Jan.) - pulses / senna* (Feb.-May)",
      "Coleus* / Periwinkle* / senna* (June-Nov.)",
      "Sweet sorghum* (Jun-Sept) – rice (Oct-Jan) – Pulses/gingelly (Feb- May)"
    ],
    SevereDroughtYear: [
      "Pulses (June-Sep.) - sunflower/coriander/cotton (Oct.-Feb.) - fallow",
      "Ragi (June-Sep.) - maize / fodder (Oct.-Feb.) - pulses (Feb.-May)"
    ]
  },
  "கோயம்புத்தூர் மாவட்டம்": {
    CommonAreas: "Lower Bhavani Project (LBP), Parambikulam Aliyar Project (PAP), Amaravathy Reservoir Project (ARP): Red and black soils",
    Existing: [
      "Rice (Aug.-Nov.) - groundnut (Dec.-March)",
      "Rice (June-Sep.) - rice (Oct.-Jan.)",
      "Sugarcane (Dec.-Nov.) - ratoon sugarcane (Dec.-Nov.) - rice (Dec.-March) – 3 years rotation",
      "Turmeric (May-Dec.) - rice (Dec.-March)",
      "Banana (June-May) - ratoon banana (June-May) – 2 years rotation",
      "Groundnut (June-Sep.) - rice (Oct.-Jan.) - Maize (Feb.-May)"
    ],
    NormalYear: [
      "Rice (Aug.-Nov.) - groundnut (Dec.-March)",
      "Sugarcane (Dec.-Nov.) - ratoon sugarcane (Dec.-Nov.) - rice (Dec.-March) – 3 years rotation",
      "Turmeric (May-Dec.) - rice (Dec.-March)",
      "Banana (June-May) - ratoon banana (June-May) – 2 years rotation",
      "Groundnut (June-Sep.) - rice (Oct.-Jan.) - maize (Feb.-May)"
    ],
    ModerateDroughtYear: [
      "Maize (June-Sep.) - pulses (Oct.-Dec.)",
      "Vegetables / sunflower / gingelly (Oct.-Feb.)"
    ],
    SevereDroughtYear: [
      "Sorghum / fodder sorghum / pulses (Aug.-Feb.)"
    ]
  },
  Cuddalore: {
    CommonAreas: "heavy clay soils",
    Existing: [
      "Rice (June-Sep.) - rice (Oct.-Jan.) - pulses / gingelly (Feb.-May)",
      "Rice (Aug.-Jan.) - pulses/sesame/cotton (Jan.-Apr)",
      "Sugarcane - ratoon sugarcane (Dec.-Nov.) - rice (Dec.-May) – groundnut (June-Sep./Oct.) - (three years rotation)"
    ],
    NormalYear: [
      "Rice (June - Sep.) - rice (Oct.-Jan.) - pulses / gingelly (Feb.-May)",
      "Rice (Aug.-Jan.) - pulses/sesame/cotton (Jan.-April)",
      "Maize / vegetables / pulses / gingelly / green manure (June-Sep.) – rice (Aug.-Feb.) - pulses (Feb.-May)",
      "Sugarcane - ratoon sugarcane (Dec.-Nov.) - rice (Dec.-May) – groundnut (June-Sep./Oct.) - (three years rotation)"
    ],
    ModerateDroughtYear: [
      "Maize / clusterbean / lab lab / bhendi / gingelly / green manure (June-Sep.) - rice (Aug.-Feb.) – gingelly (Feb.-May)",
      "Sweet sorghum* (Jun-Sept) – Rice (Oct-Jan) – Pulses/gingelly (Feb-May)"
    ],
    SevereDroughtYear: [
      "Millets / green manure / season (June-Sep.) - maize / fodder (Oct.-Feb.) – gingelly (Feb.-May)",
      "Perennial trees: 20% of cultivable area sapota, amla, cashew, bamboo, mango, casuarina, Brinjal, Yam, Tube rose",
      "Inland fisheries and dairy",
      "Biofuel crops are recommended only with industrial tie-up",
      "Medicinal plants are recommended only with buy back arrangement"
    ]
  },
  Karur: {
    CommonAreas: "Red and black soils except Kulithalai taluk",
    Existing: [
      "Rice (Aug.-Jan.) - pulses/sesame/cotton (Jan.-Apr)",
      "Turmeric (May-Dec.) - rice (Dec.-March)",
      "Sugarcane (Dec.-Nov.) - ratoon sugarcane (Dec.-Nov.) - rice (Dec.-March) – 3 years rotation"
    ],
    NormalYear: [
      "Rice (Aug.-Jan.) - pulses/sesame/cotton (Jan.-Apr)",
      "Turmeric (May-Dec.) - rice (Dec.-March)",
      "Sugarcane (Dec.-Nov.) - ratoon sugarcane (Dec.-Nov.) - rice (Dec.-March) – 3 years rotation",
      "Groundnut (June-Sep.) - rice (Oct.-Jan.) - maize (Feb.-May)"
    ],
    ModerateDroughtYear: [
      "Millets / pulses / green manure (June-Sep.) - maize (Oct.-Feb.) - pulses (Feb.-May)",
      "Pearlmillet / pulses / fodder sorghum (Feb.-May)"
    ],
    SevereDroughtYear: [
      "Millets / pulses / green manure (June-Sep.) - maize (Oct.-Feb.) - pulses (Feb.-May)"
    ]
  },
  Krishnagiri: {
    CommonAreas: "Red and Heavy clay soils",
    Existing: [
      "Rice (June-Sep., Dec.-March)",
      "Cotton (Aug.-Jan.)",
      "Greengram (Feb.-April)",
      "Cowpea (Feb.-April)",
      "Bhendi (June-Sep.)",
      "Cluster bean (June-Sep.)",
      "Water melon (June-Sep.)",
      "Ragi (Dec.-March)"
    ],
    NormalYear: [
      "Cotton (Aug.-Jan.)",
      "Greengram (Feb.-April)",
      "Cowpea (Feb.-April)",
      "Bhendi (June-Sep.)",
      "Cluster bean (June-Sep.)",
      "Water melon (June-Sep.)",
      "Rice (Dec.-March)",
      "Ragi (Dec.-March)"
    ],
    ModerateDroughtYear: [
      "Rice (June-Sep., Dec.-March)",
      "Green manure (May-Aug.)",
      "Pulses (May-Aug.)",
      "Radish (May-Aug.)",
      "Clusterbean (May-Aug.)",
      "Lab Lab (May-Aug.)",
      "Bhendi (May-Aug.)"
    ],
    SevereDroughtYear: [
      "Cowpea (Oct.-Jan.)",
      "Minor millet (Oct.-Jan.)",
      "Fodder (Oct.-Jan.)"
    ]
  },
  "மதுரை மாவட்டம்": {
    CommonAreas: "Alluvial soils",
    Existing: [
      "Rice (June-Sep., Oct.-Jan.)",
      "Pulses (Feb.-April)",
      "Green manure (Feb.-April)",
      "Sugarcane (Ratoon sugarcane (Nov.-Dec.))",
      "Banana (June-March)"
    ],
    NormalYear: [
      "Rice (June-Sep., Oct.-Jan.)",
      "Pulses (Feb.-April)",
      "Green manure (Feb.-April)",
      "Sugarcane (Ratoon sugarcane (Nov.-Dec.))",
      "Banana (June-March)"
    ],
    ModerateDroughtYear: [
      "Pulses (June-Sep.)",
      "Millets (June-Sep.)",
      "Clusterbean (June-Sep.)",
      "Lab Lab (June-Sep.)",
      "Bhendi (June-Sep.)",
      "Sweet sorghum (Jun-Sept)"
    ],
    SevereDroughtYear: [
      "Maize (Jun-Sep.)",
      "Millets (Jun-Sep.)",
      "Pulses (Oct.-Jan.)",
      "Senna (Oct.-Jan.)"
    ]
  },
  Mayiladuthurai: {
    CommonAreas: "Alluvial soils",
    Existing: [
      "Rice (June-Sep., Oct.-Jan.)",
      "Pulses (Feb.-May)",
      "Gingelly (Feb.-May)",
      "Groundnut (Jan.-April)",
      "Sugarcane (Ratoon sugarcane (Dec.-Nov.))"
    ],
    NormalYear: [
      "Cumbu (June-Sep.)",
      "Rice (Oct.-Jan.)",
      "Pulses (Feb.-May)",
      "Cotton (Feb.-May)",
      "Gingelly (Feb.-May)",
      "Sunflower (Feb.-May)",
      "Sugarcane (Ratoon sugarcane (Dec.-Nov.))"
    ],
    ModerateDroughtYear: [
      "Maize (June-Sep.)",
      "Vegetables (June-Sep.)",
      "Pulses (Aug.-Feb.)",
      "Sesame (Feb.-May)",
      "Green manure (June-Nov.)",
      "Pearl millet (June-Sep.)",
      "Fodder sorghum (June-Sep.)",
      "Sweet sorghum (Jun-Sept)"
    ],
    SevereDroughtYear: [
      "Pulses (June-Sep.)",
      "Sunflower (Oct.-Feb.)",
      "Coriander (Oct.-Feb.)",
      "Cotton (Oct.-Feb.)",
      "Black Gram (June-Sep.)",
      "Maize (Oct.-Feb.)"
    ]
  },
  Nagapattinam: {
    CommonAreas: "Alluvial and sandy soils",
    Existing: [
      "Rice (June-Sep., Oct.-Jan.)",
      "Pulses (Feb.-May)",
      "Gingelly (Feb.-May)",
      "Groundnut (Jan.-April)",
      "Sugarcane (Ratoon sugarcane)"
    ],
    NormalYear: [
      "Maize (June-Sep.)",
      "Pulses (Oct.-Jan.)",
      "Vegetables (June-Sep.)",
      "Cotton (Feb.-May)",
      "Sunflower (Feb.-May)",
      "Sugarcane (Ratoon sugarcane)"
    ],
    ModerateDroughtYear: [
      "Maize (June-Sep.)",
      "Clusterbean (June-Sep.)",
      "Lab Lab (June-Sep.)",
      "Bhendi (June-Sep.)",
      "Sesame (June-Sep.)",
      "Green manure (June-Nov.)",
      "Sweet sorghum (Jun-Sept.)"
    ],
    SevereDroughtYear: [
      "Millets (June-Sep.)",
      "Green manure (June-Sep.)",
      "Gingelly (June-Sep.)",
      "Maize (Oct.-Feb.)",
      "Fodder (Oct.-Feb.)"
    ]
  },
  "கன்னியாகுமரி மாவட்டம்": {
    CommonAreas: "Laterite and sandy soils",
    Existing: [
      "Rice (April-Aug., Sep.-March)",
      "Banana (April-Jan.)"
    ],
    NormalYear: [
      "Rice (April-Aug., Sep.-March)",
      "Banana (April-Jan.)"
    ],
    ModerateDroughtYear: [
      "Short duration rice (Oct.-Jan.)",
      "Maize (Oct.-Feb.)",
      "Clusterbean (Oct.-Feb.)",
      "Lab Lab (Oct.-Feb.)",
      "Bhendi (Oct.-Feb.)",
      "Groundnut (Aug.-Nov.)",
      "Tapioca (Sep.-March)"
    ],
    SevereDroughtYear: [
      "Sorghum (Oct.-Feb.)",
      "Sesame (Oct.-Feb.)",
      "Minor millets (Oct.-Feb.)",
      "Fodder (Oct.-Feb.)",
      "Horsegram (Oct.-Feb.)"
    ]
  },
    Ranipet: {
      CommonAreas: ["Tank alluvium (heavy clay and red soils)"],
      Existing: [
        "Rice (Aug.-Jan.)",
        "Pulses (Jan.-April)"
      ],
      NormalYear: [
        "Rice (Aug.-Jan.)",
        "Pulses (Jan.-April)"
      ],
      ModerateDroughtYear: [
        "Rice/Vegetables (Aug.-Jan.)",
        "Gingelly/Pulses (Feb.-May)"
      ],
      SevereDroughtYear: [
        "Pearl millet/Sorghum (Aug.-Jan.)",
        "Pulses/Ragi/Maize (Feb.-May)",
        "Pulses (June-Sep.)",
        "Wheat (Nov.-Feb.)"
      ]
    },
    "சேலம் மாவட்டம்": {
      CommonAreas: ["Heavy clay and red soils"],
      Existing: [
        "Turmeric (June-March)",
        "Sugarcane (Dec.-Nov.)",
        "Ratoon sugarcane (Dec.-Nov.)",
        "Rice (Dec.-March)"
      ],
      NormalYear: [
        "Rice (Aug.-Nov.)",
        "Rice/Cotton/Gingelly/Groundnut (Dec.-March)"
      ],
      ModerateDroughtYear: [
        "Rice/Cotton/Gingelly/Groundnut (Aug.-Nov.)",
        "Cotton (Aug.-Jan.)",
        "Greengram/Cowpea (Feb.-Apr.)",
        "Bhendi/Cluster bean/Watermelon (June-Oct.)",
        "Turmeric (Jun.-March)"
      ],
      SevereDroughtYear: [
        "Cowpea/Fodder sorghum (Oct.-Jan.)"
      ]
    },
    "சிவகங்கை மாவட்டம்": {
      CommonAreas: ["Heavy clay soils"],
      Existing: [
        "Rice (Sep.-Jan.)",
        "Cotton/Pulses/Millets/Vegetables/Gingelly (Feb.-Aug.)"
      ],
      NormalYear: [
        "Rice (Sep.-Jan.)",
        "Cotton/Pulses/Millets/Vegetables/Gingelly (Feb.-Aug.)",
        "Rice/Groundnut/Vegetables/Maize (Jun-Sep.)",
        "Chillies (Oct.-Feb.)"
      ],
      ModerateDroughtYear: [
        "Millets/Maize (Oct.-Jan.)",
        "Ragi/Maize/Gingelly (Jan.-April)",
        "Maize/Clusterbean/Lab Lab/Bhendi (June-Oct.)",
        "Pulses (Nov.-Feb.)",
        "Sweet sorghum (Jun-Sept.)",
        "Rice (Oct.-Jan.)",
        "Pulses (Feb.-May)"
      ],
      SevereDroughtYear: [
        "Sorghum/Maize/Pulses/Gingelly/Fodder/Watermelon/Gourds/Senna (Sep.-Feb.)"
      ]
    },
    Tenkasi: {
      CommonAreas: ["Alluvial and sandy soils"],
      Existing: [
        "Rice (June-Sep., Oct.-Jan.)",
        "Pulses/Gingelly (Feb.-May)"
      ],
      NormalYear: [
        "Maize/Pulses/Vegetables (June-Sep.)",
        "Rice (Oct.-Jan.)",
        "Pulses/Cotton/Gingelly/Sunflower (Feb.-May)",
        "Sugarcane (Ratoon sugarcane)"
      ],
      ModerateDroughtYear: [
        "Maize/Clusterbean/Lab Lab/Bhendi/Pulses/Sesame/Green manure (June-Sep.)",
        "Rice (Aug.-Feb.)",
        "Pulses (Feb.-May.)",
        "Coleus/Sweet sorghum (Jun.-Nov.)"
      ],
      SevereDroughtYear: [
        "Millets/Green manure/Gingelly (June-Sep.)",
        "Maize/Fodder (Oct.-Feb.)",
        "Pulses (Feb.-May.)"
      ]
    },
    Thanjavur: {
      CommonAreas: ["Alluvial soils"],
      Existing: [
        "Rice (June-Sep., Oct.-Jan.)",
        "Pulses/Gingelly (Feb.-May.)",
        "Groundnut (Jan.-April.)",
        "Sugarcane (Ratoon sugarcane (Feb.-Dec.))"
      ],
      NormalYear: [
        "Rice (June-Sep., Oct.-Jan.)",
        "Pulses/Gingelly (Feb.-May.)",
        "Groundnut (Jan.-April.)",
        "Sugarcane (Ratoon sugarcane (Feb.-Dec.))"
      ],
      ModerateDroughtYear: [
        "Maize/Clusterbean/Lab Lab/Bhendi/Pulses/Gingelly/Green manure (June-Sep.)",
        "Rice (Aug.-Feb.)",
        "Pulses/Cotton/Sunflower (Feb.-May.)",
        "Coleus/Sweet sorghum (Sep.-Jan.)"
      ],
      SevereDroughtYear: [
        "Millets/Green manure/Gingelly (June-Sep.)",
        "Maize/Fodder (Oct.-Feb.)",
        "Pulses (Feb.-May.)"
      ]
    },
    Theni: {
      CommonAreas: ["Red and alluvial soils"],
      Existing: [
        "Rice (June-Sep., Oct.-Jan.)",
        "Green manure/Pulses (Feb.-April.)"
      ],
      NormalYear: [
        "Rice (June-Sep., Oct.-Jan.)",
        "Green manure/Pulses (Feb.-April.)"
      ],
      ModerateDroughtYear: [
        "Rice (Aug.-Jan.)",
        "Maize (June-Sep.)",
        "Pulses (Feb.-May.)"
      ],
      SevereDroughtYear: [
        "Maize/Clusterbean/Lab Lab/Bhendi/Sunflower (Sep.-Jan.)",
        "Green manure (Feb.-March.)"
      ]
    },
    Thiruvallur: {
      CommonAreas: ["Tank alluvium (heavy clay and red soils)"],
      Existing: [
        "Rice (Aug.-Jan.)",
        "Pulses/Groundnut (Jan.-April.)"
      ],
      NormalYear: [
        "Rice/Vegetables/Watermelon (Aug.-Jan.)",
        "Groundnut/Gingelly/Pulses (Feb.-May.)"
      ],
      ModerateDroughtYear: [
        "Ragi/Maize/Pearl millet/Clusterbean (Aug.-Jan.)",
        "Pulses/Sesame/Vegetables/Watermelon (Feb.-April.)",
        "Pulses (June-Sep.)",
        "Wheat/Fodder (Nov.-Feb.)",
        "Tapioca (Aug.-May.)"
      ],
      "SevereDroughtYear": [
        "Wheat/Fodder (Nov.-Feb.)"
      ]
    },
    Thiruvarur: {
      "CommonAreas": ["Alluvial soils"],
      "Existing": [
        "Rice (June-Sep., Oct.-Jan.)",
        "Pulses/Gingelly (Feb.-May.)",
        "Groundnut (Jan.-April.)",
        "Sugarcane (Ratoon sugarcane (Feb.-Dec.))"
      ],
      NormalYear: [
        "Rice (June-Sep., Oct.-Jan.)",
        "Pulses/Gingelly (Feb.-May.)",
        "Groundnut (Jan.-April.)",
        "Sugarcane (Ratoon sugarcane (Feb.-Dec.))"
      ],
      ModerateDroughtYear: [
        "Maize/Clusterbean/Lab Lab/Bhendi/Pulses/Gingelly/Green manure (June-Sep.)",
        "Rice (Aug.-Feb.)",
        "Pulses/Gingelly/Cotton (Feb.-May.)",
        "Coleus/Periwinkle/Senna (Sep.-Jan.)"
      ],
      SevereDroughtYear: [
        "Millets/Green manure/Gingelly (June-Sep.)",
        "Upland rice/Maize/Fodder (Oct.-Feb.)",
        "Pulses/Sunflower (Feb.-May.)"
      ]
    },
    "தூத்துக்குடி மாவட்டம்": {
      CommonAreas: ["Thamarabarani project: Alluvial soils"],
      "Existing": [
        "Rice (June-Sep., Oct.-Jan.)",
        "Pulses/Green manure (Feb.-April.)",
        "Banana (July-June, June-March)"
      ],
      NormalYear: [
        "Rice (June-Sep., Oct.-Jan.)",
        "Pulses/Gingelly (Feb.-April.)",
        "Banana (July-June, June-March)"
      ],
      ModerateDroughtYear: [
        "Clusterbean/Lab Lab/Bhendi (June-Sep.)",
        "Rice (Oct.-Jan.)",
        "Sweet sorghum (Jun-Sept.)",
        "Pulses (Feb.-May.)"
      ],
      SevereDroughtYear: [
        "Maize/Sunflower (June-Sep.)",
        "Senna (Oct.-Jan.)"
      ]
    },
    Tiruchirappalli: {
      CommonAreas: ["Alluvial soils"],
      Existing: [
        "Rice (June-Sep., Oct.-Jan.)",
        "Pulses/Gingelly (Feb.-May.)",
        "Groundnut (Jan.-April.)",
        "Sugarcane (Ratoon sugarcane (Dec.-Nov.))"
      ],
      NormalYear: [
        "Rice (June-Sep., Oct.-Jan.)",
        "Pulses/Gingelly (Feb.-May.)",
        "Groundnut (Jan.-April.)",
        "Sugarcane (Ratoon sugarcane (Dec.-Nov.))"
      ],
      ModerateDroughtYear: [
        "Maize/Vegetables/Pulses/Sesame/Green manure (June-Sep.)",
        "Rice (Aug.-Feb.)",
        "Pulses/Senna (Feb.-May.)",
        "Coleus/Vinca rosea/Senna (June-Nov.)"
      ],
      SevereDroughtYear: [
        "Pulses (June-Sep.)",
        "Sunflower/Coriander/Cotton (Oct.-Feb.)",
        "Millets/Green manure/Gingelly (June-Sep.)",
        "Maize/Fodder (Oct.-Feb.)"
      ]
    }  ,
      "திருநெல்வேலி மாவட்டம்": {
        CommonAreas: ["Thamarabarani project area: alluvial soils"],
        Existing: [
          "Rice (June-Sep., Oct.-Jan.)",
          "Pulses/Gingelly (Feb.-April)",
          "Green manure (Feb.-May)",
          "Banana (Ratoon banana (June-March) - 2 years rotation)"
        ],
        NormalYear: [
          "Rice (June-Sep., Oct.-Jan.)",
          "Pulses/Gingelly (Feb.-April)",
          "Green manure (Feb.-May)",
          "Banana (July-June - Ratoon banana (June-March) - 2 years rotation)"
        ],
        ModerateDroughtYear: [
          "Clusterbean/Lab Lab/Bhendi (June-Sep.)",
          "Rice (Oct.-Jan.)",
          "Sweet sorghum (Jun-Sept.)",
          "Pulses (Feb.-May)"
        ],
        SevereDroughtYear: [
          "Cowpea/Green manure (June-Jan.)"
        ]
      },
      Tirupathur: {
        CommonAreas: ["Tank alluvium (heavy clay and red soils)"],
        Existing: [
          "Rice (Aug.-Jan.)",
          "Pulses/Groundnut (Jan.-April)"
        ],
        NormalYear: [
          "Rice/Vegetables/Watermelon (Aug.-Jan.)",
          "Groundnut/Gingelly/Pulses (Feb.-May)"
        ],
        ModerateDroughtYear: [
          "Ragi/Maize/Pearl millet/Clusterbean (Aug.-Jan.)",
          "Pulses/Sesame/Vegetables/Watermelon (Feb.-April)",
          "Pulses (June-Sep.)",
          "Wheat (Nov.-Feb.)",
          "Tapioca (Aug.-May)"
        ],
        SevereDroughtYear: [
          "Wheat/Fodder (Nov.-Feb.)"
        ]
      },
      "திருப்பூர் மாவட்டம்": {
        CommonAreas: ["Vaigai Periyar project: red and alluvial soils"],
        Existing: [
          "Rice (June-Sep., Oct.-Jan.)",
          "Green manure/Pulses (Feb.-April)"
        ],
        NormalYear: [
          "Rice (June-Sep., Oct.-Jan.)",
          "Green manure/Pulses (Feb.-April)"
        ],
        ModerateDroughtYear: [
          "Rice (Aug.-Jan.)",
          "Green manure (Feb.-May)",
          "Maize (June-Sep.)",
          "Pulses (Feb.-May)"
        ],
        SevereDroughtYear: [
          "Maize/Clusterbean/Lab Lab/Bhendi/Sunflower (Sep.-Jan.)",
          "Green manure (Feb.-March)"
        ]
      },
      "திருவண்ணாமலை மாவட்டம்": {
        CommonAreas: ["Sathanur: heavy clay and sandy soils"],
        Existing: [
          "Rice (Aug.-Jan.)",
          "Pulses/Gingelly (Jan.-April)"
        ],
        NormalYear: [
          "Rice/Maize (Aug.-Jan.)",
          "Pulses/Gingelly (Jan.-April)"
        ],
        ModerateDroughtYear: [
          "Groundnut/Maize (Aug.-Dec.)",
          "Pulses (Jan.-April)"
        ],
        SevereDroughtYear: [
          "Pearl millet/Sorghum/Fodder (Oct.-Jan.)",
          "Cluster bean/Vegetable beans (Oct.-Jan.)"
        ]
      },
      "THE NILIGIRIS": {
        "Description": "The Nilgiris district known as 'The Queen of Hill Stations' is situated at an elevation of 900 to 2636 meters above MSL. The climate is temperate to sub-tropical. The average annual rainfall ranges from 950 to 1550 mm. The total geographical area is 2,54,381 ha. The topography of this district is rolling and steep. About 60% of the cultivable land falls under the slope ranging from 10 to 33%. Nilgiris, being basically a Horticultural District and the crops grown are potato, cabbage, carrot, garlic, beans, paddy, ginger, tea, coffee, pepper, orange and cut flowers.",
        "SuggestedCroppingPattern": [
          "Tea and Coffee (Reduce 10% area over the next five years)",
          "Replacements: Rosemary, Thyme, Potato, Cabbage, Radish, Carrot (grow these crops in terrace)",
          "Cut flowers (Increase area)"
        ]
      },
      Vellore: {
        CommonAreas: ["Tank alluvium (heavy clay and red soils)"],
        Existing: [
          "Rice (Aug.-Jan.)",
          "Pulses (Jan.-April)"
        ],
        NormalYear: [
          "Rice/Vegetables (Aug.-Jan.)",
          "Gingelly/Pulses (Feb.-May)"
        ],
        ModerateDroughtYear: [
          "Pearl millet/Sorghum (Aug.-Jan.)",
          "Pulses/Ragi/Maize (Feb.-May)",
          "Pulses (June-Sep.)",
          "Wheat (Nov.-Feb.)"
        ],
        SevereDroughtYear: [
          "Wheat/Fodder (Nov.-Feb.)"
        ]
      },
      Vilupuram: {
        CommonAreas: ["Sathanur: Heavy clay and sandy soils"],
        Existing: [
          "Rice (Aug.-Jan.)",
          "Pulses/Gingelly (Jan.-April)"
        ],
        NormalYear: [
          "Rice (Aug.-Jan.)",
          "Pulses/Gingelly (Jan.-April)",
          "Pulses/Sesame/Maize (Jan.-April)"
        ],
        ModerateDroughtYear: [
          "Maize/Pearl millet (Aug.-Dec.)",
          "Pulses (Jan.-March)"
        ],
        SevereDroughtYear: [
          "Pearl millet/Sorghum/Fodder (Oct.-Jan.)",
          "Vegetables (Lab Lab/Cluster bean/Bhendi) (Oct.-Jan.)"
        ]
      },
      Virudhunagar: {
        CommonAreas: ["Heavy clay soils"],
        Existing: [
          "Rice (Sep.-Jan.)",
          "Cotton (Feb.-Aug.)",
          "Chillies (Oct.-Feb.)"
        ],
        NormalYear: [
          "Rice (Sep.-Jan.)",
          "Cotton (Feb.-Aug.)",
          "Rice/Maize (June-Sep.)",
          "Chillies (Oct.-Feb.)"
        ],
        ModerateDroughtYear: [
          "Maize/Clusterbean/Lab Lab/Bhendi (June-Oct.)",
          "Pulses (Nov.-Feb.)"
        ],
        SevereDroughtYear: [
          "Sorghum/Minor millets/Gingelly/Fodder/Watermelons/Gourds/Senna (Sep.-Feb.)"
        ]
      }  
};

const Maps = () => {
  const mapRef = useRef(null);
  const [mapType, setMapType] = useState('mapbox://styles/mapbox/streets-v11');
  const [coordinates, setCoordinates] = useState(null);
  const [weatherData, setWeatherData] = useState(null);
  const [districtName, setDistrictName] = useState('');
  const [cropDetails, setCropDetails] = useState({});
  const [loading, setLoading] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    mapboxgl.accessToken = 'pk.eyJ1Ijoia3J1dGhhZyIsImEiOiJjbTA5M2RxNTkxY2dsMmtzZG55bGpndmdtIn0.Ia4cFati9sMIEC1bd_lAVw';

    const map = new mapboxgl.Map({
      container: mapRef.current,
      style: mapType,
      center: [78.9629, 20.5937],
      zoom: 4,
    });

    map.addControl(new mapboxgl.NavigationControl());

    map.on('click', async (e) => {
      const clickedCoordinates = e.lngLat;
      setCoordinates(clickedCoordinates);
      setLoading(true);

      try {
        const [weatherResponse, districtResponse] = await Promise.all([
          fetchWeatherData(clickedCoordinates.lng, clickedCoordinates.lat),
          fetchDistrictName(clickedCoordinates.lat, clickedCoordinates.lng),
        ]);

        let district = districtResponse;

        // First, check if the district name exists in the hardcoded data
        if (cropData[district]) {
          setCropDetails(cropData[district]);
        } else {
          // If not found, translate the district name to English
          const translatedDistrict = await translateToEnglish(districtResponse);

          // Check again with the translated district name
          setCropDetails(cropData[translatedDistrict] || {});
        }

        setWeatherData(weatherResponse);
        setDistrictName(districtResponse);
        handleFullscreenToggle(false);
      } catch (error) {
        console.error('Error fetching data:', error);
      } finally {
        setLoading(false);
      }
    });

    return () => {
      map.remove();
    };
  }, [mapType]);

  const fetchWeatherData = async (lng, lat) => {
    const apiKey = '5c2271d3eb6f9b763548f1e81cba6d01';
    const apiUrl = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lng}&units=metric&appid=${apiKey}`;

    try {
      const response = await axios.get(apiUrl);
      return response.data;
    } catch (error) {
      console.error('Error fetching weather data:', error);
      return null;
    }
  };

  const fetchDistrictName = async (lat, lng) => {
    const apiUrl = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}`;

    try {
      const response = await axios.get(apiUrl);
      return response.data.address.state_district || 'District not found';
    } catch (error) {
      console.error('Error fetching district name:', error);
      return 'Error fetching district';
    }
  };

  const translateToEnglish = async (tamilName) => {
    // Assuming you have a translation function available or use a translation API
    try {
      const response = await axios.get('https://api.translation-service.com/translate', {
        params: {
          text: tamilName,
          target_lang: 'en'
        }
      });
      return response.data.translatedText || tamilName;
    } catch (error) {
      console.error('Error translating district name:', error);
      return tamilName;
    }
  };

  const handleMapChange = (type) => {
    setMapType(type);
  };

  const handleFullscreenToggle = (fullscreen = !isFullscreen) => {
    if (fullscreen) {
      mapRef.current.requestFullscreen().catch((err) => {
        console.error(`Error attempting to enable full-screen mode: ${err.message}`);
      });
    } else if (document.fullscreenElement) {
      document.exitFullscreen().catch((err) => {
        console.error(`Error attempting to exit full-screen mode: ${err.message}`);
      });
    }
    setIsFullscreen(fullscreen);
  };


  return (
    <div className="font-poppins p-4 pt-16">
      <div className="relative h-96 rounded-2xl shadow-lg overflow-hidden" ref={mapRef}>
        <button
          onClick={() => handleFullscreenToggle()}
          className="absolute bottom-4 right-4 z-10 bg-green-500 text-white p-3 rounded-full shadow hover:bg-green-600"
        >
          {isFullscreen ? <FaCompress size={20} /> : <FaExpand size={20} />}
        </button>
      </div>
  
      <div className="mt-4 border border-gray-300 bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="py-4 px-6">
          <MapTypeSelector mapType={mapType} onMapChange={handleMapChange} />
  
          {weatherData && !loading && (
            <div className="mt-4">
              <EnvironmentInfo weatherData={weatherData} />
              {districtName}
            </div>
          )}
  
          {coordinates && cropDetails && (
            <div className="mt-4">
              <h2 className="font-poppins font-semibold text-xl text-green-600">Crop Recommendations</h2>
              <CropRecommendations cropDetails={cropDetails} />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};    
  

  const MapTypeSelector = ({ mapType, onMapChange }) => {
    const mapTypes = [
      { type: 'mapbox://styles/mapbox/streets-v11', image: streetsImage },
      { type: 'mapbox://styles/mapbox/satellite-streets-v11', image: satelliteStreetsImage },
      { type: 'mapbox://styles/mapbox/outdoors-v11', image: outdoorsImage },
      { type: 'mapbox://styles/mapbox/satellite-v9', image: satelliteImage },
    ];
  
  return (
    <div className="mb-4">
    <h2 className="font-poppins font-semibold text-xl text-green-600 mb-4">Select Map</h2>
    <div className="grid grid-cols-4  gap-2 md:grid-cols-4">
      {mapTypes.map((map, index) => (
        <button
          key={index}
          className={`rounded-lg shadow-md border ${mapType === map.type ? 'bg-white text-white' : 'bg-gray-100 text-gray-700'}`}
          onClick={() => onMapChange(map.type)}
        >
          <img src={map.image} alt={map.type} className="w-16 h-16 md:w-24 md:h-24 object-cover rounded-md" />
        </button>
      ))}
    </div>
  </div>
    );
  };
  

  const EnvironmentInfo = ({ weatherData, loading }) => (
    <div className="font-poppins border border-gray-300 bg-white rounded-xl shadow-md p-4">
      {loading && <p className="text-gray-500">Loading...</p>}
      {weatherData && !loading && (
        <div>
          <h3 className="font-semibold text-green-600 text-lg">Weather Info</h3>
          <div className="pl-4 text-gray-700">
            <div>Temperature: {weatherData.main.temp}°C</div>
            <div>Weather: {weatherData.weather[0].description}</div>
            <div>Humidity: {weatherData.main.humidity}%</div>
            <div>Wind Speed: {weatherData.wind.speed} m/s</div>
          </div>
        </div>
      )}
    </div>
  );
  
  const CropRecommendations = ({ cropDetails }) => {
    const cropCategories = Object.keys(cropDetails);
    return (
      <div className="mt-4">
        <h1 className="text-black font-bold">Recommended Crop and Details</h1>
        <br />
        {cropCategories.length > 0 ? (
          cropCategories.map((category) => (
            <div
              key={category}
              className="mb-4 p-4 bg-white rounded-lg shadow-lg border border-gray-300 overflow-hidden"
            >
              <details className="group">
                <summary className="font-semibold text-green-600 cursor-pointer focus:outline-none group-hover:underline">
                  {category}
                </summary>
                <ul className="list-disc pl-6 mt-2 text-gray-700">
                  {Array.isArray(cropDetails[category]) ? (
                    cropDetails[category].map((item, index) => (
                      <li key={index} className="break-words">
                        {item}
                      </li>
                    ))
                  ) : (
                    <p className="break-words">
                      {cropDetails[category]}
                    </p>
                  )}
                </ul>
              </details>
            </div>
          ))
        ) : (
          <p className="text-gray-500">No crop recommendations available.</p>
        )}
      </div>
    );
  };
  
  
  
  export default Maps;