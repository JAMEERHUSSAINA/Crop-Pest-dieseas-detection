import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { IoIosArrowBack, IoIosArrowForward } from "react-icons/io";

const Page = ({ response, onViewMore }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [diseaseDetails, setDiseaseDetails] = useState(null);
  const [images, setImages] = useState([]);

  useEffect(() => {
    if (response && response.length > 0) {
      const firstDisease = response[0]; 
      setDiseaseDetails(firstDisease);

      const diseaseImages = {
        "Alternaria leafspot": [
          "https://www.vegetables.cornell.edu/files/2018/08/Summer-2013-075-1wuy93u.jpg",
          "https://www.gardentech.com/-/media/Project/OneWeb/GardenTech/Images/pest-id/plant-pest/Alternaria-leaf-spot/Alternaria-leaf-spot-broccoli-leaf.jpg",
          "https://www.crop.bayer.com.au/-/media/bcs-inter/ws_australia/discover-our-crop-solutions/by-pest/diseases/alternaria_leaf_spot.jpg?h=470&w=427&la=en&hash=374C950DBA813828B204FEF38BC7C916",
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTf6fbppcv8xGJUieeno4kO97Gni-1-1lqRqA&s",
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQV7aTIDxCCptEGp1VCxpQbqefhsLdULzjirQ&s"
        ],
        "Aphid": [
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR7e3lbguAryAklu4zY-OQ21PHe9XGHrHUmbQ&s",
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRnyV5f-RfCHW3m73U0w9GgQxfnKfpm3AExQg&s",
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQkcVTX4mr-3yCFtpwHGfwPMwJbpaIeeoBLeQ&s",
          "https://krishisevakendra.in/cdn/shop/articles/aphid-damage.webp?v=1707821600",
          "https://images.immediate.co.uk/production/volatile/sites/10/2018/02/e6062b20-6490-4970-b606-d8a3f68368fa-02e4460.jpg"
        ],
        "Helicoverpa Armigera": [
          "https://biochemtech.eu/storage/products/41/product-5f5a3f865ae66-41.jpg",
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQRJWhBTP867ZicU1-Ngexa8fNv2_dKC1n7Ow&s",
          "https://i0.wp.com/entomologytoday.org/wp-content/uploads/2021/02/helicoverpa-armigera-soybean.jpeg?resize=400%2C286&ssl=1",
          "https://apps.lucidcentral.org/pppw_v10/images/entities/tomato_fruit_borer_corn_earworm_112/unnamed1.jpg",
          "https://5.imimg.com/data5/SELLER/Default/2024/4/406758866/IH/RS/LO/12175809/helicoverpa-armigera-pheromone-trap-heliothis-cotton-bollworm.jpg"
        ],
        "Jassid": [
          "https://www.infonet-biovision.org/sites/default/files/1343.400x400_12.jpeg",
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRaiDMe8PesS-rkY5BJKsafGEIsSyHVaOPuIg&s",
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ3UdGsROFYPUOs0IIi6umXnmtjpqPLqSJJkg&s",
          "https://cdn.shopify.com/s/files/1/0762/3639/0696/files/groundnut-leafhopper-india-eng-1_480x480.webp?v=1709642227",
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRLrOBriaPEdJLu3ooDOPNEaFV20DnIlXXm_g&s"
        ],
        "Red Bug": [
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQtAjyl3mRVONOayMNaF2ti1a2omieIC-4bDA&s",
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT_AkSJPm8hYgkHerFpC-lZNNqCuwVKtACQXg&s",
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRpG2RXeFHn0NkCTkfQNJK3pimsgqvSuR6Y7w&s",
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSWmEGvu_HKpeiQwH7-wmJW7XZqtp0AwLDZ1g&s",
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRTlARA-ip7JKSkeeMXBDHxuvfLu3r_4arnFw&s"
        ],
        "bacterial blight": [
          "https://www.cottoninc.com/wp-content/uploads/2018/01/Angular-shapes-of-bacterial-blight-e1516731819850.png",
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTMlURuhBaYhXwDpJWqGfjKL7DsgOU6MrtE9w&s",
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSnXATbIw-Nvi90Mtvjttur55T9BBrl2oGO1A&s",
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRgLepY1SZyit6mhPVj0SLFsDvgugSgUFgrgg&s",
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSqxytEJWpZp6wPIdwLPBiurB8WSXKmKRyjdA&s"
        ],
        "black root rot": [
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTRgTxBQTDFsxIBtBlzp2lejjsk_61Q5IQgTQ&s",
          "https://images.squarespace-cdn.com/content/v1/58fe3c496b8f5bf31bd239f6/1584394830009-G0LIUQFXAPS10XO45TPH/new-york-state-berry-growers-association-black-root-rot-of+strawberry",
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSsg4nZ_5DSxYlediOurjXoImSG_R83akEihw&s",
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQQixLRqGYofw21hY-viUhO2HpC2xCKLeSIKA&s",
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT8sq6PaL7n7wh4BedtGrfLT8vw3ZwZUenCSA&s"
        ],
        "blue disease": [
          "https://www.aces.edu/wp-content/uploads/2019/04/Cotton-Blue-Disease-Henry-Co-1-copy-e1629929280768-300x300.jpg",
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRw1ledGakjZaxSd95--Z3PDPdVTy2H5jNgog&s",
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRuAKrVpehgoN22-FZ55gs6V7wkbnWns2nc5wITfzLDiXnfSvu_TtJBzFW_sf4Lb_gfdv4&usqp=CAU",
          "https://agrilife.org/texasrowcrops/files/2019/07/t1.jpg",
          "https://www.dpi.nsw.gov.au/__data/assets/image/0009/1187307/CottonBlueDisease2.jpg"
        ]
      
      }
      // Get images for the current disease
      setImages(diseaseImages[firstDisease.disease] || []);
    }
  }, [response]);

  const handleNextImage = () => {
    setCurrentImageIndex((prevIndex) => (prevIndex + 1) % images.length);
  };

  const handlePrevImage = () => {
    setCurrentImageIndex((prevIndex) =>
      prevIndex === 0 ? images.length - 1 : prevIndex - 1
    );
  };

  const details = diseaseDetails?.details || '';
  const solution = diseaseDetails?.solution || '';
  const plant_info = diseaseDetails?.plant_info || '';

  return (
    <div className='pl-4 pr-4'>
      <button 
        className="mt-20 bg-blue-500 text-white px-4 py-2 rounded shadow-lg hover:bg-blue-600" 
        style={{ zIndex: 1 }}
        onClick={onViewMore}
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
          <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
        </svg>
      </button>
      
      <h1 className="text-3xl font-bold mb-4 mt-4 text-green-900">{diseaseDetails?.disease || 'Disease Name'}</h1>
      
      <div className="flex items-center justify-center mb-8 relative">
        <button 
          onClick={handlePrevImage} 
          className={`text-2xl absolute left-0 ${currentImageIndex === 0 ? 'opacity-50 cursor-not-allowed' : 'opacity-100'}`}
          disabled={currentImageIndex === 0}
        >
          <IoIosArrowBack className='h-[60px] w-[40px]'/>
        </button>
        
        <div className="grid grid-cols-1 md:grid-cols-1 overflow-hidden w-full max-w-3xl gap-2">
          {images.length > 0 && (
            <img 
              src={images[currentImageIndex]} 
              alt={`Disease Image ${currentImageIndex + 1}`} 
              className="w-full h-auto object-cover" 
            />
          )}
        </div>

        <button 
          onClick={handleNextImage} 
          className={`text-2xl absolute right-0 ${currentImageIndex === images.length - 1 ? 'opacity-50 cursor-not-allowed' : 'opacity-100'}`}
          disabled={currentImageIndex === images.length - 1}
        >
          <IoIosArrowForward className='h-[60px] w-[40px]' />
        </button>
      </div>
      
      <div className="p-6 bg-white shadow-lg rounded-lg border border-green-300">
        <h2 className="text-xl font-bold mb-2 text-green-800">Disease Details</h2>
        <p className="mb-2">{details}</p>
        <h3 className="text-lg font-semibold mb-2 text-green-600">Solution</h3>
        <p className="mb-4">{solution}</p>
        <h3 className="text-lg font-semibold mb-2 text-green-600">Requirements</h3>
        <p className="mb-6">{plant_info}</p>
      </div>
    </div>
  );
};

export default Page;
