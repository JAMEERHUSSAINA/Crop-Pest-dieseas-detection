import React, { useState, useEffect } from 'react';
import CameraUpload from './CameraUpload';
import { useImage } from './ImageContext';
import axios from 'axios';
import { useSpeechSynthesis } from 'react-speech-kit';

const ImagePrediction = ({ onViewMore, setResponse }) => {
  const { image, userId } = useImage();
  const [toggle, setToggle] = useState(1);
  const [response, setLocalResponse] = useState(null);
  const [loading, setLoading] = useState(false);
  const [language, setLanguage] = useState('en'); 
  const { speak } = useSpeechSynthesis();

const [expandedDisease, setExpandedDisease] = useState("");
const [searchInput, setSearchInput] = useState('');
const handleExpandClick = (disease) => {
    setExpandedDisease(expandedDisease === disease ? null : disease);
  };

  const getColorClass = (risk) => {
    switch (risk) {
      case 'Extremely high':
      case 'High':
        return 'text-red-600';
      case 'Moderate to High':
        return 'text-orange-500';
      case 'Moderate':
        return 'text-orange-500';
      default:
        return 'text-green-600';
    }
  };

  const diseaseInfoTomato = [
    {
      name: "Late Blight (Phytophthora infestans)",
      risk: "Extremely high",
      symptoms: "Water-soaked lesions on leaves, stems, and fruit that quickly become brown and leathery.",
      impact: "Can destroy the entire crop within days, especially in wet and cool conditions."
    },
    {
      name: "Early Blight (Alternaria solani)",
      risk: "High",
      symptoms: "Dark, concentric rings on leaves, starting at the lower leaves and moving upward. Also affects stems and fruit.",
      impact: "Reduces fruit yield and quality, making plants more susceptible to other issues."
    },
    {
      name: "Bacterial Spot (Xanthomonas spp.)",
      risk: "High",
      symptoms: "Small, dark, water-soaked spots on leaves, stems, and fruit that turn black with a yellow halo.",
      impact: "Causes leaf drop, reduced fruit yield, and unmarketable fruit."
    },
    {
      name: "Fusarium Wilt (Fusarium oxysporum f. sp. lycopersici)",
      risk: "High",
      symptoms: "Yellowing and wilting of lower leaves, one-sided stem and leaf browning, and eventual plant death.",
      impact: "Causes significant crop loss, especially in warm, sandy soils."
    },
    {
      name: "Tomato Spotted Wilt Virus (TSWV)",
      risk: "High",
      symptoms: "Bronzing, rings, or spots on leaves, stunted growth, and misshapen, discolored fruit.",
      impact: "Severely reduces plant growth and fruit production."
    },
    {
      name: "Verticillium Wilt (Verticillium dahliae and Verticillium albo-atrum)",
      risk: "High",
      symptoms: "Yellowing of lower leaves, V-shaped lesions on leaf edges, and wilted plants that eventually die.",
      impact: "Reduces yield and plant vigor, especially in cooler climates."
    },
    {
      name: "Southern Blight (Sclerotium rolfsii)",
      risk: "High",
      symptoms: "Wilting of the plant, white fungal growth at the base, and rotting of the stem.",
      impact: "Rapid plant death and significant crop loss, particularly in warm, humid conditions."
    },
    {
      name: "Septoria Leaf Spot (Septoria lycopersici)",
      risk: "Moderate to High",
      symptoms: "Small, circular spots with dark borders and light centers on leaves, leading to defoliation.",
      impact: "Reduces photosynthesis, leading to lower fruit yield and quality."
    }
  ];

     const diseaseInfoPaddy = [
      {
        "name": "Rice Blast (Magnaporthe oryzae)",
        "risk": "High",
        "symptoms": "Spindle-shaped lesions with gray centers and brown margins on leaves, nodes, and panicles. Can lead to 'neck blast,' causing the grain to shrivel.",
        "spread": "Airborne spores, especially in warm, humid conditions.",
        "impact": "Can cause significant yield loss, particularly in areas with conducive climates."
      },
      {
        "name": "Bacterial Leaf Blight (Xanthomonas oryzae pv. oryzae)",
        "risk": "High",
        "symptoms": "Yellowing and wilting of leaves starting from the tips, leading to entire leaf collapse. In severe cases, plants may die prematurely.",
        "spread": "Spread through infected seeds, irrigation water, and rain splashes.",
        "impact": "Can result in up to 70% yield loss in severe outbreaks."
      },
      {
        "name": "Sheath Blight (Rhizoctonia solani)",
        "risk": "High",
        "symptoms": "Irregular, greenish-gray lesions on the leaf sheaths near the waterline, which can spread to the leaves.",
        "spread": "Soil-borne fungus that thrives in high humidity and dense planting.",
        "impact": "Affects grain filling, leading to reduced yield and quality."
      },
      {
        "name": "Brown Spot (Bipolaris oryzae)",
        "risk": "Moderate",
        "symptoms": "Brown, round to oval spots on leaves, sometimes with a yellow halo. Severe infection can cause grain discoloration.",
        "spread": "Spores spread by wind, rain, and infected seeds.",
        "impact": "More severe under poor nutrient conditions, especially with potassium deficiency, leading to moderate yield loss."
      },
      {
        "name": "Rice Tungro Disease",
        "risk": "Moderate",
        "symptoms": "Stunted growth, yellow to orange discoloration of leaves, and reduced tillering.",
        "spread": "Transmitted by green leafhoppers (insect vectors).",
        "impact": "Yield losses can be significant in affected areas, particularly where vector populations are high."
      },
      {
        "name": "False Smut (Ustilaginoidea virens)",
        "risk": "Moderate",
        "symptoms": "Formation of greenish-yellow to orange spore balls on the grains, replacing individual grains.",
        "spread": "Spread through windborne spores, especially in humid conditions.",
        "impact": "Reduces grain quality and can contaminate the crop with toxins, though yield loss is generally moderate."
      },
      {
        "name": "Bakanae Disease (Fusarium moniliforme)",
        "risk": "Low",
        "symptoms": "Abnormal elongation of seedlings, chlorotic leaves, and reduced tillering. Infected plants often die before maturity.",
        "spread": "Seed-borne and can also spread through soil.",
        "impact": "Can be controlled with seed treatment, and yield losses are generally low in well-managed fields."
      },
      {
        "name": "Leaf Scald (Microdochium oryzae)",
        "risk": "Low",
        "symptoms": "Long, narrow lesions with wavy margins on leaves, starting from the tips and edges.",
        "spread": "Spread by wind and rain, especially in warm and wet conditions.",
        "impact": "Yield loss is usually low unless the disease is left unchecked in favorable conditions."
      },
      {
        "name": "Rice Yellow Mottle Virus (RYMV)",
        "risk": "Low",
        "symptoms": "Yellow mottling on leaves, stunted growth, and reduced tillering.",
        "spread": "Transmitted by insects like beetles and leafhoppers.",
        "impact": "Can cause yield loss, but usually low in areas with good management practices."
      }
    ]
  

  useEffect(() => {
    if (image) {
      setLoading(true);
      const endpoint = toggle === 1 ? 'http://localhost:5000/detect_disease' : 'http://localhost:5000/detect_pests';

      const formData = new FormData();
      formData.append('image', image);

      axios.post(endpoint, formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
      .then(response => {
        const data = toggle === 1 ? response.data.diseases_detected : response.data.pests_detected;

        // Translate data if language is Tamil
        if (language === 'ta') {
          const translatedData = data.map(async disease => {
            const translatedDisease = await translateText(disease.disease, 'ta');
            const translatedSolution = await translateText(disease.solution, 'ta');
            return { disease: translatedDisease, solution: translatedSolution };
          });
          Promise.all(translatedData).then(finalData => {
            setLocalResponse(finalData);
            setResponse(finalData);
            setLoading(false);
          });
        } else {
          setLocalResponse(data);
          setResponse(data);
          setLoading(false);
        }
      })
      .catch(error => {
        console.error("Error detecting:", error);
        setLoading(false);
      });
    }
  }, [image, toggle, language]);



  // UseEffect to save image and response to user's history
  useEffect(() => {
    if (image && response && userId) {
      const reader = new FileReader();
      reader.readAsDataURL(image);
  
      reader.onloadend = () => {
        const base64Image = reader.result;
  
        const newEntry = {
          imageId: Date.now(),
          image: base64Image,
          disease: response,
        };
  
        axios.get(`http://localhost:4000/users/${userId}`)
          .then(res => {
            const userData = res.data;
            let updatedHistory = Array.isArray(userData.history) ? userData.history : [];
            const imageExists = updatedHistory.some(entry => entry.image === base64Image);
  
            if (!imageExists) {
              updatedHistory = [...updatedHistory, newEntry];
            } else {
              console.log("Image already exists in history");
            }
  
            return axios.patch(`http://localhost:4000/users/${userId}`, { history: updatedHistory });
          })
          .then(() => {
            console.log("Image data saved successfully");
          })
          .catch(err => {
            if (err.response && err.response.status === 404) {
              console.error("User not found:", err);
              // Optionally handle user creation or display a message
              // For example, you could create a new user here
              // axios.post('http://localhost:4000/users', { id: userId, history: [newEntry] });
            } else {
              console.error("Error saving image data:", err);
            }
          });
      };
    }
  }, [image, response, userId]);
  
  const translateText = async (text, targetLang) => {
    try {
      const response = await axios.post(
        'https://libretranslate.com/translate',
        {
          q: text,
          source: 'en', // Assuming source language is English
          target: targetLang
        },
        {
          headers: { 'Content-Type': 'application/json' }
        }
      );
      return response.data.translatedText;
    } catch (error) {
      console.error("Translation error:", error);
      return text; // Fallback to original text if translation fails
    }
  }

  const handleSpeak = (text) => {
    speak({ text, lang: language === 'ta' ? 'ta-IN' : 'en-US' });
  };

const getDiseaseInfo = () => {
    const crop = searchInput.toLowerCase();
    if (crop === 'tomato') {
      return diseaseInfoTomato;
    } else if (crop === 'paddy') {
      return diseaseInfoPaddy;
    }
    return [];
  };
  return (
    <div className="min-h-screen flex flex-col bg-green-50">
    <header className="text-black py-6 pt-20">
      <h1 className="text-3xl font-bold text-center font-montserrat">
        Plant Disease Detection
      </h1>
      <p className="text-center mt-2 text-green-600">
        Identify and manage plant diseases effectively
      </p>
      <div className="flex justify-center mt-4">
        <label className="mr-2 text-lg">Language:</label>
        <select
          value={language}
          onChange={(e) => setLanguage(e.target.value)}
          className="px-3 py-1 border border-green-600 rounded"
        >
          <option value="en">English</option>
          <option value="ta">Tamil</option>
        </select>
      </div>
    </header>
    <div className="flex-grow flex flex-col items-center pt-10 p-6">
      <div className="flex justify-center mb-8">
        <div className="flex space-x-0">
          <button
            onClick={() => setToggle(1)}
            className={`px-2 py-2 rounded-l border border-green-600 ${
              toggle === 1 ? 'bg-green-600 text-white' : 'bg-white text-green-600'
            } transition-all`}
          >
            Disease prediction
          </button>
          <button
            onClick={() => setToggle(2)}
            className={`px-6 py-2 rounded-r border border-green-600 ${
              toggle === 2 ? 'bg-green-600 text-white' : 'bg-white text-green-600'
            } transition-all`}
          >
            Pest prediction
          </button>
        </div>
      </div>
      <div className="relative flex justify-center mb-9 w-full">
        <div className="p-4 border border-dashed border-green-300 rounded-lg w-96 h-96 bg-white shadow-lg">
          <CameraUpload />
        </div>
      </div>
      <div className="mb-6 w-full max-w-md">
        <p className="font-montserrat text-gray-700 font-bold">Enter Crop Name</p>
        <input
          type="text"
          placeholder="Crop Name"
          value={searchInput}
          onChange={(e) => setSearchInput(e.target.value)}
          className="p-2 border border-gray-300 rounded w-full"
        />
      </div>
      {loading && (
        <div className="bg-green-100 p-6 rounded-lg shadow-md border border-green-300 text-center">
          <p>Loading response...</p>
        </div>
      )}
      <div className="w-full max-w-md">
        {getDiseaseInfo().map((disease, index) => (
          <div key={index} className="mb-6 font-montserrat">
            <h3
              className={`text-lg font-semibold cursor-pointer ${getColorClass(disease.risk)}`}
              onClick={() => handleExpandClick(disease.name)}
            >
              {disease.name}
            </h3>
            {expandedDisease === disease.name && (
              <div className="p-4 border border-gray-300 rounded mt-2 font-montserrat">
                <p className="text-gray-700 mb-2"><strong>Risk:</strong> <span className={getColorClass(disease.risk)}>{disease.risk}</span></p>
                <p className="text-gray-700 mb-2"><strong>Symptoms:</strong> {disease.symptoms}</p>
                <p className="text-gray-700 mb-2"><strong>Impact:</strong> {disease.impact}</p>
              </div>
            )}
          </div>
        ))}
      </div>
      {response && !loading && (
        <div className="bg-white p-6 rounded-lg mt-6 shadow-lg border border-green-300 w-full max-w-md">
          <h2 className="text-xl font-bold mb-4 text-green-800">
            Detected Diseases
          </h2>
          {response.map((disease, index) => (
            <div key={index} className="mb-6">
              <h3 className="text-lg font-semibold text-green-600">{disease.disease}</h3>
              <p className="text-gray-700 mb-2"><strong>Solution:</strong> {disease.solution}</p>
              <button
                onClick={() => handleSpeak(`${disease.disease}. ${disease.solution}`)}
                className="text-green-600 hover:underline"
              >
                Play Audio
              </button>
            </div>
          ))}
          <div className="flex justify-end mt-6">
            <button onClick={onViewMore} className="text-green-600 hover:underline font-bold text-lg">
              View More
            </button>
          </div>
        </div>
      )}
    </div>
  </div>
  
);
};

export default ImagePrediction;