import axios from 'axios';
import React, { useState } from 'react';
import ReactMarkdown from "react-markdown";

const Resource = ({ onViewMore }) => {
  const [selectedSoil, setSelectedSoil] = useState('');
  const [cropOptions, setCropOptions] = useState([]);
  const [selectedCrop, setSelectedCrop] = useState('');
  const [diseaseOptions, setDiseaseOptions] = useState([]);
  const [selectedDisease, setSelectedDisease] = useState('');
  const [landSize, setLandSize] = useState('');
  const [landUnit, setLandUnit] = useState('hectares');
  const [selectedSection, setSelectedSection] = useState('');
  const [sectionData, setSectionData] = useState(null);
  const [loading, setLoading] = useState(false);

  const soilToCropMapping = {
    'Alluvial soil': ['Wheat', 'Rice', 'Sugarcane', 'Cotton','Jute','Pulses','Maize','Oilseeds'],
    'black soil': ['Cotton', 'Wheat', 'Jowar', 'Millets','Groundnut','Sugarcane','Pulses','Sunflower'],
    'red soil': ['Groundnut', 'Millets', 'Rice', 'Cotton','Pulses','Oilseeds','Potato','Fruits like Mango, Orange, and Grapes'],
    'marsh soil': ['Rice', 'Jute', 'Sugarcane','Barley','Mustard','Millets'],
    'laterite soil': ['Tea', 'Coffee', 'Cashew', 'Rubber','Cashew Nuts','Coconut','Pepper','Pineapple'],
  };

  const images = {
    "Fertilizers": 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTi2mihT3stc8mnXFmU0vnVNjMe9orhKYMteQ&s',
    'organic solution': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ0EfxLWgQ1sKQSqO8-07Tlt3doxqAtgiOgUA&s',
    'Market Information': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQy9MbGp_mGXIUvVHsFnYe7PPqbJZvRydUUNtXbydm12FcOB_CXXJDe74FZ4A&s',
    'preventive measures': 'https://i0.wp.com/geopard.tech/wp-content/uploads/2021/12/Sand.jpg?resize=810%2C439&ssl=1',
  };

  const diseaseMapping = {
    // Alluvial Soil Crops
    Wheat: ['Alternaria leafspot', 'Jassid', 'Curl Virus', 'Rust', 'Powdery Mildew'],
    Rice: ['Blast', 'Brown Spot', 'Bacterial Blight', 'Sheath Blight', 'Tungro Virus'],
    Sugarcane: ['Red Rot', 'Smut', 'Wilt', 'Ratoon Stunting', 'Mosaic Virus'],
    Cotton: ['Boll Rot', 'Leaf Curl', 'Wilt', 'Anthracnose', 'Verticillium Wilt'],
    Jute: ['Stem Rot', 'Black Band Disease', 'Mosaic Virus'],
    Pulses: ['Wilt', 'Powdery Mildew', 'Rust', 'Blight', 'Mosaic Virus'],
    Maize: ['Downy Mildew', 'Rust', 'Bacterial Stalk Rot', 'Leaf Blight'],
    Oilseeds: ['Alternaria Blight', 'Rust', 'Downy Mildew', 'Sclerotinia Stem Rot'],
  
    // Black Soil Crops
    Jowar: ['Downy Mildew', 'Rust', 'Anthracnose', 'Grain Mold'],
    Millets: ['Blast', 'Rust', 'Smuts', 'Downy Mildew'],
    Groundnut: ['Tikka Disease', 'Rust', 'Leaf Spot', 'Collar Rot'],
    Sunflower: ['Alternaria Leaf Spot', 'Downy Mildew', 'Rust', 'Sclerotinia Stem Rot'],
  
    // Red Soil Crops
    Potato: ['Late Blight', 'Early Blight', 'Black Scurf', 'Wilt'],
    Fruits: ['Anthracnose', 'Fruit Rot', 'Powdery Mildew', 'Mosaic Virus'],
  
    // Marsh Soil Crops
    Barley: ['Leaf Rust', 'Stripe Rust', 'Scald', 'Powdery Mildew'],
    Mustard: ['Alternaria Blight', 'White Rust', 'Downy Mildew', 'Sclerotinia Stem Rot'],
  
    // Laterite Soil Crops
    Tea: ['Blister Blight', 'Red Rust', 'Black Rot'],
    Coffee: ['Coffee Leaf Rust', 'Coffee Berry Disease', 'Wilt'],
    Cashew: ['Anthracnose', 'Powdery Mildew', 'Dieback', 'Tea Mosquito Bug'],
    Rubber: ['Powdery Mildew', 'Leaf Spot', 'Pink Disease', 'Corynespora Leaf Fall'],
    Coconut: ['Root Wilt', 'Stem Bleeding', 'Bud Rot', 'Leaf Blight'],
    Pepper: ['Foot Rot', 'Pollu Beetle', 'Quick Wilt'],
    Pineapple: ['Phytophthora Heart Rot', 'Pink Disease', 'Mealybug Wilt'],
  };
  

  const fetchData = async () => {
    const requestData = {
      crop: selectedCrop,
      soil: selectedSoil,
      disease: selectedDisease,
      land_size: landSize,
      section: selectedSection,
      unit: landUnit,
    };

    console.log('Request Data:', requestData);

    setLoading(true);
    try {
      const response = await axios.post('http://localhost:5000/get_agricultural_advice', requestData);
      setSectionData(response.data.advice);
      // console.log(sectionData.fertilizers.map((i,e)=>{
      //   <div key={e+1}>
      //     <div>{i.name}</div>
      //     <div>{i.amount}</div>
      //   </div>
      // }))
      console.log('Response:', response.data);
      // console.log(sectionData);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  
  const handleSoilChange = (event) => {
    const soil = event.target.value;
    setSelectedSoil(soil);
    setCropOptions(soilToCropMapping[soil] || []);
    setSelectedCrop('');
    setDiseaseOptions([]);
    setSelectedDisease('');
    setSelectedSection('');
    setSectionData(null);
  };

  const handleCropChange = (event) => {
    const crop = event.target.value;
    setSelectedCrop(crop);
    setDiseaseOptions(diseaseMapping[crop] || []);
    setSelectedDisease('');
  };

  const handleSectionClick = (section) => {
    // console.log(section);
    setSelectedSection(section);
    fetchData();
  };

  const renderDetails = () => {
    if (loading) {
      return <p className='text-gray-500'>Loading data...</p>;
    }

    if (!sectionData) {
      return <p className='text-gray-500'>Details not available for the selected combination.</p>;
    }

    switch (selectedSection) {
      case 'Fertilizers':
        return (
          <>
            <p className='font-montserrat text-lg font-bold text-gray-600'>Fertilizer Name</p>
            {/* <p className='text-gray-700'>{sectionData}</p> */}
            <ReactMarkdown>{sectionData}</ReactMarkdown>
            {/* <p className='font-montserrat text-lg font-bold text-gray-600'>Fertilizer Info</p>
            <p className='text-gray-700'>{sectionData.info}</p>
            <p className='font-montserrat text-lg font-bold text-gray-600'>Fertilizer Use</p>
            <p className='text-gray-700'>{sectionData.use}</p> */}
          </>
        );
      case 'organic solution':
        return (
          <>
            <p className='font-montserrat text-lg font-bold text-gray-600'>organic solution</p>
            <ReactMarkdown>{sectionData}</ReactMarkdown>
            {/* <p className='text-gray-700'>{sectionData.info}</p>
            <p className='font-montserrat text-lg font-bold text-gray-600'>Tips</p>
            <p className='text-gray-700'>{sectionData.tips}</p> */}
          </>
        );
      case 'Market Information':
        return (
          <>
            <p className='font-montserrat text-lg font-bold text-gray-600'>Market Trends</p>
            <ReactMarkdown>{sectionData}</ReactMarkdown>
            {/* <p className='text-gray-700'>{sectionData.trends}</p>
            <p className='font-montserrat text-lg font-bold text-gray-600'>Prices</p>
            <p className='text-gray-700'>{sectionData.prices}</p> */}
          </>
        );
      case 'preventive measures':
        return (
          <>
            <p className='font-montserrat text-lg font-bold text-gray-600'>Soil Characteristics</p>
            <ReactMarkdown>{sectionData}</ReactMarkdown>
            {/* <p className='text-gray-700'>{sectionData.characteristics}</p>
            <p className='font-montserrat text-lg font-bold text-gray-600'>Management</p>
            <p className='text-gray-700'>{sectionData.management}</p> */}
          </>
        );
      default:
        return <p>Invalid section selected.</p>;
    }
  };

  return (
    <div className='px-2 py-2 pt-14'>
      <div>
        <div className='flex justify-between'>
        <p className='font-montserrat text-xl font-bold pl-3 pt-1'>Resource to Use</p>
        <div className='pr-3'>
        <button className=' font-montserrat font-bold border border-green-500 py-1 px-1 rounded-md text-white bg-green-500 '
        onClick={onViewMore}>Crop Calculator</button>
        </div>
        </div>
        <div className='grid grid-cols-2 gap-2 pt-5 px-2'>
          <div className="">
            <select
              name="soil"
              className="w-full p-2 border font-kanit border-gray-300 rounded-md"
              value={selectedSoil}
              onChange={handleSoilChange}
              required
            >
              <option value="">Select Type Of Soil</option>
              {Object.keys(soilToCropMapping).map((soil) => (
                <option key={soil} value={soil}>{soil}</option>
              ))}
            </select>
          </div>
          <div className="">
            <select
              name="crop"
              className="w-full p-2 border font-kanit border-gray-300 rounded-md"
              value={selectedCrop}
              onChange={handleCropChange}
              required
              disabled={!selectedSoil}
            >
              <option value="">Select Type of Crop</option>
              {cropOptions.map((crop) => (
                <option key={crop} value={crop}>{crop}</option>
              ))}
            </select>
          </div>
          <div className="">
            <select
              name="disease"
              className="w-full p-2 border font-kanit border-gray-300 rounded-md"
              value={selectedDisease}
              onChange={(e) => setSelectedDisease(e.target.value)}
              required
              disabled={!selectedCrop}
            >
              <option value="">Select Type of Disease</option>
              {diseaseOptions.map((disease) => (
                <option key={disease} value={disease}>{disease}</option>
              ))}
            </select>
          </div>
          <div className="flex items-center gap-2">
            <input
              type="number"
              name="landSize"
              className="w-full pt-2 pb-1 border font-kanit pl-2 border-gray-300 rounded-md"
              placeholder={` Size of land`}
              value={landSize}
              onChange={(e) => setLandSize(e.target.value)}
              required
            />
            <select
              name="landUnit"
              className="p-2 border font-kanit border-gray-300 rounded-md"
              value={landUnit}
              onChange={(e) => setLandUnit(e.target.value)}
            >
              <option value="hectares">Hec</option>
              <option value="acres">Acr</option>
            </select>
          </div>
        </div>
      </div>

      <div className='flex flex-row gap-4 px-2 py-5 overflow-x-scroll'>
        {['Fertilizers', 'organic solution', 'Market Information', 'preventive measures'].map((section) => (
          <div
            key={section}
            className={`shadow-md rounded-md font-montserrat flex-shrink-0 text-lg px-5 py-3 cursor-pointer whitespace-nowrap ${
              selectedSection === section ? 'bg-green-100' : ''
            }`}
            onClick={() => handleSectionClick(section)}
          >
            <div className='flex items-center flex-row'>
              <img className='w-10 h-10 mr-3 rounded-md' src={images[section]} alt={section} />
              <p className='font-montserrat font-bold'>{section}</p>
            </div>
          </div>
        ))}
      </div>
      {selectedSection && (
        <div className='shadow-md rounded-md px-5 py-5'>
          <h2 className='font-bold text-xl mb-3'>{selectedSection}</h2>
          <div className='shadow-md p-3'>
            {renderDetails()}
          </div>
        </div>
      )}
    </div>
  );
};

export default Resource;
