// import React, { useState } from 'react';
// import SearchIcon from '@mui/icons-material/Search';
// import Card from '@mui/material/Card';
// import CardActions from '@mui/material/CardActions';
// import CardContent from '@mui/material/CardContent';
// import CardMedia from '@mui/material/CardMedia';
// import Button from '@mui/material/Button';
// import Typography from '@mui/material/Typography';
// import a from '../images/compost.jpg'
// import b from '../images/nitro1.jpg'
// import c from '../images/pottasium.jpg'
// import d from '../images/phos.jpg'
// import e from '../images/urea.jpg'
// import f from '../images/superphos.jpg'
// import g from '../images/calnitrate.jpg'
// import h from '../images/micronutrient.jpg'
// import i from '../images/bonemeall.jpg'
// import j from '../images/tractor.jpg'
// import k from '../images/plough.jpg'
// import l from '../images/seedrill.jpg'
// import m from '../images/sprayer.jpg'
// import n from '../images/harvester.jpg'
// import o from '../images/rotavator.jpg'
// import p from '../images/baler.jpg'
// import q from '../images/chiselplough.jpg'

// const sectionInfo = {
//     "Fertilizers": {
//         "title": "Fertilizers",
//         "items": [
//             { "name": "Nitrogen Fertilizer", "price": "₹1,500", "description": "Nitrogen Fertilizer is crucial for promoting vigorous plant growth by enhancing leaf and stem development. It helps in the synthesis of proteins and chlorophyll, leading to increased crop yields. Ideal for leafy vegetables and cereals.", "image": b },
//             { "name": "Phosphorus Fertilizer", "price": "₹1,875", "description": "Phosphorus Fertilizer improves root development and enhances flowering and fruiting. It is essential for energy transfer and storage in plants, making it vital for root crops and flowering plants. It also boosts resistance to diseases.", "image": d },
//             { "name": "Potassium Fertilizer", "price": "₹1,350", "description": "Potassium Fertilizer aids in enhancing the plant's ability to resist diseases and improve water retention. It plays a key role in photosynthesis and protein synthesis. Suitable for a wide range of crops including vegetables and grains.", "image": c },
//             { "name": "Compost", "price": "₹1,125", "description": "Compost is rich in organic matter and nutrients, improving soil texture and fertility. It helps in the retention of moisture and supports healthy root development. Suitable for all types of crops, it is an essential component of organic farming.", "image": a },
//             { "name": "Urea", "price": "₹1,200", "description": "Urea is a high-nitrogen fertilizer that promotes rapid plant growth and development. It is widely used for cereals, vegetables, and other crops needing a quick nitrogen boost. Ensure proper application to avoid nitrogen leaching.", "image": e },
//             { "name": "Superphosphate", "price": "₹1,800", "description": "Superphosphate provides a readily available source of phosphorus to plants, supporting root growth and flowering. It is beneficial for root crops like potatoes and carrots, as well as for flowering plants and vegetables.", "image": f },
//             { "name": "Calcium Nitrate", "price": "₹2,000", "description": "Calcium Nitrate supplies calcium and nitrogen to plants, essential for cell wall development and overall plant health. It is particularly useful for preventing calcium deficiencies in crops such as tomatoes and peppers.", "image": g },
//             { "name": "Micronutrient Mix", "price": "₹1,800", "description": "Micronutrient Mix provides essential trace elements like zinc, iron, and manganese that are critical for plant health and development. It helps in correcting deficiencies and enhancing crop productivity.", "image": h },
//             { "name": "Bone Meal", "price": "₹1,650", "description": "Bone Meal is a slow-release organic fertilizer that enriches the soil with phosphorus and calcium. It supports strong root development and helps in flowering and fruiting. Ideal for use in vegetable gardens and flower beds.", "image": i }
//         ]
//         },
//         "Equipment": {
//           "title": "Equipment",
//           "items": [
//             { "name": "Tractor", "price": "₹1,25,000", "description": "A versatile tractor designed for various farming tasks, including ploughing, tilling, and hauling. Its powerful engine and robust build make it suitable for large-scale farming operations, enhancing productivity.", "image": j },
//             { "name": "Plough", "price": "₹30,000", "description": "A high-quality plough designed for efficient soil preparation. It helps in breaking up and turning over soil, making it suitable for planting and improving soil aeration. Essential for tilling large fields.", "image": k},
//             { "name": "Seed Drill", "price": "₹40,000", "description": "Seed Drill ensures precise planting of seeds at the correct depth and spacing. It enhances germination rates and crop uniformity, making it ideal for various crops including grains and vegetables.", "image": l },
//             { "name": "Sprayer Machine", "price": "₹25,000", "description": "Sprayer Machine is used for applying pesticides, herbicides, and fertilizers evenly across crops. It ensures effective coverage and reduces manual labor, improving crop protection and nutrient application.", "image": m },
//             { "name": "Harvester", "price": "₹2,00,000", "description": "Harvester is designed for efficient and quick harvesting of crops such as wheat, rice, and corn. It reduces labor costs and harvest time, making it ideal for large-scale farming operations.", "image": n },
//             { "name": "Rotavator", "price": "₹45,000", "description": "Rotavator is used for preparing soil by breaking it into finer particles. It improves soil aeration and mixing of organic matter, making it ready for planting and enhancing soil fertility.", "image": o },
//             { "name": "Baler", "price": "₹75,000", "description": "Baler is used for compacting and baling straw, hay, or silage. It helps in efficient storage and transport of fodder, ensuring better feed management for livestock.", "image": p },
//             { "name": "Chisel Plough", "price": "₹50,000", "description": "Chisel Plough is designed for deep tillage, breaking hard soil layers and improving soil structure. It enhances water infiltration and root growth, making it suitable for clayey soils and heavy farming.", "image": q }
//           ]
//         },
//         "Consultant": {
//           "title": "Consultant",
//           "items": [
//             { "name": "Soil Specialist", "price": "₹1,000/hr", "description": "A Soil Specialist offers expertise in soil health, nutrient management, and fertility enhancement. They analyze soil samples, recommend treatments, and help in improving crop yields through effective soil management.", "image": "/images/soil_specialist.jpg" },
//             { "name": "Crop Advisor", "price": "₹1,000/hr", "description": "Crop Advisors provide guidance on selecting the right crops for different soil types and climates. They offer advice on crop rotation, pest management, and optimizing crop production.", "image": "/images/crop_advisor.jpg" },
//             { "name": "Irrigation Expert", "price": "₹1,000/hr", "description": "Irrigation Experts design and implement efficient irrigation systems to ensure optimal water supply for crops. They help in water management strategies, system installation, and maintenance.", "image": "/images/irrigation_expert.jpg" },
//             { "name": "Pest Control Advisor", "price": "₹1,500/hr", "description": "Pest Control Advisors provide strategies for managing pests and diseases that affect crops. They offer solutions for prevention and control, helping to minimize crop damage and loss.", "image": "/images/pest_control_advisor.jpg" },
//             { "name": "Organic Farming Consultant", "price": "₹1,500/hr", "description": "Organic Farming Consultants guide farmers in transitioning to and managing organic farming practices. They offer advice on organic inputs, pest management, and compliance with organic standards.", "image": "/images/organic_farming_consultant.jpg" },
//             { "name": "Agricultural Engineer", "price": "₹1,000/hr", "description": "Agricultural Engineers provide expertise in designing and improving agricultural machinery and infrastructure. They work on optimizing equipment use, farm layout, and technology integration.", "image": "/images/agricultural_engineer.jpg" },
//             { "name": "Nutrient Management Specialist", "price": "₹1,200/hr", "description": "Nutrient Management Specialists focus on optimizing nutrient use in crops to improve growth and yields. They analyze plant and soil nutrient levels and recommend appropriate fertilization strategies.", "image": "/images/nutrient_management_specialist.jpg" },
//             { "name": "Farm Management Consultant", "price": "₹1,500/hr", "description": "Farm Management Consultants help in improving overall farm operations, including crop planning, resource management, and financial planning. They offer strategies for enhancing productivity and profitability.", "image": "/images/farm_management_consultant.jpg" },
//             { "name": "Climate Advisor", "price": "₹1,800/hr", "description": "Climate Advisors provide insights into how climate factors impact farming practices. They offer recommendations for adapting to climate change and optimizing crop performance under varying weather conditions.", "image": "/images/climate_advisor.jpg" },
//             { "name": "Agribusiness Consultant", "price": "₹1,800/hr", "description": "Agribusiness Consultants offer expertise in the business aspects of agriculture, including market analysis, business planning, and investment strategies. They help in maximizing profitability and growth.", "image": "/images/agribusiness_consultant.jpg" }
//           ]
//         },
//         "Workers": {
//           "title": "Workers",
//           "items": [
//             { "name": "Farm Laborer", "price": "₹1,200/day", "description": "Farm Laborers assist with various tasks on the farm, including planting, weeding, and harvesting. They provide essential manual labor, ensuring smooth farm operations and timely completion of tasks." },
//             { "name": "Irrigation Technician", "price": "₹1,500/day", "description": "Irrigation Technicians specialize in managing and maintaining irrigation systems. They ensure proper installation, operation, and repair of irrigation equipment to provide adequate water supply to crops.", },
//             { "name": "Machinery Operator", "price": "₹1,800/day", "description": "Machinery Operators are skilled in handling and operating various farm machinery such as tractors, harvesters, and ploughs. They ensure efficient and safe operation of equipment for various farming tasks.",  },
//             { "name": "Pest Control Worker", "price": "₹1,400/day", "description": "Pest Control Workers apply pest control measures to protect crops from pests and diseases. They use various methods and chemicals to manage pest populations and ensure crop health." },
//             { "name": "Harvesting Crew", "price": "₹1,600/day", "description": "Harvesting Crews are responsible for the efficient and timely collection of crops. They work in teams to gather produce, ensuring minimal damage and optimal harvest quality." },
//             { "name": "Greenhouse Technician", "price": "₹1,700/day", "description": "Greenhouse Technicians manage and maintain greenhouse environments, including temperature, humidity, and light levels. They ensure optimal conditions for plant growth and productivity." },
//             { "name": "Livestock Handler", "price": "₹1,500/day", "description": "Livestock Handlers care for and manage farm animals, including feeding, grooming, and health monitoring. They ensure the well-being of animals and assist in their overall management." },
//             { "name": "Soil Technician", "price": "₹1,800/day", "description": "Soil Technicians analyze soil conditions and provide recommendations for soil improvement. They assist in soil testing, treatment, and management to enhance crop growth and yields." },
//             { "name": "Field Supervisor", "price": "₹2,000/day", "description": "Field Supervisors oversee farm operations, managing workers and ensuring tasks are completed efficiently. They handle scheduling, quality control, and coordination of various farm activities." },
//             { "name": "Veterinary Technician", "price": "₹1,900/day", "description": "Veterinary Technicians assist with the health care of farm animals, including vaccinations, treatments, and health monitoring. They work alongside veterinarians to ensure animal health and productivity" }
//           ]
//         },
//         "Schemes": {
//           "title": "Schemes",
//           "items": [
//             {
//               "name": "Pradhan Mantri Fasal Bima Yojana (PMFBY)",
//               "type": "Crop Insurance",
//               "details": "This scheme offers insurance coverage for crops to protect farmers from financial losses due to crop failure caused by natural calamities, pests, or diseases. It aims to reduce the risk of farming and secure farmer livelihoods.",
//               "amount": "Premium subsidy up to 98% of the sum insured, depending on the crop and region."
//             },
//             {
//               "name": "Pradhan Mantri Kisan Samman Nidhi (PM-KISAN)",
//               "type": "Income Support",
//               "details": "PM-KISAN provides direct financial assistance to small and marginal farmers. The scheme aims to ensure financial support for farming activities and improve their income levels.",
//               "amount": "₹6,000 per year in three equal installments of ₹2,000 each."
//             },
//             {
//               "name": "Agriculture Infrastructure Fund (AIF)",
//               "type": "Infrastructure Development",
//               "details": "AIF supports the development of agricultural infrastructure such as warehouses, cold storage, and processing units. It aims to improve the supply chain and reduce post-harvest losses.",
//               "amount": "Interest subvention of 3% per annum up to ₹2 crore."
//             },
//             {
//               "name": "National Agriculture Market (e-NAM)",
//               "type": "Market Support",
//               "details": "e-NAM facilitates online trading of agricultural produce, providing farmers access to national markets. It aims to enhance market efficiency and reduce transaction costs for farmers.",
//               "amount": "No direct financial assistance, but it helps reduce marketing and transportation costs."
//             },
//             {
//               "name": "Pradhan Mantri Krishi Sinchayee Yojana (PMKSY)",
//               "type": "Irrigation Support",
//               "details": "PMKSY focuses on improving irrigation facilities to ensure water access for every farm. It supports the implementation of micro-irrigation systems and efficient water management practices.",
//               "amount": "Subsidy up to 50% on equipment for micro-irrigation."
//             },
//             {
//               "name": "Tamil Nadu Crop Insurance Scheme",
//               "type": "State Crop Insurance",
//               "details": "This state-specific scheme offers insurance coverage for crops against natural calamities and adverse weather conditions. It aims to protect farmers from crop loss and financial instability.",
//               "amount": "Premium subsidy ranging from 50% to 75% depending on the crop and region."
//             },
//             {
//               "name": "Solar Powered Pumping System",
//               "type": "Renewable Energy",
//               "details": "This scheme supports the installation of solar-powered pumps to reduce electricity costs for irrigation. It promotes the use of renewable energy in farming operations.",
//               "amount": "Subsidy of up to 90% for small and marginal farmers."
//             },
//             {
//               "name": "Integrated Scheme on Agriculture Marketing (ISAM)",
//               "type": "Market Support",
//               "details": "ISAM supports the development of infrastructure for marketing agricultural products, including market yards and cold storage. It aims to enhance market facilities and improve farmer income.",
//               "amount": "Subsidy of 25% to 33.33% on the cost of infrastructure development."
//             },
//             {
//               "name": "National Food Security Mission (NFSM)",
//               "type": "Production Enhancement",
//               "details": "NFSM aims to increase the production of food grains by promoting the use of high-yielding varieties, improving soil health, and providing technical support to farmers.",
//               "amount": "Subsidy for seeds, fertilizers, and other inputs."
//             },
//             {
//               "name": "Rural Infrastructure Development Fund (RIDF)",
//               "type": "Infrastructure Financing",
//               "details": "RIDF provides financial support for rural infrastructure projects, including agricultural development, irrigation, and rural connectivity. It aims to enhance rural infrastructure and support agricultural growth.",
//               "amount": "Loan facilities with subsidized interest rates."
//             }
//           ]
//         },
//         "Educational & Awareness": {
//           "title": "Educational & Awareness",
//           "items": [
//             { "name": "Soil Health Workshop", "price": "₹4,000", "description": "Soil Health Workshops cover topics on soil fertility, nutrient management, and soil testing. Participants learn techniques for improving soil health and productivity, including practical demonstrations and case studies.", "image": "/images/soil_health_workshop.jpg" },
//             { "name": "Organic Farming Webinar", "price": "₹2,500", "description": "Organic Farming Webinars provide insights into organic farming practices, including composting, organic pest control, and soil management. The sessions are conducted by experts and include Q&A sessions.", "image": "/images/organic_farming_webinar.jpg" },
//             { "name": "Pest Management Training", "price": "₹3,000", "description": "Pest Management Training covers effective strategies for controlling pests and diseases. Topics include pest identification, integrated pest management (IPM), and the safe use of pesticides and natural predators.", "image": "/images/pest_management_training.jpg" },
//             { "name": "Water Conservation Seminar", "price": "₹2,800", "description": "Water Conservation Seminars focus on techniques and technologies for efficient water use in agriculture. Participants learn about irrigation methods, water-saving technologies, and best practices for sustainable water management.", "image": "/images/water_conservation_seminar.jpg" },
//             { "name": "Sustainable Agriculture Course", "price": "₹8,000", "description": "The Sustainable Agriculture Course provides a comprehensive understanding of sustainable farming practices. It covers soil health, crop rotation, organic farming, and conservation techniques to promote environmental sustainability.", "image": "/images/sustainable_agriculture_course.jpg" },
//             { "name": "Climate Change Adaptation Workshop", "price": "₹5,000", "description": "This workshop focuses on adapting agricultural practices to climate change. Topics include understanding climate impacts, developing adaptation strategies, and implementing climate-smart agriculture techniques.", "image": "/images/climate_change_adaptation_workshop.jpg" },
//             { "name": "Agroforestry Training", "price": "₹4,500", "description": "Agroforestry Training provides knowledge on integrating trees and shrubs into farming systems. The training covers benefits, management practices, and economic advantages of agroforestry for sustainable land use.", "image": "/images/agroforestry_training.jpg" },
//             { "name": "Precision Farming Seminar", "price": "₹3,500", "description": "Precision Farming Seminars explore the use of technology and data in optimizing farm operations. Topics include GPS-guided equipment, data analysis, and variable rate application for improved efficiency and yields.", "image": "/images/precision_farming_seminar.jpg" },
//             { "name": "Farm Business Management Course", "price": "₹7,500", "description": "Farm Business Management Course offers training in managing farm operations effectively. It covers financial planning, marketing strategies, and risk management to enhance farm profitability and sustainability.", "image": "/images/farm_business_management_course.jpg" },
//             { "name": "Integrated Pest Management (IPM) Workshop", "price": "₹4,000", "description": "The IPM Workshop provides insights into managing pests using integrated approaches. It covers biological control, cultural practices, and chemical methods to control pests while minimizing environmental impact.", "image": "/images/ipm_workshop.jpg" }
//           ]
//         }
//       };

//       const AlteredStore = () => {
//         const [selectedSection, setSelectedSection] = useState('');
//         const [searchQuery, setSearchQuery] = useState('');
//         const [expandedItem, setExpandedItem] = useState(null);
    
//         const handleSectionClick = (section) => {
//             setSelectedSection(section);
//             setExpandedItem(null); // Reset expanded item when changing sections
//         };
    
//         const handleMoreDetailsClick = (item) => {
//             setExpandedItem(expandedItem === item ? null : item); // Toggle expanded state
//         };
    
//         const filteredItems = sectionInfo[selectedSection]?.items.filter(item =>
//             item.name.toLowerCase().includes(searchQuery.toLowerCase())
//         ) || [];
    
//         return (
//             <div className="min-h-screen bg-green-50 p-4">
//                 <div className="pl-5 font-montserrat font-bold text-2xl text-green-700">Store</div>
//                 <div className="pl-1">
//                     <div className="flex items-center border border-gray-800 rounded-md w-11/12 mx-auto">
//                         <input
//                             type="text"
//                             placeholder="Search..."
//                             className="pl-2 py-2 w-full border-none focus:ring-0 rounded-md"
//                             value={searchQuery}
//                             onChange={(e) => setSearchQuery(e.target.value)}
//                         />
//                         <SearchIcon className="text-gray-500 ml-2" />
//                     </div>
//                 </div>
    
//                 <div className="font-bold flex justify-between font-montserrat pt-5 pl-3">
//                     <p>Categories</p>
//                 </div>
    
//                 {/* Horizontal scrollable categories */}
//                 <div className="flex overflow-x-auto space-x-4 py-2 categories-scroll">
//                     {Object.keys(sectionInfo).map((section) => (
//                         <div
//                             key={section}
//                             className={`cursor-pointer p-2 rounded-lg whitespace-nowrap ${
//                                 selectedSection === section ? 'bg-green-200' : 'hover:bg-green-100'
//                             }`}
//                             onClick={() => handleSectionClick(section)}
//                         >
//                             {sectionInfo[section].title}
//                         </div>
//                     ))}
//                 </div>
    
//     <div>
//     <div>

//     </div>

//     </div>
//             </div>
//         );
//     };
    
//     export default AlteredStore;



import React, { useState } from 'react';
import SearchIcon from '@mui/icons-material/Search';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import a from '../images/compost.jpg'
import b from '../images/nitro1.jpg'
import c from '../images/pottasium.jpg'
import d from '../images/phos.jpg'
import e from '../images/urea.jpg'
import f from '../images/superphos.jpg'
import g from '../images/calnitrate.jpg'
import h from '../images/micronutrient.jpg'
import i from '../images/bonemeall.jpg'
import j from '../images/tractor.jpg'
import k from '../images/plough.jpg'
import l from '../images/seedrill.jpg'
import m from '../images/sprayer.jpg'
import n from '../images/harvester.jpg'
import o from '../images/rotavator.jpg'
import p from '../images/baler.jpg'
import q from '../images/chiselplough.jpg'

const sectionInfo = {
  "Fertilizers": {
      "title": "Fertilizers",
      "items": [
          { "name": "Nitrogen Fertilizer", "price": "₹1,500", "description": "Nitrogen Fertilizer is crucial for promoting vigorous plant growth by enhancing leaf and stem development. It helps in the synthesis of proteins and chlorophyll, leading to increased crop yields. Ideal for leafy vegetables and cereals.", "image": b },
          { "name": "Phosphorus Fertilizer", "price": "₹1,875", "description": "Phosphorus Fertilizer improves root development and enhances flowering and fruiting. It is essential for energy transfer and storage in plants, making it vital for root crops and flowering plants. It also boosts resistance to diseases.", "image": d },
          { "name": "Potassium Fertilizer", "price": "₹1,350", "description": "Potassium Fertilizer aids in enhancing the plant's ability to resist diseases and improve water retention. It plays a key role in photosynthesis and protein synthesis. Suitable for a wide range of crops including vegetables and grains.", "image": c },
          { "name": "Compost", "price": "₹1,125", "description": "Compost is rich in organic matter and nutrients, improving soil texture and fertility. It helps in the retention of moisture and supports healthy root development. Suitable for all types of crops, it is an essential component of organic farming.", "image": a },
          { "name": "Urea", "price": "₹1,200", "description": "Urea is a high-nitrogen fertilizer that promotes rapid plant growth and development. It is widely used for cereals, vegetables, and other crops needing a quick nitrogen boost. Ensure proper application to avoid nitrogen leaching.", "image": e },
          { "name": "Superphosphate", "price": "₹1,800", "description": "Superphosphate provides a readily available source of phosphorus to plants, supporting root growth and flowering. It is beneficial for root crops like potatoes and carrots, as well as for flowering plants and vegetables.", "image": f },
          { "name": "Calcium Nitrate", "price": "₹2,000", "description": "Calcium Nitrate supplies calcium and nitrogen to plants, essential for cell wall development and overall plant health. It is particularly useful for preventing calcium deficiencies in crops such as tomatoes and peppers.", "image": g },
          { "name": "Micronutrient Mix", "price": "₹1,800", "description": "Micronutrient Mix provides essential trace elements like zinc, iron, and manganese that are critical for plant health and development. It helps in correcting deficiencies and enhancing crop productivity.", "image": h },
          { "name": "Bone Meal", "price": "₹1,650", "description": "Bone Meal is a slow-release organic fertilizer that enriches the soil with phosphorus and calcium. It supports strong root development and helps in flowering and fruiting. Ideal for use in vegetable gardens and flower beds.", "image": i }
      ]
      },
      "Equipment": {
        "title": "Equipment",
        "items": [
          { "name": "Tractor", "price": "₹1,25,000", "description": "A versatile tractor designed for various farming tasks, including ploughing, tilling, and hauling. Its powerful engine and robust build make it suitable for large-scale farming operations, enhancing productivity.", "image": j },
          { "name": "Plough", "price": "₹30,000", "description": "A high-quality plough designed for efficient soil preparation. It helps in breaking up and turning over soil, making it suitable for planting and improving soil aeration. Essential for tilling large fields.", "image": k},
          { "name": "Seed Drill", "price": "₹40,000", "description": "Seed Drill ensures precise planting of seeds at the correct depth and spacing. It enhances germination rates and crop uniformity, making it ideal for various crops including grains and vegetables.", "image": l },
          { "name": "Sprayer Machine", "price": "₹25,000", "description": "Sprayer Machine is used for applying pesticides, herbicides, and fertilizers evenly across crops. It ensures effective coverage and reduces manual labor, improving crop protection and nutrient application.", "image": m },
          { "name": "Harvester", "price": "₹2,00,000", "description": "Harvester is designed for efficient and quick harvesting of crops such as wheat, rice, and corn. It reduces labor costs and harvest time, making it ideal for large-scale farming operations.", "image": n },
          { "name": "Rotavator", "price": "₹45,000", "description": "Rotavator is used for preparing soil by breaking it into finer particles. It improves soil aeration and mixing of organic matter, making it ready for planting and enhancing soil fertility.", "image": o },
          { "name": "Baler", "price": "₹75,000", "description": "Baler is used for compacting and baling straw, hay, or silage. It helps in efficient storage and transport of fodder, ensuring better feed management for livestock.", "image": p },
          { "name": "Chisel Plough", "price": "₹50,000", "description": "Chisel Plough is designed for deep tillage, breaking hard soil layers and improving soil structure. It enhances water infiltration and root growth, making it suitable for clayey soils and heavy farming.", "image": q }
        ]
      },
      "Consultant": {
        "title": "Consultant",
        "items": [
          { "name": "Soil Specialist", "price": "₹1,000/hr", "description": "A Soil Specialist offers expertise in soil health, nutrient management, and fertility enhancement. They analyze soil samples, recommend treatments, and help in improving crop yields through effective soil management.", "image": "/images/soil_specialist.jpg" },
          { "name": "Crop Advisor", "price": "₹1,000/hr", "description": "Crop Advisors provide guidance on selecting the right crops for different soil types and climates. They offer advice on crop rotation, pest management, and optimizing crop production.", "image": "/images/crop_advisor.jpg" },
          { "name": "Irrigation Expert", "price": "₹1,000/hr", "description": "Irrigation Experts design and implement efficient irrigation systems to ensure optimal water supply for crops. They help in water management strategies, system installation, and maintenance.", "image": "/images/irrigation_expert.jpg" },
          { "name": "Pest Control Advisor", "price": "₹1,500/hr", "description": "Pest Control Advisors provide strategies for managing pests and diseases that affect crops. They offer solutions for prevention and control, helping to minimize crop damage and loss.", "image": "/images/pest_control_advisor.jpg" },
          { "name": "Organic Farming Consultant", "price": "₹1,500/hr", "description": "Organic Farming Consultants guide farmers in transitioning to and managing organic farming practices. They offer advice on organic inputs, pest management, and compliance with organic standards.", "image": "/images/organic_farming_consultant.jpg" },
          { "name": "Agricultural Engineer", "price": "₹1,000/hr", "description": "Agricultural Engineers provide expertise in designing and improving agricultural machinery and infrastructure. They work on optimizing equipment use, farm layout, and technology integration.", "image": "/images/agricultural_engineer.jpg" },
          { "name": "Nutrient Management Specialist", "price": "₹1,200/hr", "description": "Nutrient Management Specialists focus on optimizing nutrient use in crops to improve growth and yields. They analyze plant and soil nutrient levels and recommend appropriate fertilization strategies.", "image": "/images/nutrient_management_specialist.jpg" },
          { "name": "Farm Management Consultant", "price": "₹1,500/hr", "description": "Farm Management Consultants help in improving overall farm operations, including crop planning, resource management, and financial planning. They offer strategies for enhancing productivity and profitability.", "image": "/images/farm_management_consultant.jpg" },
          { "name": "Climate Advisor", "price": "₹1,800/hr", "description": "Climate Advisors provide insights into how climate factors impact farming practices. They offer recommendations for adapting to climate change and optimizing crop performance under varying weather conditions.", "image": "/images/climate_advisor.jpg" },
          { "name": "Agribusiness Consultant", "price": "₹1,800/hr", "description": "Agribusiness Consultants offer expertise in the business aspects of agriculture, including market analysis, business planning, and investment strategies. They help in maximizing profitability and growth.", "image": "/images/agribusiness_consultant.jpg" }
        ]
      },
      "Workers": {
        "title": "Workers",
        "items": [
          { "name": "Farm Laborer", "price": "₹1,200/day", "description": "Farm Laborers assist with various tasks on the farm, including planting, weeding, and harvesting. They provide essential manual labor, ensuring smooth farm operations and timely completion of tasks." },
          { "name": "Irrigation Technician", "price": "₹1,500/day", "description": "Irrigation Technicians specialize in managing and maintaining irrigation systems. They ensure proper installation, operation, and repair of irrigation equipment to provide adequate water supply to crops.", },
          { "name": "Machinery Operator", "price": "₹1,800/day", "description": "Machinery Operators are skilled in handling and operating various farm machinery such as tractors, harvesters, and ploughs. They ensure efficient and safe operation of equipment for various farming tasks.",  },
          { "name": "Pest Control Worker", "price": "₹1,400/day", "description": "Pest Control Workers apply pest control measures to protect crops from pests and diseases. They use various methods and chemicals to manage pest populations and ensure crop health." },
          { "name": "Harvesting Crew", "price": "₹1,600/day", "description": "Harvesting Crews are responsible for the efficient and timely collection of crops. They work in teams to gather produce, ensuring minimal damage and optimal harvest quality." },
          { "name": "Greenhouse Technician", "price": "₹1,700/day", "description": "Greenhouse Technicians manage and maintain greenhouse environments, including temperature, humidity, and light levels. They ensure optimal conditions for plant growth and productivity." },
          { "name": "Livestock Handler", "price": "₹1,500/day", "description": "Livestock Handlers care for and manage farm animals, including feeding, grooming, and health monitoring. They ensure the well-being of animals and assist in their overall management." },
          { "name": "Soil Technician", "price": "₹1,800/day", "description": "Soil Technicians analyze soil conditions and provide recommendations for soil improvement. They assist in soil testing, treatment, and management to enhance crop growth and yields." },
          { "name": "Field Supervisor", "price": "₹2,000/day", "description": "Field Supervisors oversee farm operations, managing workers and ensuring tasks are completed efficiently. They handle scheduling, quality control, and coordination of various farm activities." },
          { "name": "Veterinary Technician", "price": "₹1,900/day", "description": "Veterinary Technicians assist with the health care of farm animals, including vaccinations, treatments, and health monitoring. They work alongside veterinarians to ensure animal health and productivity" }
        ]
      },
      "Schemes": {
        "title": "Schemes",
        "items": [
          {
            "name": "Pradhan Mantri Fasal Bima Yojana (PMFBY)",
            "type": "Crop Insurance",
            "details": "This scheme offers insurance coverage for crops to protect farmers from financial losses due to crop failure caused by natural calamities, pests, or diseases. It aims to reduce the risk of farming and secure farmer livelihoods.",
            "amount": "Premium subsidy up to 98% of the sum insured, depending on the crop and region."
          },
          {
            "name": "Pradhan Mantri Kisan Samman Nidhi (PM-KISAN)",
            "type": "Income Support",
            "details": "PM-KISAN provides direct financial assistance to small and marginal farmers. The scheme aims to ensure financial support for farming activities and improve their income levels.",
            "amount": "₹6,000 per year in three equal installments of ₹2,000 each."
          },
          {
            "name": "Agriculture Infrastructure Fund (AIF)",
            "type": "Infrastructure Development",
            "details": "AIF supports the development of agricultural infrastructure such as warehouses, cold storage, and processing units. It aims to improve the supply chain and reduce post-harvest losses.",
            "amount": "Interest subvention of 3% per annum up to ₹2 crore."
          },
          {
            "name": "National Agriculture Market (e-NAM)",
            "type": "Market Support",
            "details": "e-NAM facilitates online trading of agricultural produce, providing farmers access to national markets. It aims to enhance market efficiency and reduce transaction costs for farmers.",
            "amount": "No direct financial assistance, but it helps reduce marketing and transportation costs."
          },
          {
            "name": "Pradhan Mantri Krishi Sinchayee Yojana (PMKSY)",
            "type": "Irrigation Support",
            "details": "PMKSY focuses on improving irrigation facilities to ensure water access for every farm. It supports the implementation of micro-irrigation systems and efficient water management practices.",
            "amount": "Subsidy up to 50% on equipment for micro-irrigation."
          },
          {
            "name": "Tamil Nadu Crop Insurance Scheme",
            "type": "State Crop Insurance",
            "details": "This state-specific scheme offers insurance coverage for crops against natural calamities and adverse weather conditions. It aims to protect farmers from crop loss and financial instability.",
            "amount": "Premium subsidy ranging from 50% to 75% depending on the crop and region."
          },
          {
            "name": "Solar Powered Pumping System",
            "type": "Renewable Energy",
            "details": "This scheme supports the installation of solar-powered pumps to reduce electricity costs for irrigation. It promotes the use of renewable energy in farming operations.",
            "amount": "Subsidy of up to 90% for small and marginal farmers."
          },
          {
            "name": "Integrated Scheme on Agriculture Marketing (ISAM)",
            "type": "Market Support",
            "details": "ISAM supports the development of infrastructure for marketing agricultural products, including market yards and cold storage. It aims to enhance market facilities and improve farmer income.",
            "amount": "Subsidy of 25% to 33.33% on the cost of infrastructure development."
          },
          {
            "name": "National Food Security Mission (NFSM)",
            "type": "Production Enhancement",
            "details": "NFSM aims to increase the production of food grains by promoting the use of high-yielding varieties, improving soil health, and providing technical support to farmers.",
            "amount": "Subsidy for seeds, fertilizers, and other inputs."
          },
          {
            "name": "Rural Infrastructure Development Fund (RIDF)",
            "type": "Infrastructure Financing",
            "details": "RIDF provides financial support for rural infrastructure projects, including agricultural development, irrigation, and rural connectivity. It aims to enhance rural infrastructure and support agricultural growth.",
            "amount": "Loan facilities with subsidized interest rates."
          }
        ]
      },
      "Educational & Awareness": {
        "title": "Educational & Awareness",
        "items": [
          { "name": "Soil Health Workshop", "price": "₹4,000", "description": "Soil Health Workshops cover topics on soil fertility, nutrient management, and soil testing. Participants learn techniques for improving soil health and productivity, including practical demonstrations and case studies." },
          { "name": "Organic Farming Webinar", "price": "₹2,500", "description": "Organic Farming Webinars provide insights into organic farming practices, including composting, organic pest control, and soil management. The sessions are conducted by experts and include Q&A sessions." },
          { "name": "Pest Management Training", "price": "₹3,000", "description": "Pest Management Training covers effective strategies for controlling pests and diseases. Topics include pest identification, integrated pest management (IPM), and the safe use of pesticides and natural predators." },
          { "name": "Water Conservation Seminar", "price": "₹2,800", "description": "Water Conservation Seminars focus on techniques and technologies for efficient water use in agriculture. Participants learn about irrigation methods, water-saving technologies, and best practices for sustainable water management."},
          { "name": "Sustainable Agriculture Course", "price": "₹8,000", "description": "The Sustainable Agriculture Course provides a comprehensive understanding of sustainable farming practices. It covers soil health, crop rotation, organic farming, and conservation techniques to promote environmental sustainability."},
          { "name": "Climate Change Adaptation Workshop", "price": "₹5,000", "description": "This workshop focuses on adapting agricultural practices to climate change. Topics include understanding climate impacts, developing adaptation strategies, and implementing climate-smart agriculture techniques." },
          { "name": "Agroforestry Training", "price": "₹4,500", "description": "Agroforestry Training provides knowledge on integrating trees and shrubs into farming systems. The training covers benefits, management practices, and economic advantages of agroforestry for sustainable land use." },
          { "name": "Precision Farming Seminar", "price": "₹3,500", "description": "Precision Farming Seminars explore the use of technology and data in optimizing farm operations. Topics include GPS-guided equipment, data analysis, and variable rate application for improved efficiency and yields." },
          { "name": "Farm Business Management Course", "price": "₹7,500", "description": "Farm Business Management Course offers training in managing farm operations effectively. It covers financial planning, marketing strategies, and risk management to enhance farm profitability and sustainability." },
          { "name": "Integrated Pest Management (IPM) Workshop", "price": "₹4,000", "description": "The IPM Workshop provides insights into managing pests using integrated approaches. It covers biological control, cultural practices, and chemical methods to control pests while minimizing environmental impact."}
        ]
      }
    };

const AlteredStore = () => {
    const [selectedSection, setSelectedSection] = useState('');
    const [searchQuery, setSearchQuery] = useState('');
    const [expandedItem, setExpandedItem] = useState(null);

    const handleSectionClick = (section) => {
        setSelectedSection(section);
        setExpandedItem(null); // Reset expanded item when changing sections
    };

    const handleMoreDetailsClick = (item) => {
        setExpandedItem(expandedItem === item ? null : item); // Toggle expanded state
    };

    const filteredItems = sectionInfo[selectedSection]?.items.filter(item =>
        item.name.toLowerCase().includes(searchQuery.toLowerCase())
    ) || [];

    const renderFertilizersAndEquipment = () => (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-4 justify-items-center">
          {filteredItems.map((item, index) => (
              <Card
                  key={index}
                  className="bg-white shadow-md rounded-md overflow-hidden"
                  style={{
                      width: '250px', // Set a fixed width for the card
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center' // Center the content within the card
                  }}
              >
                  <CardMedia
                      component="img"
                      image={item.image}
                      alt={item.name}
                      style={{
                          maxWidth: '100%', // Ensure the image does not exceed the card's width
                          maxHeight: '200px', // Set a maximum height for the image
                          width: 'auto', // Keeps the image's aspect ratio
                          height: 'auto', // Keeps the image's aspect ratio
                          objectFit: 'contain' // Ensures the image scales down without cropping
                      }}
                  />
                  <CardContent style={{ textAlign: 'center' }}> {/* Center text within the card */}
                      <Typography gutterBottom variant="h5" component="div">
                          {item.name}
                      </Typography>
                      <Typography variant="body2" color="textSecondary" component="p">
                          {item.price}
                      </Typography>
                      {expandedItem === item && (
                          <>
                              <Typography variant="body2" color="textSecondary" component="p">
                                  {item.description}
                              </Typography>
                              <Button size="small" color="primary">
                                  Buy Now
                              </Button>
                          </>
                      )}
                  </CardContent>
                  <CardActions>
                      <Button size="small" color="primary" onClick={() => handleMoreDetailsClick(item)}>
                          {expandedItem === item ? 'Show Less' : 'Show More'}
                      </Button>
                  </CardActions>
              </Card>
          ))}
      </div>
  );
  
  

    const renderConsultants = () => (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-4">
            {filteredItems.map((item, index) => (
                <Card key={index} className="bg-white shadow-md rounded-md overflow-hidden">
                    <CardContent>
                        <Typography gutterBottom variant="h5" component="div">
                            {item.name}
                        </Typography>
                        <Typography variant="body2" color="textSecondary" component="p">
                            {item.price}
                        </Typography>
                        {expandedItem === item && (
                            <Typography variant="body2" color="textSecondary" component="p">
                                {item.description}
                            </Typography>
                        )}
                    </CardContent>
                    <CardActions>
                        <Button size="small" color="primary" onClick={() => handleMoreDetailsClick(item)}>
                            {expandedItem === item ? 'Show Less' : 'Show More'}
                        </Button>
                    </CardActions>
                </Card>
            ))}
        </div>
    );

    const renderSchemesAndEducational = () => (
        <div className="pt-4 space-y-4">
            {filteredItems.map((item, index) => (
                <div key={index} className="bg-white shadow-md rounded-md p-4">
                    <Typography variant="h6" component="div">
                        {item.name}
                    </Typography>
                    <Typography variant="body2" color="textSecondary" component="p">
                        {item.type && <><strong>Type:</strong> {item.type}</>}
                    </Typography>
                    <Typography variant="body2" color="textSecondary" component="p">
                        {item.details}
                    </Typography>
                    {item.amount && (
                        <Typography variant="body2" color="textSecondary" component="p">
                            <strong>Amount:</strong> {item.amount}
                        </Typography>
                    )}
                </div>
            ))}
        </div>
    );

    const renderWorkers = () => (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-4">
          {filteredItems.map((item, index) => (
              <Card key={index} className="bg-white shadow-md rounded-md overflow-hidden">
                  <CardContent>
                      <Typography gutterBottom variant="h5" component="div">
                          {item.name}
                      </Typography>
                      <Typography variant="body2" color="textSecondary" component="p">
                          {item.price}
                      </Typography>
                      {expandedItem === item && (
                          <Typography variant="body2" color="textSecondary" component="p">
                              {item.description}
                          </Typography>
                      )}
                  </CardContent>
                  <CardActions>
                      <Button size="small" color="primary" onClick={() => handleMoreDetailsClick(item)}>
                          {expandedItem === item ? 'Show Less' : 'Show More'}
                      </Button>
                  </CardActions>
              </Card>
          ))}
      </div>
  );

  const renderEducationalAwareness = () => (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-4">
          {filteredItems.map((item, index) => (
              <Card key={index} className="bg-white shadow-md rounded-md overflow-hidden">
                  {/* <CardMedia
                      component="img"
                      height="140"
                      image={item.image}
                      alt={item.name}
                  /> */}
                  <CardContent>
                      <Typography gutterBottom variant="h5" component="div">
                          {item.name}
                      </Typography>
                      <Typography variant="body2" color="textSecondary" component="p">
                          {item.price}
                      </Typography>
                      {expandedItem === item && (
                          <Typography variant="body2" color="textSecondary" component="p">
                              {item.description}
                          </Typography>
                      )}
                  </CardContent>
                  <CardActions>
                      <Button size="small" color="primary" onClick={() => handleMoreDetailsClick(item)}>
                          {expandedItem === item ? 'Show Less' : 'Show More'}
                      </Button>
                  </CardActions>
              </Card>
          ))}
      </div>
  );

  const renderSectionContent = () => {
      switch (selectedSection) {
          case "Fertilizers":
          case "Equipment":
              return renderFertilizersAndEquipment();
          case "Consultant":
              return renderConsultants();
          case "Workers":
              return renderWorkers();
          case "Educational & Awareness":
              return renderEducationalAwareness();
          case "Schemes":
              return renderSchemesAndEducational();
          default:
              return <div className="text-center pt-10">Please select a category.</div>;
      }
  };
    return (
        <div className="min-h-screen bg-green-50 p-4">
            <div className="pl-5 font-montserrat font-bold text-2xl text-green-700">Store</div>
            <div className="pl-1">
                <div className="flex items-center border border-gray-800 rounded-md w-11/12 mx-auto">
                    <input
                        type="text"
                        placeholder="Search..."
                        className="pl-2 py-2 w-full border-none focus:ring-0 rounded-md"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                    />
                    <SearchIcon className="text-gray-500 ml-2" />
                </div>
            </div>

            <div className="font-bold flex justify-between font-montserrat pt-5 pl-3">
                <p>Categories</p>
            </div>

            {/* Horizontal scrollable categories */}
            <div className="flex overflow-x-auto space-x-4 py-2 categories-scroll">
                {Object.keys(sectionInfo).map((section) => (
                    <div
                        key={section}
                        className={`cursor-pointer p-2 rounded-lg whitespace-nowrap ${
                            selectedSection === section ? 'bg-green-200' : 'hover:bg-green-100'
                        }`}
                        onClick={() => handleSectionClick(section)}
                    >
                        {sectionInfo[section].title}
                    </div>
                ))}
            </div>

            {/* Render section content based on selection */}
            {renderSectionContent()}
        </div>
    );
};

export default AlteredStore;
